package com.example.jetpackpracticedemo.presentation.common

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import com.example.jetpackpracticedemo.navigation.AppRoute

@Composable
fun AppBottomBar(
    currentScreen:  AppRoute,
    onTabSelected: (AppRoute) -> Unit
) {
    NavigationBar {

        NavigationBarItem(
            selected = currentScreen == AppRoute.HomeScreen,
            onClick = { onTabSelected(AppRoute.HomeScreen) },
            icon = {
                Icon(Icons.Default.Home, null)
            },
            label = {
                Text("Home")
            }
        )


        NavigationBarItem(
            selected = currentScreen == AppRoute.FavoriteScreen,
            onClick = { onTabSelected(AppRoute.FavoriteScreen) },
            icon = {
                Icon(Icons.Default.Person, null)
            },
            label = {
                Text("Profile")
            }
        )

        NavigationBarItem(
            selected = currentScreen == AppRoute.SettingScreen,
            onClick = { onTabSelected(AppRoute.SettingScreen) },
            icon = {
                Icon(Icons.Default.Settings, null)
            },
            label = {
                Text("Search")
            }
        )
    }
}
