package com.example.jetpackpracticedemo.navigation

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.navigation.compose.NavHost

import androidx.compose.ui.Modifier
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.jetpackpracticedemo.presentation.common.AppBottomBar
import com.example.jetpackpracticedemo.presentation.common.AppTopBar
import com.example.jetpackpracticedemo.presentation.ui.favorite.FavoriteScreen
import com.example.jetpackpracticedemo.presentation.ui.home.HomeScreen
import com.example.jetpackpracticedemo.presentation.ui.setting.SettingScreen

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun AppNavigation() {
    val navController = rememberNavController()

    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = backStackEntry?.destination


    val topLevelScreens = setOf(
        AppRoute.HomeScreen,
        AppRoute.FavoriteScreen,
        AppRoute.SettingScreen
    )
    val currentScreen = when {
        currentDestination?.hasRoute<AppRoute.HomeScreen>() == true -> AppRoute.HomeScreen
        currentDestination?.hasRoute<AppRoute.FavoriteScreen>() == true -> AppRoute.FavoriteScreen
        currentDestination?.hasRoute<AppRoute.SettingScreen>() == true -> AppRoute.SettingScreen
        currentDestination?.hasRoute<AppRoute.CategoryScreen>() == true -> AppRoute.CategoryScreen
        currentDestination?.hasRoute<AppRoute.ListScreen>() == true -> AppRoute.ListScreen
        else -> AppRoute.HomeScreen
    }
    Scaffold(
        topBar = {
            AppTopBar(
                currentScreen = currentScreen,
                canNavigateBack = currentScreen !in topLevelScreens,
                navigateUp = { navController.navigateUp() }
            )
        },
        bottomBar = {
            if (currentScreen in topLevelScreens) {

                AppBottomBar(
                    currentScreen = currentScreen,
                    onTabSelected = { screen ->

                        navController.navigate(screen) {

                            popUpTo(
                                navController.graph.startDestinationId
                            ) {
                                saveState = true
                            }

                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )

            }
        }

    ){innerPadding ->
        NavHost(
            navController = navController,
           startDestination = AppRoute.HomeScreen,
            modifier = Modifier.padding(innerPadding)

        ){
            composable<AppRoute.HomeScreen>  {
                HomeScreen()
            }
            composable<AppRoute.FavoriteScreen>  {
                FavoriteScreen()
            }
            composable<AppRoute.SettingScreen>  {
                SettingScreen()
            }
//            composable<AppRoute.CategoryScreen>  {
//
//            }
//            composable<AppRoute.ListScreen>  {
//
//            }
        }


    }



}