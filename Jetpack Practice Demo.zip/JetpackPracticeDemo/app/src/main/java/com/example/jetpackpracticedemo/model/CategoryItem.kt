package com.example.jetpackpracticedemo.model

data class CategoryItem(
    val title: String,
    val count: String,
    val emoji: String
)