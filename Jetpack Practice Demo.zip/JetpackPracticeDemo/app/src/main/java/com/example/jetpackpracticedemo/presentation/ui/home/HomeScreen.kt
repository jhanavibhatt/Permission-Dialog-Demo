package com.example.jetpackpracticedemo.presentation.ui.home

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Color.Companion.Black
import androidx.compose.ui.graphics.Color.Companion.White
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun HomeScreen() {
    var selectedTab by rememberSaveable {
        mutableIntStateOf(0)
    }

    Column(modifier = Modifier.fillMaxSize().background(Color.Cyan).padding(15.dp)) {

        CustomTab(
            selectedItemIndex = selectedTab,
            items = listOf("Quotes", "Shayari"),
            onClick = { index ->
                selectedTab = index
            },
        )

        Spacer(modifier = Modifier.height(16.dp))

        when (selectedTab) {
            0 -> {
                QuotesContent()
            }

            1 -> {
                ShayariContent()
            }
        }
    }
}




@Composable
private fun MyTabIndicator(
    indicatorWidth: Dp,
    indicatorOffset: Dp,
    indicatorColor: Color,
) {
    Box(
        modifier = Modifier
            .fillMaxHeight()
            .width(
                width = indicatorWidth,
            )
            .offset(
                x = indicatorOffset,
            )
            .clip(
                shape = CircleShape,
            )
            .background(
                color = indicatorColor
            ),
    )
}
@Composable
private fun MyTabItem(
    isSelected: Boolean,
    onClick: () -> Unit,
    text: String,
    modifier: Modifier = Modifier
) {
    val tabTextColor by animateColorAsState(
        targetValue = if (isSelected) White else Black,
        animationSpec = tween(easing = LinearEasing),
        label = ""
    )

    Text(
        modifier = modifier
            .clip(CircleShape)
            .clickable(onClick = onClick)
            .padding(
                vertical = 12.dp,
                horizontal = 12.dp
            ),
        text = text,
        color = tabTextColor,
        textAlign = TextAlign.Center
    )
}
@Composable
fun CustomTab(
    selectedItemIndex: Int,
    items: List<String>,
    modifier: Modifier = Modifier,
    onClick: (Int) -> Unit,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(CircleShape)
            .background(White)
            .padding(4.dp)
    ) {
        items.forEachIndexed { index, text ->

            val selected = index == selectedItemIndex

            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(CircleShape)
                    .background(
                        if (selected)
                            MaterialTheme.colorScheme.primary
                        else
                            Color.Transparent
                    )
            ) {
                MyTabItem(
                    isSelected = selected,
                    onClick = { onClick(index) },
                    text = text,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}


