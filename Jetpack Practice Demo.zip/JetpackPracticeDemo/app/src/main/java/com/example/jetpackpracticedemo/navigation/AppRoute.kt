package com.example.jetpackpracticedemo.navigation

import androidx.annotation.StringRes
import com.example.jetpackpracticedemo.R
import kotlinx.serialization.Serializable

@Serializable
sealed class AppRoute(@StringRes val title: Int) {

    @Serializable
    data object HomeScreen : AppRoute(R.string.home)

    @Serializable
    data object FavoriteScreen : AppRoute(R.string.favorite)

    @Serializable
    data object SettingScreen : AppRoute(R.string.setting)

    @Serializable
    data object CategoryScreen : AppRoute(R.string.category)


    @Serializable
    data object ListScreen : AppRoute(R.string.list)

}