package com.example.jetpackpracticedemo.presentation.ui.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.jetpackpracticedemo.model.CategoryItem

val quoteCategories = listOf(
    CategoryItem("Motivation", "850+ Quotes", "⚡"),
    CategoryItem("Success", "720+ Quotes", "🏆"),
    CategoryItem("Life", "920+ Quotes", "🌞"),
    CategoryItem("Friendship", "640+ Quotes", "👥"),
    CategoryItem("Friendship", "640+ Quotes", "👥"),
    CategoryItem("Friendship", "640+ Quotes", "👥"),
    CategoryItem("Friendship", "640+ Quotes", "👥"),
    CategoryItem("Friendship", "640+ Quotes", "👥"),
    CategoryItem("Friendship", "640+ Quotes", "👥"),

)
@Preview(showBackground = true, showSystemUi = true)
@Composable
fun QuotesContent() {
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {

        item(
            span = { GridItemSpan(maxLineSpan) }
        ) {
            DayQuoteCard()
        }
        item(span = { GridItemSpan(maxLineSpan) }) {
            ExploreHeader(
                title = "Explore Quotes",
                onSeeAllClick = {}
            )
        }

        items(quoteCategories) { category ->
            CategoryCard(item = category)
        }
    }
}