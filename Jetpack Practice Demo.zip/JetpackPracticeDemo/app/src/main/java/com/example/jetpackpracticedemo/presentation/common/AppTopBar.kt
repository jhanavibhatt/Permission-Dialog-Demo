package com.example.jetpackpracticedemo.presentation.common

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.ArrowBackIosNew
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import com.example.jetpackpracticedemo.navigation.AppRoute

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppTopBar(
    currentScreen: AppRoute,
    canNavigateBack: Boolean,
    navigateUp: () -> Unit,
) {

    TopAppBar(
        title ={ Text(stringResource(currentScreen.title)) },
        navigationIcon ={

            if (canNavigateBack){
                IconButton(onClick = navigateUp) {
                    Icon(
                        imageVector = Icons.Filled.ArrowBackIosNew,
                        contentDescription =  "back arrow"
                    )
                }
            }else{
                Icon(imageVector = Icons.Default.Apps,
                    contentDescription = "app logo")
            }

        }
    )

}