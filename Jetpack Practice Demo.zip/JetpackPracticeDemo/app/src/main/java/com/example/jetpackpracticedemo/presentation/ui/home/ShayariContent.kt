package com.example.jetpackpracticedemo.presentation.ui.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.jetpackpracticedemo.model.CategoryItem

val shayariCategories = listOf(
    CategoryItem("Love", "1.2k+ Shayari", "❤️"),
    CategoryItem("Sad", "2.1k+ Shayari", "☁️"),
    CategoryItem("Love", "1.2k+ Shayari", "❤️"),
    CategoryItem("Life", "920+ Shayari", "🌼"),
    CategoryItem("Sad", "2.1k+ Shayari", "☁️"),
    CategoryItem("Good Morning", "430+ Shayari", "☀️"),
    CategoryItem("Life", "920+ Shayari", "🌼"),
    CategoryItem("Good Morning", "430+ Shayari", "☀️"),
    CategoryItem("Love", "1.2k+ Shayari", "❤️"),
    CategoryItem("Sad", "2.1k+ Shayari", "☁️"),
    CategoryItem("Love", "1.2k+ Shayari", "❤️"),
    CategoryItem("Life", "920+ Shayari", "🌼"),
    CategoryItem("Sad", "2.1k+ Shayari", "☁️"),
    CategoryItem("Good Morning", "430+ Shayari", "☀️"),
    CategoryItem("Life", "920+ Shayari", "🌼"),
    CategoryItem("Good Morning", "430+ Shayari", "☀️")
)

@Composable
fun ShayariContent() {
    Column(
        modifier = Modifier.fillMaxSize()
    ) {

        DayShayariCard()

        Spacer(modifier = Modifier.height(16.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {

            items(shayariCategories) { category ->

                CategoryCard(
                    category
                )
            }
        }
    }
}