package com.example.jetpackpracticedemo.presentation.ui.home

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

@Preview(showSystemUi = true, showBackground = true)
@Composable
fun DayShayariCard() {

    Card(
        modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.secondaryContainer
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {

            Text(
                text = "Shayari of the Day", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold
            )

            Text(
                text = "❤️", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.padding(top = 8.dp)
            )

            Text(
                text = """
        कुछ रिश्ते ऐसे होते हैं,
        जिन्हें शब्दों में नहीं बाँधा जा सकता।
        
        वो दिल में बस जाते हैं,
        और उम्र भर साथ रहते हैं।
    """.trimIndent(), style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 12.dp)
            )
        }
    }
}