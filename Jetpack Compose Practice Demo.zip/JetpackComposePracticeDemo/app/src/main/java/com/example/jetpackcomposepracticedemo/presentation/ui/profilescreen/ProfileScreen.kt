package com.example.jetpackcomposepracticedemo.presentation.ui.profilescreen

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridItemSpan
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.jetpackcomposepracticedemo.R
import com.example.jetpackcomposepracticedemo.presentation.ui.profilescreen.components.AllContent
import com.example.jetpackcomposepracticedemo.presentation.ui.profilescreen.components.HighLightGrid
import com.example.jetpackcomposepracticedemo.presentation.ui.profilescreen.components.ProfileBio
import com.example.jetpackcomposepracticedemo.presentation.ui.profilescreen.components.ProfileButtons
import com.example.jetpackcomposepracticedemo.presentation.ui.profilescreen.components.ProfileHeader
import com.example.jetpackcomposepracticedemo.presentation.ui.profilescreen.components.ProfileTabSelector

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun ProfileScreen() {


    var tabIndex by remember { mutableStateOf(0) }
    val tabs = listOf("Posts", "Reels", "Reposts", "Tagged")

    LazyVerticalStaggeredGrid(
        columns = StaggeredGridCells.Fixed(3), // The grid has 3 columns
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black),
        horizontalArrangement = Arrangement.spacedBy(1.dp),
        verticalItemSpacing = 1.dp
    ) {
        // --- HEADER SECTION (Full Width) ---
        item(span = StaggeredGridItemSpan.FullLine) {
            ProfileHeader()
        }

        item(span = StaggeredGridItemSpan.FullLine) {
            ProfileBio()
        }

        item(span = StaggeredGridItemSpan.FullLine) {
            ProfileButtons()
        }

        item(span = StaggeredGridItemSpan.FullLine) {
            HighLightGrid()
        }

        // --- TABS SECTION (Full Width) ---
        item(span = StaggeredGridItemSpan.FullLine) {
            // Pass the state to your Tab component
            ProfileTabSelector(
                tabs = tabs,
                selectedIndex = tabIndex,
                onTabClick = { tabIndex = it }
            )
        }

        when (tabIndex) {
            0 -> {
                AllContent()
            }
            1 -> { /* items for Reels*/ }
            2 -> { /* items for Reposts */ }
            3 -> { /* items for Tagged */ }
        }
    }

}

/*   LazyColumn(
       modifier = Modifier
           .fillMaxSize()
           .background(Color.Black),
       horizontalAlignment = Alignment.CenterHorizontally,

       ) {
       item {

           Row(
               modifier = Modifier
                   .fillMaxWidth(),
               horizontalArrangement = Arrangement.SpaceBetween,
               verticalAlignment = Alignment.CenterVertically
           ) {

               Box(
                   modifier = Modifier
                       .size(120.dp)
                       .padding(16.dp)
                       .border(width = 2.dp, color = Color.DarkGray, shape = CircleShape)
                       .padding(6.dp)
                       .clip(CircleShape)
                       .background(Color.Black)

               ) {
                   Image(
                       painter = painterResource(R.drawable.profile_img),
                       "profile",
                       modifier = Modifier.fillMaxSize(),
                       contentScale = ContentScale.Crop
                   )
               }
               Column(
                   modifier = Modifier.padding(12.dp),
                   verticalArrangement = Arrangement.Center,
                   horizontalAlignment = Alignment.CenterHorizontally
               ) {
                   Text(
                       "54",
                       color = Color.White,
                       fontWeight = FontWeight.SemiBold,
                       style = MaterialTheme.typography.titleMedium
                   )
                   Text(
                       "Posts",
                       color = Color.White,
                       fontWeight = FontWeight.SemiBold,
                       style = MaterialTheme.typography.titleMedium
                   )
               }
               Column(
                   modifier = Modifier.padding(12.dp),
                   verticalArrangement = Arrangement.Center,
                   horizontalAlignment = Alignment.CenterHorizontally
               ) {
                   Text(
                       "834",
                       color = Color.White,
                       fontWeight = FontWeight.SemiBold,
                       style = MaterialTheme.typography.titleSmall
                   )
                   Text(
                       "Followers",
                       color = Color.White,
                       fontWeight = FontWeight.SemiBold,
                       style = MaterialTheme.typography.titleSmall
                   )
               }
               Column(
                   modifier = Modifier.padding(12.dp),
                   verticalArrangement = Arrangement.Center,
                   horizontalAlignment = Alignment.CenterHorizontally
               ) {
                   Text(
                       "162",
                       color = Color.White,
                       fontWeight = FontWeight.SemiBold,
                       style = MaterialTheme.typography.titleSmall
                   )
                   Text(
                       "Following",
                       color = Color.White,
                       fontWeight = FontWeight.SemiBold,
                       style = MaterialTheme.typography.titleSmall
                   )
               }


           }
       }
       item {
           Column(
               modifier = Modifier
                   .fillMaxWidth()
                   .padding(start = 20.dp, end = 10.dp),
               verticalArrangement = Arrangement.Center,

               ) {
               Text(
                   "Jacob West",
                   color = Color.White,
                   fontWeight = FontWeight.Bold,
                   style = MaterialTheme.typography.titleMedium
               )
               Text(
                   "Digital goodies designer @pixsellz",
                   color = Color.White,
                   fontWeight = FontWeight.SemiBold,
                   style = MaterialTheme.typography.titleMedium
               )
               Text(
                   "Everything is designed",
                   color = Color.White,
                   fontWeight = FontWeight.SemiBold,
                   style = MaterialTheme.typography.titleMedium
               )

           }
       }
       item {
           Row(
               modifier = Modifier
                   .fillMaxWidth()
                   .padding(10.dp),
               horizontalArrangement = Arrangement.spacedBy(5.dp)
           ) {
               TextButton(
                   onClick = {},
                   contentPadding = PaddingValues(6.dp),
                   modifier = Modifier
                       .weight(2f)
                       .clip(RoundedCornerShape(10.dp))
                       .background(Color.DarkGray),
               )


               {
                   Text("Edit Profile", color = Color.White)
               }
               TextButton(
                   onClick = {},
                   contentPadding = PaddingValues(6.dp),
                   modifier = Modifier
                       .weight(2f)
                       .clip(RoundedCornerShape(10.dp))
                       .background(Color.DarkGray),
                   border = BorderStroke(1.dp, Color.DarkGray),
                   shape = MaterialTheme.shapes.small

               ) {
                   Text("Share Profile", color = Color.White)
               }

               TextButton(
                   onClick = {},
                   contentPadding = PaddingValues(6.dp),
                   modifier = Modifier
                       .weight(1f)
                       .clip(RoundedCornerShape(10.dp))
                       .background(Color.DarkGray),
                   border = BorderStroke(1.dp, Color.DarkGray),
                   shape = MaterialTheme.shapes.small

               ) {

                   Icon(
                       Icons.Default.PersonAdd,
                       modifier = Modifier.size(20.dp),
                       contentDescription = null,
                       tint = Color.White
                   )
               }
           }
       }

       item {
           HighLightGrid()
       }
       item {
           Spacer(Modifier.height(15.dp))
           ProfileTabs()
       }

   }*/