package com.example.jetpackcomposepracticedemo.presentation.ui.chatscreen

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.example.jetpackcomposepracticedemo.R
import com.example.jetpackcomposepracticedemo.presentation.ui.chatscreen.compnents.ChatData
import com.example.jetpackcomposepracticedemo.presentation.ui.chatscreen.compnents.ChatItem
import com.example.jetpackcomposepracticedemo.presentation.ui.searchscreen.components.InstagramSearchHeader

@Composable
fun ChatScreen() {

    val dummyChats = listOf(
        ChatData(R.drawable.profile_img, "Joshul_L", "Have a nice day", "Now"),
        ChatData(R.drawable.profile_img, "Joshul_L", "Have a nice day", "Now"),
        ChatData(R.drawable.profile_img, "Joshul_L", "Have a nice day", "Now"),
        ChatData(R.drawable.profile_img, "Joshul_L", "Have a nice day", "Now"),
        ChatData(R.drawable.profile_img, "Joshul_L", "Have a nice day", "Now"),
        ChatData(R.drawable.profile_img, "Joshul_L", "Have a nice day", "Now"),
        ChatData(R.drawable.profile_img, "Joshul_L", "Have a nice day", "Now"),
        ChatData(R.drawable.profile_img, "Joshul_L", "Have a nice day", "Now"),
        ChatData(R.drawable.profile_img, "Joshul_L", "Have a nice day", "Now"),
        ChatData(R.drawable.profile_img, "Joshul_L", "Have a nice day", "Now")

    )
    var query by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {

        InstagramSearchHeader(
            query = query,
            onQueryChange = { query = it },
            modifier = Modifier
        )
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            items(dummyChats) { item ->
                ChatItem(
                    profileImg = item.profileImg,
                    name = item.name,
                    time = item.time,
                    lastMsg = item.lastMsg
                )
            }
        }
    }

}
