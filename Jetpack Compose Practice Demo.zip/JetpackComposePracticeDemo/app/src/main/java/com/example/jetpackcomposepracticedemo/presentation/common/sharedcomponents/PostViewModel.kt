package com.example.jetpackcomposepracticedemo.presentation.common.sharedcomponents

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.jetpackcomposepracticedemo.data.repository.PostRepository
import com.example.jetpackcomposepracticedemo.presentation.ui.homescreen.components.PostItem
import com.example.jetpackcomposepracticedemo.presentation.ui.searchscreen.components.InstagramPost
import com.example.jetpackcomposepracticedemo.utils.Resource
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class PostViewModel : ViewModel() {

    private val repository = PostRepository()

    private val _postState =
        MutableStateFlow<Resource<List<InstagramPost>>>(Resource.Loading)
    val postState: StateFlow<Resource<List<InstagramPost>>> = _postState


    private val _feedPostState =
        MutableStateFlow<Resource<List<PostItem>>>(Resource.Loading)

    val feedPostState: StateFlow<Resource<List<PostItem>>> = _feedPostState


    fun getPosts() {
        viewModelScope.launch {
            repository.getPosts().collect { result ->
                _postState.value = result
            }
        }
    }

    fun getFeedPosts(){
        viewModelScope.launch {
            repository.getFeedPosts().collect{result->
                _feedPostState.value = result
            }
        }

    }
}