package com.example.jetpackcomposepracticedemo.presentation.ui.storyscreen

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.jetpackcomposepracticedemo.R

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun InstagramStoryScreen() {

    Column(modifier = Modifier
        .fillMaxSize()
        .background(Color.Black))
        {

        Box(
            modifier = Modifier
                .fillMaxSize()
                .clip(RectangleShape)
        ) {
            Image(
                painter = painterResource(R.drawable.img_3),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .padding(top = 8.dp, start = 12.dp, end = 12.dp)
            ) {
                LinearProgressIndicator(
                    progress = { 0.7f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(2.dp),
                    color = Color.White,
                    trackColor = Color.White.copy(alpha = 0.4f),
                    strokeCap = StrokeCap.Round,
                )

                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Profile Circular Image
                    Image(
                        painter = painterResource(R.drawable.profile_img),
                        contentDescription = null,
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape),
                        contentScale = ContentScale.Crop
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    // Text Info
                    Column(modifier = Modifier.weight(1f)) {
                        Text("CompanyName", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Sponsorisé", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                    }

                    // Top Right Icons
                    Icon(Icons.Default.MoreVert, "More", tint = Color.White, modifier = Modifier.size(20.dp))
//                    Spacer(modifier = Modifier.width(16.dp))
//                    Icon(Icons.Default.Close, "Close", tint = Color.White, modifier = Modifier.size(28.dp))
                }
            }
            Row(modifier = Modifier
                .fillMaxWidth()
                .background(Color.Black)
                .align(Alignment.BottomCenter)
                .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                OutlinedTextField(
                    value = "fdfdfdf",
                    onValueChange = {},
                    modifier = Modifier
                        .weight(1f)
                        .height(60.dp)
                        .padding(5.dp),
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,

                        focusedBorderColor = Color.DarkGray,
                        unfocusedBorderColor = Color.DarkGray,

                        focusedContainerColor = Color.Black,
                        unfocusedContainerColor = Color.Black,

                        cursorColor = Color.White

                )
                )
                Spacer(Modifier.width(10.dp))
                Icon(painterResource(R.drawable.ic_like), "Like", tint = Color.White)
                Spacer(Modifier.width(10.dp))
                Icon(painterResource(R.drawable.ic_comment), "Comment", tint = Color.White)
                Spacer(Modifier.width(10.dp))
                Icon(painterResource(R.drawable.ic_send), "Share", tint = Color.White)

            }
        }
    }

}