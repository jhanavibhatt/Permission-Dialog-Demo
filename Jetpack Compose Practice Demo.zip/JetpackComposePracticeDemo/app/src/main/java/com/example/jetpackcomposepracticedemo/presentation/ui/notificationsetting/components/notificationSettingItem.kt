package com.example.jetpackcomposepracticedemo.presentation.ui.notificationsetting.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight


@Composable
fun notificationSettingItem(title: String) {


    Row(
        modifier = Modifier.fillMaxWidth().background(Color.Black),
        verticalAlignment = Alignment.CenterVertically
    ) {
Column(
    modifier = Modifier.weight(1f)
) {
    Text(
        title,
        color = Color.White,
    )

}
        Icon(Icons.AutoMirrored.Filled.ArrowForwardIos, contentDescription = null, tint = Color.Gray)


    }

}

