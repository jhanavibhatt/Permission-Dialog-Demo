package com.example.jetpackcomposepracticedemo.presentation.ui.signinscreen

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.jetpackcomposepracticedemo.R
import com.example.jetpackcomposepracticedemo.presentation.ui.signinscreen.components.InfoItem
import com.example.jetpackcomposepracticedemo.ui.theme.BtnColor

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun SignInScreen() {

    var name by remember { mutableStateOf("") }
    var userName by remember { mutableStateOf("") }
    var bio by remember { mutableStateOf("") }


    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {

        Image(
            painterResource(R.drawable.ic_dp),
            contentDescription = null,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )

        Spacer(Modifier.height(10.dp))


        Text(//44414455544554455555544545400
            "Change profile Photo",
            color = BtnColor,
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )

        TextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Name") },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
            singleLine = true,
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Color.Black,
                unfocusedContainerColor = Color.Black,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                focusedIndicatorColor = Color.Gray,
                unfocusedIndicatorColor = Color.DarkGray,
                cursorColor = Color.White
            )
        )

        TextField(
            value = userName,
            onValueChange = { userName = it },
            label = { Text("Username") },
            modifier = Modifier.fillMaxWidth().padding(horizontal=12.dp),
            singleLine = true,
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Color.Black,
                unfocusedContainerColor = Color.Black,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                focusedIndicatorColor = Color.Gray,
                unfocusedIndicatorColor = Color.DarkGray,
                cursorColor = Color.White
            )
        )
        TextField(
            value = bio,
            onValueChange = { bio = it },
            label = { Text("Bio") },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
            singleLine = true,
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Color.Black,
                unfocusedContainerColor = Color.Black,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                focusedIndicatorColor = Color.Gray,
                unfocusedIndicatorColor = Color.DarkGray,
                cursorColor = Color.White
            )
        )

        Spacer(Modifier.height(10.dp))

        Text(
            "Add Links",
            color = Color.White,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)
        )

        Spacer(Modifier.height(15.dp))
        HorizontalDivider(Modifier.fillMaxWidth(), thickness = 1.dp, color = Color.Gray)

        Spacer(Modifier.height(15.dp))

        Text(
            "Profile information",
            color = Color.White,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)
        )

        Spacer(Modifier.height(10.dp))
        InfoItem("Page")
        Spacer(Modifier.height(10.dp))
        InfoItem("Category")
        Spacer(Modifier.height(10.dp))
        InfoItem("ContactOption")
        Spacer(Modifier.height(10.dp))
        InfoItem("Profile Display")
        Spacer(Modifier.height(20.dp))
        Text(
            "Personal information settings",
            color = BtnColor,
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)

        )
        Spacer(Modifier.height(10.dp))

        Text(
            "Personal information settings",
            color = BtnColor,
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)
        )

    }

}