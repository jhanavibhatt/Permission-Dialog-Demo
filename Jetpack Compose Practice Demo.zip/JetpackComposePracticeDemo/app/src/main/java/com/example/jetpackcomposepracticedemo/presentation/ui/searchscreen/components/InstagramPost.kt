package com.example.jetpackcomposepracticedemo.presentation.ui.searchscreen.components

data class InstagramPost(
    val id: Int,
    val imageUrl: String,
    val viewCountText: String? = null,
    val isVideo: Boolean = false,
    val isMultiPost: Boolean = false
)