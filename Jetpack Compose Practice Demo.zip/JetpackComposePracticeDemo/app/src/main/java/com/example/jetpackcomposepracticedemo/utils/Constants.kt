package com.example.jetpackcomposepracticedemo.utils

object Constants {
    const val JSON_BIN_BASE_URL = "https://api.jsonbin.io/"
}