package com.example.jetpackcomposepracticedemo.presentation.ui.loginscreen

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.jetpackcomposepracticedemo.R
import com.example.jetpackcomposepracticedemo.presentation.common.sharedcomponents.ClickableAnnotatedText
import com.example.jetpackcomposepracticedemo.presentation.common.sharedcomponents.CommonButton
import com.example.jetpackcomposepracticedemo.presentation.ui.loginscreen.components.AppTextField
import com.example.jetpackcomposepracticedemo.presentation.ui.loginscreen.components.FacebookLoginBtn
import com.example.jetpackcomposepracticedemo.ui.theme.BtnColor

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun LoginScreen() {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {


        Text(
            "Instagram",
            color = Color.White,
            fontStyle = FontStyle.Italic,
            style = MaterialTheme.typography.headlineLarge,
            modifier = Modifier.padding(bottom = 32.dp)
        )


        AppTextField(
            value = email,
            onValueChange = { email = it },
            hint = "username or email"
        )
        Spacer(Modifier.height(8.dp))

        AppTextField(
            value = password,
            onValueChange = { password = it },
            isPassword = true,
            hint = "password"
        )
        Text(
            "forgot password?", modifier = Modifier
                .fillMaxWidth()
                .wrapContentWidth(Alignment.End)
                .padding(5.dp), color = BtnColor, fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(18.dp))

        CommonButton(text = "Login", onClick = {})
        Spacer(Modifier.height(18.dp))


        FacebookLoginBtn(onClick = {})

        Spacer(Modifier.height(20.dp))


        Text(
            "OR",
            color = Color.DarkGray,
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.padding(vertical = 32.dp)
        )
        Spacer(Modifier.height(20.dp))
        ClickableAnnotatedText(
            normalText = stringResource(R.string.login_screen_annotated_text),
            clickableText = stringResource(R.string.sign_up_btn),
            clickableColor = Color.White,
            onClick = { }
        )

    }

}