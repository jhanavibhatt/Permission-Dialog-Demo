package com.example.jetpackcomposepracticedemo.presentation.ui.notificationscreen.components

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp

@Composable
fun NotificationText(username: String,message: String?,time: String) {
    val annotatedString = buildAnnotatedString {
        withStyle(style = SpanStyle(fontWeight = FontWeight.Bold, color = Color.White)) {
            append(username)
        }

        withStyle(style = SpanStyle(fontWeight = FontWeight.Normal, color = Color.White)) {
            append(message)
        }

        withStyle(style = SpanStyle(fontWeight = FontWeight.Normal, color = Color.Gray)) {
            append(time)
        }
    }

    Text(
        text = annotatedString,
        style = MaterialTheme.typography.bodyMedium,
        modifier = Modifier.padding(8.dp)
    )
}