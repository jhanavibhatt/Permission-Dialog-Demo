package com.example.jetpackcomposepracticedemo.presentation.ui.loginscreen

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.jetpackcomposepracticedemo.R
import com.example.jetpackcomposepracticedemo.presentation.common.sharedcomponents.ClickableAnnotatedText
import com.example.jetpackcomposepracticedemo.presentation.common.sharedcomponents.CommonButton


@Preview(showBackground = true, showSystemUi = true)
@Composable
fun QuickLoginScreen() {


    Column(modifier = Modifier.fillMaxSize().background(Color.Black).padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
        ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {


            Text(
                "Instagram",
                color = Color.White,
                fontStyle = FontStyle.Italic,
                style = MaterialTheme.typography.headlineLarge,
                modifier = Modifier.padding(bottom = 32.dp)
            )

            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(Color.Black)

            ) {
                Image(
                    painter = painterResource(R.drawable.profile_img),
                    "profile",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "Jacoh_w",
                color = Color.White,
                style = MaterialTheme.typography.titleMedium,
            )

            Spacer(Modifier.height(10.dp))
            CommonButton("Login", onClick = {})

            Spacer(Modifier.height(20.dp))

            Text(
                "Switch Account",
                color = Color(0xFF3797EF),
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(bottom = 16.dp)
            )
        }
        Spacer(Modifier.height(40.dp))

        ClickableAnnotatedText(
            normalText = stringResource(R.string.login_screen_annotated_text),
            clickableText = stringResource(R.string.sign_up_btn),
            clickableColor = Color.White,
            onClick = {  }
        )

    }

}