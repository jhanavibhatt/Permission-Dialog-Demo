package com.example.jetpackcomposepracticedemo.presentation.ui.homescreen.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.jetpackcomposepracticedemo.R
import com.example.jetpackcomposepracticedemo.presentation.navigation.AppRoute

@Composable
fun StoryGrid(navController: NavController) {
    val storyList = listOf(
        StoryData("your story", R.drawable.profile_img, false),
        StoryData("your story", R.drawable.profile_img, isLive = true),
        StoryData("your story", R.drawable.profile_img, false),
        StoryData("your story", R.drawable.profile_img, false),
        StoryData("your story", R.drawable.profile_img, false),
        StoryData("your story", R.drawable.profile_img, false)
    )

    Column(modifier = Modifier.fillMaxWidth()) {
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(1.dp),
            contentPadding = PaddingValues(horizontal = 4.dp),
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.Black)
        ) {
            items(storyList) { item ->
                StoryItem(
                    title = item.title,
                    image = item.image,
                    isLive = item.isLive,
                    onClick = {
                        navController.navigate(AppRoute.InstagramStoryScreen)
                    }
                )
            }
        }
    }
}