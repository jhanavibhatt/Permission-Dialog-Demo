package com.example.jetpackcomposepracticedemo.presentation.common.sharedcomponents

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp

@Composable
fun ClickableAnnotatedText(
    normalText: String,
    clickableText: String,
    onClick: () -> Unit,
    fontSize: TextUnit = 16.sp,
    clickableColor: Color = Color(0xFF3F51B5),
    normalTextColor: Color = Color.DarkGray
) {

    val annotatedText = buildAnnotatedString {

        withStyle(
            style = SpanStyle(color = Color.DarkGray, fontWeight = FontWeight.Bold, fontSize = fontSize)
        ) {
            append("$normalText ")
        }

        pushLink(
            LinkAnnotation.Clickable(
                tag = "CLICK",
                styles = TextLinkStyles(
                    style = SpanStyle(
                        color = clickableColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = fontSize
                    )
                ),
                linkInteractionListener = {
                    onClick()
                }
            )
        )

        append(clickableText)
        pop()
    }

    Text(
        text = annotatedText
    )
}