package com.example.jetpackcomposepracticedemo.presentation.ui.notificationscreen.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.jetpackcomposepracticedemo.R
import com.example.jetpackcomposepracticedemo.presentation.common.sharedcomponents.CommonButton
import com.example.jetpackcomposepracticedemo.ui.theme.BtnColor


@Composable
fun NotificationItem(notificationContent: NotificationData) {

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.Black)
            .padding(10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {


        Box(
            modifier = Modifier
                .size(60.dp)
                .padding(6.dp)
                .clip(CircleShape)
                .background(Color.Black)

        ) {
            Image(
                painter = painterResource(R.drawable.profile_img),
                "profile",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        }

        if (notificationContent.isFollowing) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 12.dp)
            ) {
                NotificationText(username = notificationContent.username, message = " Started following you. ", time = notificationContent.time)

            }
            OutlinedButton(
                onClick = {},
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 0.dp)
            ) {
                Text(
                    "Message", color = Color.White, style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
            }
        } else if (notificationContent.isRequested) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 12.dp)
            ) {
                NotificationText(username = notificationContent.username, message = " Requested to  following you. ", time = notificationContent.time)

            }
            Button(onClick = {
            },
                colors = ButtonDefaults.buttonColors(
                    containerColor = BtnColor,
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(15)
            ) {
                Text(text = "Confirm")
            }

        }
        else {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 12.dp)
            ) {
                NotificationText(username = notificationContent.username, message = "", time = notificationContent.time)

            }
            Button(onClick = {
            },
                colors = ButtonDefaults.buttonColors(
                    containerColor = BtnColor,
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(15)
            ) {
                Text(text = "Follow")
            }
        }

    }


}