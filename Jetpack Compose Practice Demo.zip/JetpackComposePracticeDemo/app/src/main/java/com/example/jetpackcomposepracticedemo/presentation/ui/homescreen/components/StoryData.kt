package com.example.jetpackcomposepracticedemo.presentation.ui.homescreen.components

data class StoryData(
    val title: String,
    val image: Int,
    val isLive: Boolean
)

