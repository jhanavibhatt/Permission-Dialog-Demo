package com.example.jetpackcomposepracticedemo.data.repository

import com.example.jetpackcomposepracticedemo.data.remote.RetrofitClient
import com.example.jetpackcomposepracticedemo.presentation.ui.homescreen.components.PostItem
import com.example.jetpackcomposepracticedemo.presentation.ui.searchscreen.components.InstagramPost
import com.example.jetpackcomposepracticedemo.utils.Resource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn

class PostRepository {

    fun getPosts(): Flow<Resource<List<InstagramPost>>> = flow {

        emit(Resource.Loading)

        try {
            val response = RetrofitClient.api.getPosts()

            if (response.isSuccessful && response.body() != null) {

                val posts = response.body()!!.posts
                emit(Resource.Success(posts))

            } else {
                emit(
                    Resource.Error(
                        message = response.message(),
                        code = response.code()
                    )
                )
            }

        } catch (e: Exception) {
            emit(Resource.Error(e.message ?: "Unknown error"))
        }

    }.flowOn(Dispatchers.IO)


    fun getFeedPosts(): Flow<Resource<List<PostItem>>> = flow {
        emit(Resource.Loading)

        try {
            val response = RetrofitClient.api.getFeedPosts()

            if (response.isSuccessful && response.body() != null) {
               val feedPosts = response.body()!!.FeedPost
                emit(Resource.Success(feedPosts))
            }else{
                emit(
                    Resource.Error(
                        message = response.message(),
                        code = response.code()
                    )
                )
            }
        } catch (e: Exception) {
            emit(Resource.Error(e.message ?: "Unknown error"))
        }
    }.flowOn(Dispatchers.IO)

}