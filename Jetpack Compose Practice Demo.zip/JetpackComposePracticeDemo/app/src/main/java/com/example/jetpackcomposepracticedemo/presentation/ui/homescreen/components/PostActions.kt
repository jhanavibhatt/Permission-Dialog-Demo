package com.example.jetpackcomposepracticedemo.presentation.ui.homescreen.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.jetpackcomposepracticedemo.R

@Composable
fun PostActions(post: PostItem) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(modifier = Modifier.weight(1f)) {
            Icon(painterResource(R.drawable.ic_like), "Like", tint = Color.White)
            Spacer(Modifier.width(16.dp))
            Icon(painterResource(R.drawable.ic_comment), "Comment", tint = Color.White)
            Spacer(Modifier.width(16.dp))
            Icon(painterResource(R.drawable.ic_send), "Share", tint = Color.White)
        }

        // Dots only for carousel
        if (post.isMultiPost) {
            val pagerState = rememberPagerState(pageCount = { post.images.size })
            Row(
                Modifier.weight(1f),
                horizontalArrangement = Arrangement.Center
            ) {
                repeat(post.images.size) { iteration ->
                    val color =
                        if (pagerState.currentPage == iteration) Color(0xFF3897F0) else Color.Gray
                    Box(
                        modifier = Modifier
                            .padding(2.dp)
                            .clip(CircleShape)
                            .background(color)
                            .size(6.dp)
                    )
                }
            }
        } else {
            Spacer(Modifier.weight(1f))
        }

        Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.CenterEnd) {
            Icon(Icons.Default.BookmarkBorder, "Save", tint = Color.White)
        }


    }

}