package com.example.jetpackcomposepracticedemo.presentation.ui.reelscreen.components

data class Reel(
    val id: Int,
    val videoRes: Int,
    val username: String,
    val caption: String,
    val audioName: String,
    val likes: String,
    val comments: String
)