package com.example.jetpackcomposepracticedemo.presentation.ui.youractivityscreen.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp


@Preview(showBackground = true, showSystemUi = true)
@Composable
fun WeeklyBarChart() {

    val data = listOf(
        "Tue" to 40,
        "Wed" to 25,
        "Thu" to 60,
        "Fri" to 20,
        "Sat" to 80,
        "Sun" to 100,
        "Today" to 25
    )

    val maxValue = data.maxOf { it.second }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(150.dp)
            .padding(horizontal = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Bottom
    ) {

        data.forEach { (label, value) ->

            val barHeight = (value / maxValue.toFloat()) * 120

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Bottom
            ) {

                Box(
                    modifier = Modifier
                        .width(24.dp)
                        .height(barHeight.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(
                            if (label == "Today") Color(0xFF1976D2) else Color(0xFF90CAF9)
                        )
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = label,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (label == "Today") Color.Black else Color.Gray
                )
            }
        }
    }
}