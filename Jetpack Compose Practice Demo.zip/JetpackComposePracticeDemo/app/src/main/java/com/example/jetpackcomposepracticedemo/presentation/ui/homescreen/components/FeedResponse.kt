package com.example.jetpackcomposepracticedemo.presentation.ui.homescreen.components

data class FeedResponse(
    val FeedPost: List<PostItem>
)

data class PostItem(
    val id: Int,
    val username: String,
    val profileImageUrl: String,
    val isVerified: Boolean,
    val location: String,
    val imageUrl: String,
    val caption: String,
    val viewCountText: String?,
    val isVideo: Boolean,
    val isMultiPost: Boolean,
    val images: List<String> = emptyList()
)