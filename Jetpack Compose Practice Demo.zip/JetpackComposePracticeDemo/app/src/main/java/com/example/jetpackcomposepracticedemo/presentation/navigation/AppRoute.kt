package com.example.jetpackcomposepracticedemo.presentation.navigation

import kotlinx.serialization.Serializable

@Serializable
sealed class AppRoute {
    @Serializable
    data object HomeScreen : AppRoute()
    @Serializable
    data object ReelScreen : AppRoute()
    @Serializable
    data object ChatScreen : AppRoute()
    @Serializable
    data object ProfileScreen : AppRoute()
    @Serializable
    data object SearchScreen : AppRoute()

    @Serializable
    data object NotificationScreen : AppRoute()

     @Serializable
    data object InstagramStoryScreen : AppRoute()

}



