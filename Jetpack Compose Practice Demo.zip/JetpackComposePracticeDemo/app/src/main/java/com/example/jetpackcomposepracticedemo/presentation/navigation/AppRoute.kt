package com.example.jetpackcomposepracticedemo.presentation.navigation

import kotlinx.serialization.Serializable

@Serializable
sealed class AppRoute {
    @Serializable
    data object HomeScreen : AppRoute()

    @Serializable
    data class ReelScreen(val startIndex: Int = -1) : AppRoute()

    @Serializable
    data object ChatScreen : AppRoute()

    @Serializable
    data object ProfileScreen : AppRoute()

    @Serializable
    data object SearchScreen : AppRoute()

    @Serializable
    data object NotificationScreen : AppRoute()

    @Serializable
    data object InstagramStoryScreen : AppRoute()

    @Serializable
    data object EditProfileScreen : AppRoute()

    @Serializable
    data object SettingsScreen : AppRoute()

    @Serializable
    data object SettingAndActivityScreen : AppRoute()

    @Serializable
    data object NotificationSettingScreen : AppRoute()


    @Serializable
    data object YourActivityScreen : AppRoute()


}



