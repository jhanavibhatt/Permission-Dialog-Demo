package com.example.jetpackcomposepracticedemo.presentation.ui.settingandactivity

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.jetpackcomposepracticedemo.R
import com.example.jetpackcomposepracticedemo.presentation.common.sharedcomponents.ClickableAnnotatedText
import com.example.jetpackcomposepracticedemo.presentation.navigation.AppRoute
import com.example.jetpackcomposepracticedemo.presentation.ui.searchscreen.components.InstagramSearchHeader
import com.example.jetpackcomposepracticedemo.presentation.ui.settingandactivity.components.MetaItem
import com.example.jetpackcomposepracticedemo.presentation.ui.settingandactivity.components.SettingItems
import com.example.jetpackcomposepracticedemo.ui.theme.BtnColor

@Composable
fun SettingAndActivity(navController: NavController) {


    var query by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(12.dp)
    ) {
        item {
            InstagramSearchHeader(query = query, onQueryChange = { query = it })
        }
        item {
            Spacer(Modifier.height(10.dp))
            Text("your Account", color = Color.Gray, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
        }
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {

                Image(
                    painter = painterResource(R.drawable.ic_account),
                    contentDescription = null,
                    Modifier.size(40.dp)
                )

                Column(
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        "Accounts Centre",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        "Password, security, personal details, ad\n" +
                                "preferences",
                        color = Color.Gray,
                        style = MaterialTheme.typography.titleSmall
                    )
                }
                Icon(Icons.AutoMirrored.Filled.ArrowForwardIos, contentDescription = null, tint = Color.White)

            }
        }
        item {
            Spacer(Modifier.height(10.dp))
            ClickableAnnotatedText(
                normalText = "Manage your connected experiences and accounts settings across Meta technologies. ",
                clickableText = "Learn more",
                clickableColor = Color.Blue,
                normalTextColor = Color.Gray,
                onClick = { }
            )
            Spacer(Modifier.height(10.dp))
        }
        item {
            HorizontalDivider(modifier = Modifier, 2.dp, Color.Gray)
            Spacer(Modifier.height(10.dp))
            Text(
                "How you use instagram",
                color = Color.Gray,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium
            )

            Spacer(Modifier.height(10.dp))
        }
        item {
            SettingItems("Saved", R.drawable.ic_save, onClick = {})
            SettingItems("Archive", R.drawable.ic_archive, onClick = {})
            SettingItems("Your Activity", R.drawable.ic_activity, onClick = {
                navController.navigate(AppRoute.YourActivityScreen)
            })
            SettingItems("Notification", R.drawable.ic_notification, onClick = {
                navController.navigate(AppRoute.NotificationSettingScreen)
            })
            SettingItems("Time Management", R.drawable.ic_time, onClick = {})

        }
        item {
            Spacer(Modifier.height(10.dp))
            HorizontalDivider(modifier = Modifier, 2.dp, Color.Gray)
            Spacer(Modifier.height(10.dp))
            Text(
                "Who can see your content",
                color = Color.Gray,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(Modifier.height(10.dp))
        }
        item {
            SettingItems("Account Privacy", R.drawable.ic_privacy, onClick = {}, "private")
            SettingItems("Close Friends", R.drawable.ic_close_frd, onClick = {}, "0")
            SettingItems("Crossposting", R.drawable.ic_crosspos, onClick = {})
            SettingItems("Blocked", R.drawable.ic_block, onClick = {})
            SettingItems("Story and Profile", R.drawable.ic_story_loc, onClick = {})
        }
        item {


            Spacer(Modifier.height(10.dp))
            HorizontalDivider(modifier = Modifier, 2.dp, Color.Gray)
            Spacer(Modifier.height(10.dp))
            Text(
                "How others can interact with you",
                color = Color.Gray,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(Modifier.height(10.dp))
        }
        item {
            SettingItems("Activity Status", R.drawable.ic_status, onClick = {})
            SettingItems("Tags and mentions", R.drawable.ic_tag, onClick = {})
            SettingItems("Comments", R.drawable.ic_comment, onClick = {})
            SettingItems("Restricted", R.drawable.ic_restrict, onClick = {})
            SettingItems("Limit interactions", R.drawable.ic_about, onClick = {})
            SettingItems("Hidden Words", R.drawable.ic_hidden, onClick = {})
            SettingItems("Follow and invite friends", R.drawable.ic_discover, onClick = {})
        }
        item {
            Spacer(Modifier.height(10.dp))
            HorizontalDivider(modifier = Modifier, 2.dp, Color.Gray)
            Spacer(Modifier.height(10.dp))
            Text(
                "What you see",
                color = Color.Gray,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(Modifier.height(10.dp))
        }
        item {
            SettingItems("Favorites", R.drawable.ic_fav, onClick = {})
            SettingItems("Muted Accounts", R.drawable.ic_save, onClick = {})
            SettingItems("Content Preferences", R.drawable.ic_content_pref, onClick = {})
            SettingItems("Like and share counts", R.drawable.ic_like_share, onClick = {})
            SettingItems("Subscriptions", R.drawable.ic_like_share, onClick = {})
        }
        item {
            Spacer(Modifier.height(10.dp))
            HorizontalDivider(modifier = Modifier, 2.dp, Color.Gray)
            Spacer(Modifier.height(10.dp))
            Text(
                "Your app and media",
                color = Color.Gray,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(Modifier.height(10.dp))
        }
        item {
            SettingItems("Device Permission", R.drawable.ic_device, onClick = {})
            SettingItems("Archiving and Downloading", R.drawable.ic_downloading, onClick = {})
            SettingItems("Accessibility", R.drawable.ic_accesscibility, onClick = {})
            SettingItems("Language and translation", R.drawable.ic_lang_trans, onClick = {})
            SettingItems("Data usage and media quality ", R.drawable.ic_datausage, onClick = {})
            SettingItems("App Website permision", R.drawable.ic_webapp, onClick = {})
        }
        item {
            Spacer(Modifier.height(10.dp))
            HorizontalDivider(modifier = Modifier, 2.dp, Color.Gray)
            Spacer(Modifier.height(10.dp))
            Text(
                "Family center",
                color = Color.Gray,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(Modifier.height(10.dp))
        }
        item {
            SettingItems("supervision for Teen Accounts", R.drawable.ic_supervisor, onClick = {})
        }
        item {
            Spacer(Modifier.height(10.dp))
            HorizontalDivider(modifier = Modifier, 2.dp, Color.Gray)
            Spacer(Modifier.height(10.dp))
            Text(
                "Your insights and tools",
                color = Color.Gray,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(Modifier.height(10.dp))
        }
        item {
            SettingItems("Account type and tools", R.drawable.ic_typetool, onClick = {})
            SettingItems("Meta Verified", R.drawable.ic_verifie, onClick = {}, "Not subscribed")
        }

        item {
            Spacer(Modifier.height(10.dp))
            HorizontalDivider(modifier = Modifier, 2.dp, Color.Gray)
            Spacer(Modifier.height(10.dp))
            Text(
                "Your orders and fundraisers",
                color = Color.Gray,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(Modifier.height(10.dp))
        }
        item {
            SettingItems("Orders and payments", R.drawable.ic_payment, onClick = {})
        }
        item {
            Spacer(Modifier.height(10.dp))
            HorizontalDivider(modifier = Modifier, 2.dp, Color.Gray)
            Spacer(Modifier.height(10.dp))
            Text(
                "More info and support",
                color = Color.Gray,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(Modifier.height(10.dp))
        }
        item {
            SettingItems("Help", R.drawable.ic_help, onClick = {})
            SettingItems("Meta AI support assistance", R.drawable.ic_metaassist, onClick = {})
            SettingItems("Privacy center", R.drawable.ic_privacycenter, onClick = {})
            SettingItems("Account  status", R.drawable.ic_accstatus, onClick = {})
            SettingItems("About", R.drawable.ic_about, onClick = {})
        }
        item {
            Spacer(Modifier.height(10.dp))
            HorizontalDivider(modifier = Modifier, 2.dp, Color.Gray)
            Spacer(Modifier.height(10.dp))
            Text(
                "Also from Meta",
                color = Color.Gray,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(Modifier.height(10.dp))
        }
        item {
            MetaItem("Meta AI", "Get answers, advice and generate images", R.drawable.ic_metaassist, onClick = {})
            Spacer(Modifier.height(10.dp))
            MetaItem("Threads", "Share ideas and join conversations", R.drawable.ic_threads, onClick = {})
            Spacer(Modifier.height(10.dp))
            MetaItem("Edits", "create videos with powerful editing tools", R.drawable.ic_edits, onClick = {})
            Spacer(Modifier.height(10.dp))
            SettingItems("More fromMeta", R.drawable.ic_meta, onClick = {})

        }
        item {

            Spacer(Modifier.height(10.dp))
            HorizontalDivider(modifier = Modifier, 2.dp, Color.Gray)
            Spacer(Modifier.height(10.dp))
        }
        item {
            Text(
                "Login",
                style = MaterialTheme.typography.titleMedium,
                color = Color.Gray
            )
            Text(
                "Add account",
                style = MaterialTheme.typography.titleMedium,
                color = BtnColor
            )
            Text(
                "Log out",
                style = MaterialTheme.typography.titleMedium,
                color = Color.Red
            )
        }

    }
}