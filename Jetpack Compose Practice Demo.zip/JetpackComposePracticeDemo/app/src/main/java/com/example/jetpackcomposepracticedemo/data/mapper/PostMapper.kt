package com.example.jetpackcomposepracticedemo.data.mapper

import com.example.jetpackcomposepracticedemo.presentation.ui.reelscreen.components.Reel
import com.example.jetpackcomposepracticedemo.presentation.ui.searchscreen.components.InstagramPost

fun InstagramPost.toReel(): Reel {
    return Reel(
        id = id,
        videoRes = imageUrl,
        username = "user_$id",
        caption = "Sample caption $id",
        audioName = "Original Audio",
        likes = "10K",
        comments = "1K",
    )
}
