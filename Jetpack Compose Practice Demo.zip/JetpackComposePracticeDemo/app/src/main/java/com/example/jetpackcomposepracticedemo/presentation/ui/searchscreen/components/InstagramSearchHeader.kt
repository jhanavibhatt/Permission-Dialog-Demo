package com.example.jetpackcomposepracticedemo.presentation.ui.searchscreen.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SearchBar
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.jetpackcomposepracticedemo.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InstagramSearchHeader(
    query: String,
    onQueryChange: (String) -> Unit,
) {


    TextField(
        value = query,
        onValueChange = onQueryChange,
        placeholder = { Text("Search", color = Color.Gray,
            fontSize = 14.sp) },
        singleLine = true,

        leadingIcon = {
            Icon(Icons.Rounded.Search, contentDescription = null, tint = Color.White)
        },

        trailingIcon = {
            if (query.isNotEmpty()) {
                Icon(
                    imageVector = Icons.Rounded.Close,
                    contentDescription = null,
                    tint = Color.White
                )
            }
        },
        textStyle = TextStyle(
            color = Color.White,   // input text color
            fontSize = 16.sp       // input text size
        ),
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp).border(1.dp, Color.DarkGray,RoundedCornerShape(16.dp)),

        shape = RoundedCornerShape(16.dp),

        colors = TextFieldDefaults.colors(
            focusedContainerColor = Color(0xFF353839),
            unfocusedContainerColor = Color.DarkGray,
        )
        )
}//4E545C