package com.example.jetpackcomposepracticedemo.data.remote.api

import com.example.jetpackcomposepracticedemo.presentation.ui.homescreen.components.FeedResponse
import com.example.jetpackcomposepracticedemo.presentation.ui.searchscreen.components.PostResponse
import retrofit2.Response
import retrofit2.http.GET

interface ApiService {
    @GET("v3/b/69e84e7caaba88219724cccf?meta=false")
    suspend fun getPosts(): Response<PostResponse>

    @GET("v3/b/69e8b124aaba882197268663?meta=false")
    suspend fun getFeedPosts(): Response<FeedResponse>
}

