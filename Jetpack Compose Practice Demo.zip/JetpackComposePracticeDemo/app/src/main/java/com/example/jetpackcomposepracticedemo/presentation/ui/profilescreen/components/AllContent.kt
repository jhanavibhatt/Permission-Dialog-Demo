package com.example.jetpackcomposepracticedemo.presentation.ui.profilescreen.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.staggeredgrid.LazyStaggeredGridScope
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.itemsIndexed
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.jetpackcomposepracticedemo.R


fun LazyStaggeredGridScope.AllContent() {

        val contentList = listOf(
            ContentData(1, R.drawable.img_1, isMultiPost = true),
            ContentData(2, R.drawable.img_2, isVideo = true),
            ContentData(2, R.drawable.img_2),
            ContentData(2, R.drawable.img_2),
            ContentData(2, R.drawable.img_2),
            ContentData(2, R.drawable.img_2),
            ContentData(2, R.drawable.img_2),
            ContentData(2, R.drawable.img_3, isVideo = true),
            ContentData(2, R.drawable.img_3),
            ContentData(2, R.drawable.img_3),
            ContentData(2, R.drawable.img_3),
            ContentData(1, R.drawable.img_1, isMultiPost = true),
            ContentData(2, R.drawable.img_2),
            ContentData(2, R.drawable.img_2),
            ContentData(2, R.drawable.img_2),
            ContentData(2, R.drawable.img_2),
            ContentData(2, R.drawable.img_2),
            ContentData(2, R.drawable.img_2),
            ContentData(2, R.drawable.img_3),
            ContentData(2, R.drawable.img_3),
            ContentData(2, R.drawable.img_3),
            ContentData(2, R.drawable.img_3)
        )

        itemsIndexed(contentList) { index, item ->
            val patternIndex = index % 18
            val isLarge = (patternIndex == 2 || patternIndex == 11 || patternIndex == 7)
            val itemHeight = when {
            item.isVideo -> 300.dp   // 🎬 video = big
            patternIndex == 2 || patternIndex == 7 || patternIndex == 11 -> 300.dp
            else -> 200.dp
        }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(itemHeight)
                    .clip(RectangleShape)
            ) {

                Image(
                    painterResource(item.imageRes),
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                if (item.isMultiPost) {

                    Icon(
                        painterResource(R.drawable.ic_layers),
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(8.dp)
                            .size(20.dp)
                    )
                }
                if (item.isVideo) {
                    Icon(
                        painterResource(R.drawable.ic_video),
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(8.dp)
                            .size(20.dp)
                    )
                }
            }
            }
}