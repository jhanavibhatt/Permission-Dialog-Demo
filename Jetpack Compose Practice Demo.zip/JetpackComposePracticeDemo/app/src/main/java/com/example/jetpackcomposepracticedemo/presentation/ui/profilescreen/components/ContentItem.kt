package com.example.jetpackcomposepracticedemo.presentation.ui.profilescreen.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.itemsIndexed
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.jetpackcomposepracticedemo.R

@Composable
fun ContentItem(content: List<ContentData>) {
    LazyVerticalStaggeredGrid(
        columns = StaggeredGridCells.Fixed(3),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 0.5.dp),
        contentPadding = PaddingValues(bottom = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(1.dp),
        verticalItemSpacing = 1.dp
    ) {
        itemsIndexed(content) { index, content ->


            val patternIndex = index % 18
            val isRightColumnBig = (patternIndex == 2)
            val isLeftColumnBig = (patternIndex == 11)

            val isMiddleColumnBig = (patternIndex == 7)

            val itemHeight = if (isRightColumnBig || isLeftColumnBig || isMiddleColumnBig) {
                400.dp
            } else {
                200.dp
            }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(itemHeight)
                    .clip(RectangleShape)
            ) {

                Image(
                    painterResource(content.imageRes),
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )

                if(content.isMultiPost) {

                    Icon(
                        painterResource(R.drawable.ic_layers),
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(8.dp)
                            .size(20.dp)
                    )
                }

               if (content.isVideo) {
                   Icon(
                       painterResource(R.drawable.ic_video),
                       contentDescription = null,
                       tint = Color.White,
                       modifier = Modifier
                           .align(Alignment.TopEnd)
                           .padding(8.dp)
                           .size(20.dp)
                   )
               }

            }
        }
    }


}