package com.example.jetpackcomposepracticedemo.presentation.ui.profilescreen.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.jetpackcomposepracticedemo.R

@Composable
fun ProfileDrawerContent(onClose: () -> Unit,
                         onNavigateToSettings: () -> Unit,
                         onNavigateToYourActivity: () -> Unit) {

    Column(
        modifier = Modifier
            .fillMaxHeight()
            .width(280.dp)
            .background(Color.Black)
            .padding(16.dp)
    ) {

        Text(
            "Joshual_l",
            color = Color.White,
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.padding(5.dp),

            )
        DrawerItem("Archive",R.drawable.ic_archive, onClick = {})
        Spacer(Modifier.height(15.dp))
        DrawerItem("Your Activity",R.drawable.ic_activity, onClick = {
            onClose()
            onNavigateToYourActivity()
        })
        Spacer(Modifier.height(15.dp))
        DrawerItem("Nametag",R.drawable.ic_nametag, onClick = {})
        Spacer(Modifier.height(15.dp))
        DrawerItem("Saved",R.drawable.ic_save, onClick = {})
        Spacer(Modifier.height(15.dp))
        DrawerItem("Close Friends",R.drawable.ic_close, onClick = {})
        Spacer(Modifier.height(15.dp))
        DrawerItem("Discover People",R.drawable.ic_discover, onClick = {})
        Spacer(Modifier.height(15.dp))
        DrawerItem("Open Facebook",R.drawable.ic_fb_, onClick = {})
        Spacer(Modifier.weight(1f))
        DrawerItem("Settings", R.drawable.ic_setting, onClick = {
            onClose()
            onNavigateToSettings()})


    }


}
@Composable
fun DrawerItem(title: String, icon: Int, onClick: () -> Unit) {
    Row(modifier = Modifier.fillMaxWidth().clickable { onClick() },
        verticalAlignment = Alignment.CenterVertically)  {

        Icon(
            painter = painterResource(icon),
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.padding(5.dp)
        )
        Spacer(Modifier.width(5.dp))
    Text(
        text = title,
        color = Color.White,
        style = MaterialTheme.typography.bodyLarge,
        modifier = Modifier.padding(5.dp),
    )


    }

}