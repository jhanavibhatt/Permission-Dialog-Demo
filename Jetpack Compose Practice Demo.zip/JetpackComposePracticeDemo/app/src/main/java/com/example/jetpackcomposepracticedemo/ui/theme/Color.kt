package com.example.jetpackcomposepracticedemo.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

val GradientStart = Color(0xFFFBAA47)
val GradientMiddle = Color(0xFFD91A46)
val GradientEnd = Color(0xFFA60F93)

val liveGradientStart = Color(0xFFE20337)
val liveGradientMiddle = Color(0xFFC60188)
val liveGradientEnd = Color(0xFF7700C3)

val BtnColor = Color(0xFF3797EF)