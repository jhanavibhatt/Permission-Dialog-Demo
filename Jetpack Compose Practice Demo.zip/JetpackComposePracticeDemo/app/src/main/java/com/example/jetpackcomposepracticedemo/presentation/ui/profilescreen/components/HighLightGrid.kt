package com.example.jetpackcomposepracticedemo.presentation.ui.profilescreen.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.jetpackcomposepracticedemo.R

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun HighLightGrid() {
    val highlightList = listOf(
        HighlightData("New", true, null),
        HighlightData("Trip", false, R.drawable.profile_img),
        HighlightData("Food", false, R.drawable.profile_img),
        HighlightData("Friends", false, R.drawable.profile_img),
        HighlightData("Work", false, R.drawable.profile_img)
    )
    Column(modifier = Modifier.fillMaxWidth()) {
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(1.dp),
            contentPadding = PaddingValues(horizontal = 4.dp),
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.Black)
        ) {
            items(highlightList) { item ->
                HighLightItem(
                    title = item.title,
                    isNew = item.isNew,
                    image = item.image
                )
            }
        }
    }
}


