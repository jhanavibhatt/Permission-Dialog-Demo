package com.example.jetpackcomposepracticedemo.presentation.ui.homescreen.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.jetpackcomposepracticedemo.R
import com.example.jetpackcomposepracticedemo.ui.theme.GradientEnd
import com.example.jetpackcomposepracticedemo.ui.theme.GradientMiddle
import com.example.jetpackcomposepracticedemo.ui.theme.GradientStart
import com.example.jetpackcomposepracticedemo.ui.theme.liveGradientEnd
import com.example.jetpackcomposepracticedemo.ui.theme.liveGradientMiddle
import com.example.jetpackcomposepracticedemo.ui.theme.liveGradientStart

@Composable
fun StoryItem(title: String, image: Int, isLive: Boolean,onClick: () -> Unit) {
    val brush = if (isLive) {
        Brush.linearGradient(
            colors = listOf(liveGradientStart, liveGradientMiddle, liveGradientEnd)
        )
    } else {
        Brush.linearGradient(
            colors = listOf(GradientStart, GradientMiddle, GradientEnd)
        )

    }
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(horizontal = 6.dp)
            .clickable { onClick() }//  spacing between items
    ) {

        Box(
            contentAlignment = Alignment.Center
        ) {

            Box(
                modifier = Modifier
                    .size(80.dp)
                    .background(brush, CircleShape)
            )

            // Inner black circle (ring thickness)
            Box(
                modifier = Modifier
                    .size(74.dp)
                    .background(Color.Black, CircleShape)
            )

            // Profile Image
            Image(
                painter = painterResource(image),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(66.dp)
                    .clip(CircleShape)
            )

            // LIVE badge
            if (isLive) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .offset(y = 6.dp)
                        .background(Brush.linearGradient(
                            colors = listOf(Color(0xFFC90083),Color(0xFFD22463) , Color(0xFFE10038))
                        ), RoundedCornerShape(6.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "LIVE",
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = title,
            color = Color.White,
            fontSize = 12.sp
        )
    }
}

