package com.example.jetpackcomposepracticedemo.presentation.ui.profilescreen.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun ProfileButtons(onEditProfileClick: () -> Unit ) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(10.dp),
        horizontalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        TextButton(
            onClick = {onEditProfileClick()},
            contentPadding = PaddingValues(6.dp),
            modifier = Modifier
                .weight(2f)
                .clip(RoundedCornerShape(10.dp))
                .background(Color.DarkGray),
        )


        {
            Text("Edit Profile", color = Color.White)
        }
        TextButton(
            onClick = {},
            contentPadding = PaddingValues(6.dp),
            modifier = Modifier
                .weight(2f)
                .clip(RoundedCornerShape(10.dp))
                .background(Color.DarkGray),
            border = BorderStroke(1.dp, Color.DarkGray),
            shape = MaterialTheme.shapes.small

        ) {
            Text("Share Profile", color = Color.White)
        }

        TextButton(
            onClick = {},
            contentPadding = PaddingValues(6.dp),
            modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(10.dp))
                .background(Color.DarkGray),
            border = BorderStroke(1.dp, Color.DarkGray),
            shape = MaterialTheme.shapes.small

        ) {

            Icon(
                Icons.Default.PersonAdd,
                modifier = Modifier.size(20.dp),
                contentDescription = null,
                tint = Color.White
            )
        }
    }
}