package com.example.jetpackcomposepracticedemo.presentation.ui.youractivityscreen

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.jetpackcomposepracticedemo.R
import com.example.jetpackcomposepracticedemo.presentation.ui.notificationsetting.components.notificationSettingItem
import com.example.jetpackcomposepracticedemo.presentation.ui.youractivityscreen.components.WeeklyBarChart

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun YourActivityScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(15.dp)

    ) {

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.Black)
                .padding(horizontal = 12.dp),

            ) {

            Text(
                "Time  on Instagram",
                color = Color.White,
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.weight(1f)
            )
            Image(painterResource(R.drawable.ic_about), contentDescription = null)
        }

        Spacer(Modifier.padding(10.dp))

        Text(
            "1h55m",
            color = Color.White,
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
        Text(
            "Daily Average",
            color = Color.White,
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
        Text(
            "Average time you spent per day using the Instagram app on \n this devices in  the last week ",
            color = Color.White,
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.align(Alignment.CenterHorizontally)

        )
        Spacer(Modifier.height(10.dp))

        WeeklyBarChart()

        Spacer(Modifier.height(15.dp))

        Text(
            "Manage  Your Time",
            color = Color.White,
            style = MaterialTheme.typography.titleMedium,
        )
        Spacer(Modifier.height(15.dp))

        notificationSettingItem(
            "Set reminder to take breaks"
        )
        Spacer(Modifier.height(10.dp))
        notificationSettingItem(
            "Set data time limit"
        )
        Spacer(Modifier.height(10.dp))
        notificationSettingItem(
            "Notification Settings"
        )
    }

}