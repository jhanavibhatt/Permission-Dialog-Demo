package com.example.jetpackcomposepracticedemo.presentation.ui.notificationscreen

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import com.example.jetpackcomposepracticedemo.R
import com.example.jetpackcomposepracticedemo.presentation.ui.notificationscreen.components.NotificationData
import com.example.jetpackcomposepracticedemo.presentation.ui.notificationscreen.components.NotificationItem


@Preview(showBackground = true, showSystemUi = true)
@Composable
fun NotificationScreen() {

    val notifications = listOf(
        NotificationData(R.drawable.profile_img, "martini_rond", "3d", isFollowing = true),
        NotificationData(R.drawable.profile_img, "john", "3d", isRequested = true),
        NotificationData(R.drawable.profile_img, "abcd"),
        NotificationData(R.drawable.profile_img, "martini_rond"),
        NotificationData(R.drawable.profile_img, "martini_rond", "3d", isRequested = true),
        NotificationData(R.drawable.profile_img, "martini_rond"),
        NotificationData(R.drawable.profile_img, "martini_rond"),
        NotificationData(R.drawable.profile_img, "martini_rond", "3d", isFollowing = true),
    )
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            items(notifications) { item ->
                NotificationItem(notificationContent = item)
            }
        }
    }


}