package com.example.jetpackcomposepracticedemo.presentation.ui.profilescreen.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AssignmentInd
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.jetpackcomposepracticedemo.presentation.ui.profilescreen.ProfileScreen

@Composable
fun ProfileTabSelector(
    tabs: List<String>,
    selectedIndex: Int,
    onTabClick: (Int) -> Unit
) {
    TabRow(
        selectedTabIndex = selectedIndex,
        containerColor = Color.Black,
        indicator = { tabPositions ->
            TabRowDefaults.SecondaryIndicator(
                modifier = Modifier.tabIndicatorOffset(tabPositions[selectedIndex]),
                height = 2.dp,
                color = Color.White
            )
        }
    ) {
        tabs.forEachIndexed { index, title ->
            Tab(
                selected = selectedIndex == index,
                onClick = { onTabClick(index) },
                icon = {
                    val iconColor = if (selectedIndex == index) Color.White else Color.Gray
                    Icon(
                        imageVector = when(index) {
                            0 -> Icons.Default.GridView
                            1 -> Icons.Default.VideoLibrary
                            2 -> Icons.Default.Repeat
                            else -> Icons.Default.AssignmentInd
                        },
                        contentDescription = null,
                        tint = iconColor
                    )
                }
            )
        }
    }
}
/*
fun ProfileTabs() {
    var tabIndex by remember { mutableStateOf(0) }

    val tabs = listOf("Posts", "Reels", "Reposts", "Tagged")
    Column(
        modifier = Modifier
            .fillMaxWidth()
    ) {
        TabRow(
            selectedTabIndex = tabIndex,
            containerColor = Color.Black,
            indicator = { tabPositions ->
                // The moving line at the bottom
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[tabIndex]),
                    height = 2.dp,
                    color = Color.White
                )
            },
            divider = {
                // Optional: thin line across the bottom
                HorizontalDivider(thickness = 0.5.dp, color = Color.DarkGray)
            }) {

            tabs.forEachIndexed { index, title ->
                val isSelected = tabIndex == index

                // Switch color based on selection state
                val iconColor = if (isSelected) Color.White else Color.Gray
                Tab(
                    selected = isSelected,
                    onClick = { tabIndex = index },
                    selectedContentColor = Color.DarkGray,
                    unselectedContentColor = Color.DarkGray,
                    icon = {
                        when (index) {
                            0 -> Icon(
                                imageVector = Icons.Default.GridView,
                                contentDescription = null,
                                tint = iconColor
                            )

                            1 -> Icon(
                                imageVector = Icons.Default.VideoLibrary,
                                contentDescription = null,
                                tint = iconColor
                            )

                            2 -> Icon(
                                imageVector = Icons.Default.Repeat,
                                contentDescription = null,
                                tint = iconColor
                            )

                            3 -> Icon(
                                imageVector = Icons.Default.AssignmentInd,
                                contentDescription = null,
                                tint = iconColor
                            )
                        }
                    }
                )
            }
        }

        Box(
            modifier = Modifier.fillMaxWidth() // 👈 VERY IMPORTANT
        ) {
            when (tabIndex) {
                0 -> AllContent()
                1 -> ReelContent()
                2 -> RePostContent()
                3 -> TagPostContent()
            }
        }
    }
}
*/
