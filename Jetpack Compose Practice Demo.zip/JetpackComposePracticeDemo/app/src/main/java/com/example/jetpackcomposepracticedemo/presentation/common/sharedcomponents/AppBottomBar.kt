package com.example.jetpackcomposepracticedemo.presentation.common.sharedcomponents

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Send
import androidx.compose.material.icons.filled.AddBox
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Send
import androidx.compose.material.icons.outlined.SmartDisplay
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.NavDestination
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavDestination.Companion.hierarchy
import com.example.jetpackcomposepracticedemo.R
import com.example.jetpackcomposepracticedemo.presentation.navigation.AppRoute

@Composable
fun AppBottomBar(
    navController: NavController,
    currentDestination: NavDestination?
) {
    val items = listOf(
        AppRoute.HomeScreen,
        AppRoute.ReelScreen,
        AppRoute.ChatScreen,
        AppRoute.SearchScreen,
        AppRoute.ProfileScreen
    )

    NavigationBar(
        containerColor = Color.Black
    ) {
        items.forEach { route ->

            val isSelected = when (route) {
                AppRoute.ReelScreen -> currentDestination?.hasRoute<AppRoute.ReelScreen>() == true
                else -> currentDestination?.hierarchy?.any {
                    it.hasRoute(route::class)
                } == true
            }

            NavigationBarItem(
                selected = isSelected,
                onClick = {
                    when (route) {

                        AppRoute.ReelScreen -> {
                            navController.navigate(AppRoute.ReelScreen()) {
                                popUpTo(navController.graph.startDestinationId)
                                launchSingleTop = true
                            }
                        }

                        else -> {
                            navController.navigate(route) {
                                popUpTo(navController.graph.startDestinationId)
                                launchSingleTop = true
                            }
                        }
                    }
                },
                icon = {

                    when (route) {

                        AppRoute.HomeScreen -> {
                            Icon(
                                imageVector = Icons.Outlined.Home,
                                contentDescription = "Home",
                                tint = Color.White
                            )
                        }

                        AppRoute.ReelScreen -> {
                            Icon(
                                painterResource(R.drawable.ic_reel),
                                contentDescription = "Reels",
                                tint = Color.White
                            )
                        }

                        AppRoute.ChatScreen -> {

                            Box {
                                Icon(
                                    painterResource(R.drawable.ic_send),
                                    contentDescription = "Share",
                                    tint = Color.White
                                )
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .background(Color.Red, CircleShape)
                                        .align(Alignment.TopEnd)
                                )
                            }
                        }

                        AppRoute.SearchScreen -> {
                            Icon(
                                imageVector = Icons.Outlined.Search,
                                contentDescription = "Search",
                                tint = Color.White
                            )
                        }

                        AppRoute.ProfileScreen -> {
                            Image(
                                painter = painterResource(R.drawable.profile_img),
                                contentDescription = null,
                                modifier = Modifier
                                    .size(26.dp)
                                    .clip(CircleShape)
                            )
                        }

                        else -> {}
                    }
                }
            )
        }
    }
}