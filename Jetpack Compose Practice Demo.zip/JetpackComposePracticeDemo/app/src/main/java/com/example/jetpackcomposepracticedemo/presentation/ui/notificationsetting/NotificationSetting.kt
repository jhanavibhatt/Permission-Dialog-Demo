package com.example.jetpackcomposepracticedemo.presentation.ui.notificationsetting

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.jetpackcomposepracticedemo.R
import com.example.jetpackcomposepracticedemo.presentation.common.sharedcomponents.ClickableAnnotatedText
import com.example.jetpackcomposepracticedemo.presentation.ui.notificationsetting.components.notificationSettingItem
import com.example.jetpackcomposepracticedemo.ui.theme.BtnColor

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun NotificationSetting() {
    var checked by remember { mutableStateOf(false) }
    var secChecked by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(15.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {

                Box(
                    modifier = Modifier
                        .background(Color.DarkGray, CircleShape)
                        .padding(10.dp)
                ) {
                    Image(
                        painter = painterResource(R.drawable.ic_notification),
                        contentDescription = null,
                        Modifier.size(40.dp)
                    )
                }
                Spacer(Modifier.width(10.dp))


                ClickableAnnotatedText(
                    normalText = "Turn on notifications from your device \n settings to see updates on your lock \n screen",
                    clickableText = "\n Go to device settings",
                    clickableColor = BtnColor,
                    normalTextColor = Color.White,
                    onClick = { }
                )


            }
        }

        item {
            Spacer(Modifier.height(20.dp))
            Text(
                "Push Notifications",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp


            )
        }
        item {

            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {

                Text(
                    "Pause all",
                    color = Color.White,
                    fontSize = 16.sp,
                    modifier = Modifier.weight(1f)
                )
                Switch(
                    checked = checked,
                    onCheckedChange = {
                        checked = it
                    },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.Black,
                        checkedTrackColor = Color.White,
                        uncheckedThumbColor = Color.LightGray,
                        uncheckedTrackColor = Color.DarkGray
                    )
                )
            }
            Spacer(Modifier.height(10.dp))

            Text(
                "Temporarily  pause notification",
                color = Color.LightGray,
                fontSize = 14.sp,
                modifier = Modifier.fillMaxWidth()
            )

        }
        item {
            Spacer(Modifier.height(10.dp))
            Text(
                "Sleep mode",
                color = Color.White,
                fontSize = 16.sp,
            )
            Spacer(Modifier.height(10.dp))
            Text(
                "automatically mute notifications at night or whenever you \n need to focus ",
                color = Color.LightGray,
                fontSize = 14.sp,
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {

            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {

                Text(
                    " Message only",
                    color = Color.White,
                    fontSize = 16.sp,
                    modifier = Modifier.weight(1f)
                )
                Switch(
                    checked = secChecked,
                    onCheckedChange = {
                        secChecked = it
                    },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.Black,
                        checkedTrackColor = Color.White,
                        uncheckedThumbColor = Color.LightGray,
                        uncheckedTrackColor = Color.DarkGray
                    )
                )
            }
            Spacer(Modifier.height(10.dp))

            Text(
                "only receive notifications about new messages and other \n " +
                        "other message notification , such as request and reminder",
                color = Color.LightGray,
                fontSize = 14.sp,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))

        }
        item {
            notificationSettingItem("Posts, Stories and Comments")
            Spacer(Modifier.height(10.dp))
            notificationSettingItem("Following and followers")
            Spacer(Modifier.height(10.dp))
            notificationSettingItem("Messages")
            Spacer(Modifier.height(10.dp))
            notificationSettingItem("Calls")
            Spacer(Modifier.height(10.dp))
            notificationSettingItem("Live and reels")
            Spacer(Modifier.height(10.dp))
            notificationSettingItem("Fundraisers")
            Spacer(Modifier.height(10.dp))
            notificationSettingItem("From Instagram")
            Spacer(Modifier.height(10.dp))
            notificationSettingItem("Birthdays")
            Spacer(Modifier.height(10.dp))
            notificationSettingItem("Maps")
            Spacer(Modifier.height(10.dp))
            notificationSettingItem("From accounts you follow")
            Spacer(Modifier.height(10.dp))
        }

        item {

            Text(
                "other notification types",
                color = Color.White,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(10.dp))

            notificationSettingItem("Email notification")
            Spacer(Modifier.height(10.dp))
            notificationSettingItem("Shopping")
            Spacer(Modifier.height(10.dp))
            notificationSettingItem("Voting reminders")
            Spacer(Modifier.height(10.dp))

        }
    }
}