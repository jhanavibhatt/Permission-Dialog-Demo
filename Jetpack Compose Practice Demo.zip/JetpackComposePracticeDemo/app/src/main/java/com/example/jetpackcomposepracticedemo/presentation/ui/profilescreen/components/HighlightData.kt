package com.example.jetpackcomposepracticedemo.presentation.ui.profilescreen.components

data class HighlightData(
    val title: String,
    val isNew: Boolean,
    val image: Int?
)