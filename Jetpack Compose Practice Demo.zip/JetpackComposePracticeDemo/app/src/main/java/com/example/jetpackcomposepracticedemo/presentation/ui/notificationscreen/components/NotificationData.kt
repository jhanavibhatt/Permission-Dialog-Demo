package com.example.jetpackcomposepracticedemo.presentation.ui.notificationscreen.components

data class NotificationData(
val profileImg: Int,
val username: String,
val time: String = "",
val isFollowing: Boolean = false,
val isRequested: Boolean = false
)
