package com.example.jetpackcomposepracticedemo.presentation.ui.homescreen.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun InstagramPost(post: PostItem) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.Black)
    ) {
        // ── Header ──────────────────────────────────────────
        PostHeader(post)

        // ── Image / Carousel / Video ─────────────────────────
        when {
            post.isMultiPost -> CarouselPost(post)
            post.isVideo     -> VideoPost(post)
            else             -> SingleImagePost(post)
        }

        PostActions(post)

        Text(
            text = "${post.username} ${post.caption}",
            color = Color.White,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }

}