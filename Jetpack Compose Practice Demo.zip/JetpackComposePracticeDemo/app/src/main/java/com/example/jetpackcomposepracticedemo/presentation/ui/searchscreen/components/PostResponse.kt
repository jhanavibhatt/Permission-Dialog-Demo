package com.example.jetpackcomposepracticedemo.presentation.ui.searchscreen.components

data class PostResponse(
    val posts: List<InstagramPost>
)
