package com.example.jetpackcomposepracticedemo.presentation.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.jetpackcomposepracticedemo.presentation.common.sharedcomponents.AppBottomBar
import com.example.jetpackcomposepracticedemo.presentation.common.sharedcomponents.AppTopBar
import com.example.jetpackcomposepracticedemo.presentation.ui.chatscreen.ChatScreen
import com.example.jetpackcomposepracticedemo.presentation.ui.homescreen.HomeScreen
import com.example.jetpackcomposepracticedemo.presentation.ui.notificationscreen.NotificationScreen
import com.example.jetpackcomposepracticedemo.presentation.ui.profilescreen.ProfileScreen
import com.example.jetpackcomposepracticedemo.presentation.ui.reelscreen.ReelScreen
import com.example.jetpackcomposepracticedemo.presentation.ui.searchscreen.SearchScreen
import com.example.jetpackcomposepracticedemo.presentation.ui.storyscreen.InstagramStoryScreen

@Composable
fun AppNavigation() {

    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = backStackEntry?.destination

    val topBarState = when {
        currentDestination?.hasRoute<AppRoute.HomeScreen>() == true ->
            TopBarState(
                title = "Home",
                showAdd = true,
                rightIcon = Icons.Default.FavoriteBorder
            )

        currentDestination?.hasRoute<AppRoute.ProfileScreen>() == true ->
            TopBarState(
                title = "jacob_w",
                showDropdown = true,
                showAdd = true,
                rightIcon = Icons.Default.Menu
            )

        currentDestination?.hasRoute<AppRoute.ChatScreen>() == true ->
            TopBarState(
                title = "Chats",
                showDropdown = true,
                rightIcon = Icons.Default.EditNote
            )

        currentDestination?.hasRoute<AppRoute.SearchScreen>() == true ->
            TopBarState(
                isSearchBar = true
            )

        currentDestination?.hasRoute<AppRoute.ReelScreen>() == true ->
            TopBarState(
                title = "Reels"
            )
        currentDestination?.hasRoute<AppRoute.NotificationScreen>() == true ->
            TopBarState(
                title = "Notifications",
                showBack = true
            )

        else -> TopBarState()
    }
    Scaffold(
        topBar = {
            AppTopBar(
                state = topBarState,
                onBackClick = { navController.popBackStack() },
                onRightIconClick = {
                    if (currentDestination?.hasRoute<AppRoute.HomeScreen>() == true) {
                        navController.navigate(AppRoute.NotificationScreen)
                    }
                }
            )
        },
        bottomBar = {
            AppBottomBar(navController, currentDestination)
        }
    ) { padding ->

        NavHost(
            navController = navController,
            startDestination = AppRoute.HomeScreen,
            modifier = Modifier.padding(padding)
        ) {

            composable<AppRoute.HomeScreen> { HomeScreen(navController) }
            composable<AppRoute.ChatScreen> { ChatScreen() }
            composable<AppRoute.ProfileScreen> { ProfileScreen() }
            composable<AppRoute.SearchScreen> { SearchScreen() }
            composable<AppRoute.ReelScreen> { ReelScreen() }
            composable<AppRoute.NotificationScreen> {
                NotificationScreen()
            }
            composable<AppRoute.InstagramStoryScreen> {
                InstagramStoryScreen()
            }
        }
    }
}