package com.example.jetpackcomposepracticedemo.presentation.navigation

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.jetpackcomposepracticedemo.presentation.common.sharedcomponents.AppBottomBar
import com.example.jetpackcomposepracticedemo.presentation.common.sharedcomponents.AppTopBar
import com.example.jetpackcomposepracticedemo.presentation.ui.chatscreen.ChatScreen
import com.example.jetpackcomposepracticedemo.presentation.ui.editprofilescreen.EditProfileScreen
import com.example.jetpackcomposepracticedemo.presentation.ui.homescreen.HomeScreen
import com.example.jetpackcomposepracticedemo.presentation.ui.notificationscreen.NotificationScreen
import com.example.jetpackcomposepracticedemo.presentation.ui.notificationsetting.NotificationSetting
import com.example.jetpackcomposepracticedemo.presentation.ui.profilescreen.ProfileScreen
import com.example.jetpackcomposepracticedemo.presentation.ui.profilescreen.components.ProfileDrawerContent
import com.example.jetpackcomposepracticedemo.presentation.ui.reelscreen.ReelScreen
import com.example.jetpackcomposepracticedemo.presentation.ui.searchscreen.SearchScreen
import com.example.jetpackcomposepracticedemo.presentation.ui.settingandactivity.SettingAndActivity
import com.example.jetpackcomposepracticedemo.presentation.ui.storyscreen.InstagramStoryScreen
import com.example.jetpackcomposepracticedemo.presentation.ui.youractivityscreen.YourActivityScreen
import kotlinx.coroutines.launch

@Composable
fun AppNavigation() {

    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = backStackEntry?.destination
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    BackHandler(enabled = drawerState.isOpen) {
        scope.launch { drawerState.close() }
    }

    val showBottomBar = when {
        currentDestination?.hasRoute<AppRoute.InstagramStoryScreen>() == true -> false
        currentDestination?.hasRoute<AppRoute.SettingsScreen>() == true -> false

        else -> true
    }

    val topBarState = when {
        currentDestination?.hasRoute<AppRoute.HomeScreen>() == true ->
            TopBarState(
                title = "Home",
                showAdd = true,
                rightIcon = Icons.Default.FavoriteBorder
            )

        currentDestination?.hasRoute<AppRoute.ProfileScreen>() == true ->
            TopBarState(
                title = "jacob_w",
                showDropdown = true,
                showAdd = true,
                rightIcon = Icons.Default.Menu
            )

        currentDestination?.hasRoute<AppRoute.ChatScreen>() == true ->
            TopBarState(
                title = "Chats",
                showDropdown = true,
                rightIcon = Icons.Default.EditNote
            )

        currentDestination?.hasRoute<AppRoute.SearchScreen>() == true ->
            TopBarState(
                isSearchBar = true
            )

        currentDestination?.hasRoute<AppRoute.ReelScreen>() == true ->
            TopBarState(
                title = "Reels",
                showAdd = true
            )

        currentDestination?.hasRoute<AppRoute.NotificationScreen>() == true ->
            TopBarState(
                title = "Notifications",
                showBack = true
            )
        currentDestination?.hasRoute<AppRoute.SettingAndActivityScreen>() == true ->
            TopBarState(
                title = "Settings and Activity",
                showBack = true
            )
        currentDestination?.hasRoute<AppRoute.EditProfileScreen>() == true ->
            TopBarState(
                title = "Edit Profile",
                showBack = true
            )
        currentDestination?.hasRoute<AppRoute.NotificationSettingScreen>() == true ->

            TopBarState(
                title = "Notification Setting",
                showBack = true
            )
        currentDestination?.hasRoute<AppRoute.YourActivityScreen>() == true ->

            TopBarState(
                title = "Your Activity ",
                showBack = true
            )


        else -> TopBarState()
    }



                Scaffold(
                    topBar = {
                        AppTopBar(
                            state = topBarState,
                            onBackClick = { navController.popBackStack() },
                            onRightIconClick = {
                                if (currentDestination?.hasRoute<AppRoute.HomeScreen>() == true) {
                                    navController.navigate(AppRoute.NotificationScreen)
                                }
                                if (currentDestination?.hasRoute<AppRoute.ProfileScreen>() == true) {
                                   navController.navigate(AppRoute.SettingAndActivityScreen)
                                }
                            }
                        )
                    },
                    bottomBar = {

                        if (showBottomBar) {
                            AppBottomBar(navController, currentDestination)
                        }
                    }
                ) { padding ->

                    NavHost(
                        navController = navController,
                        startDestination = AppRoute.HomeScreen,
                        modifier = Modifier.padding(padding)
                    ) {

                        composable<AppRoute.HomeScreen> { HomeScreen(navController) }
                        composable<AppRoute.ChatScreen> { ChatScreen() }
                        composable<AppRoute.ProfileScreen> { ProfileScreen(navController) }
                        composable<AppRoute.SearchScreen> { SearchScreen(navController) }
                        composable<AppRoute.ReelScreen> { backStackEntry ->

                            val args = backStackEntry.toRoute<AppRoute.ReelScreen>()

                            ReelScreen(startIndex = args.startIndex)
                        }
                        composable<AppRoute.NotificationScreen> {
                            NotificationScreen()
                        }
                        composable<AppRoute.InstagramStoryScreen> {
                            InstagramStoryScreen()
                        }
                        composable<AppRoute.SettingAndActivityScreen> {
                            SettingAndActivity(navController)
                        }
                        composable<AppRoute.EditProfileScreen>(){
                            EditProfileScreen()
                        }
                        composable<AppRoute.YourActivityScreen>(){
                            YourActivityScreen()
                        }
                        composable<AppRoute.NotificationSettingScreen>{
                            NotificationSetting()
                        }

                    }
                }
            }


