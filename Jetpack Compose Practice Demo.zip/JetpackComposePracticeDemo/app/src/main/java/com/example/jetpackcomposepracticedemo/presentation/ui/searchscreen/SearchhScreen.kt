package com.example.jetpackcomposepracticedemo.presentation.ui.searchscreen

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.items
import androidx.compose.foundation.lazy.staggeredgrid.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.jetpackcomposepracticedemo.R
import com.example.jetpackcomposepracticedemo.presentation.ui.searchscreen.components.InstagramPost

@Composable
fun SearchScreen() {
    val dummyPosts = listOf(
        InstagramPost(id = 1, imageRes = R.drawable.img_1, isMultiPost = true),
        InstagramPost(id = 2, imageRes = R.drawable.img_2, viewCountText = "2.5k"),
        InstagramPost(id = 3, imageRes = R.drawable.img_3, isVideo = true),
        InstagramPost(id = 4, imageRes = R.drawable.img_1),
        InstagramPost(id = 5, imageRes = R.drawable.img_2),
        InstagramPost(id = 5, imageRes = R.drawable.img_2),
        InstagramPost(id = 5, imageRes = R.drawable.img_2),
        InstagramPost(id = 7, imageRes = R.drawable.img_3),
        InstagramPost(id = 7, imageRes = R.drawable.img_3),
        InstagramPost(id = 7, imageRes = R.drawable.img_3),
        InstagramPost(id = 7, imageRes = R.drawable.img_3),
        InstagramPost(id = 5, imageRes = R.drawable.img_2),
        InstagramPost(id = 5, imageRes = R.drawable.img_2),
        InstagramPost(id = 5, imageRes = R.drawable.img_2),
        InstagramPost(id = 6, imageRes = R.drawable.img_1, isVideo = true),
        InstagramPost(id = 7, imageRes = R.drawable.img_3),
        InstagramPost(id = 8, imageRes = R.drawable.img_2),
        InstagramPost(id = 9, imageRes = R.drawable.img_1)
    )
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        Spacer(Modifier.height(16.dp))
        InstagramSearchGrid(posts = dummyPosts)
    }
}

@Composable
fun InstagramSearchGrid(posts: List<InstagramPost>) {
    LazyVerticalStaggeredGrid(
        columns = StaggeredGridCells.Fixed(3),
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 0.5.dp),
        contentPadding = PaddingValues(bottom = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(1.dp),
        verticalItemSpacing = 1.dp
    ) {
        itemsIndexed(posts) { index, post ->


            val patternIndex = index % 18
            val isRightColumnBig = (patternIndex == 2)
            val isLeftColumnBig = (patternIndex == 11)

            val isMiddleColumnBig = (patternIndex == 7)

            val itemHeight = if (isRightColumnBig || isLeftColumnBig || isMiddleColumnBig) {
                400.dp
            } else {
                200.dp
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(itemHeight)
                    .clip(RectangleShape)
            ) {
                Image(
                    painter = painterResource(id = post.imageRes),
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )

                if (post.viewCountText != null) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(6.dp)
                            .background(Color.Transparent)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Visibility,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = post.viewCountText,
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                }

                if (post.isMultiPost) {
                    Icon(
                        painterResource(R.drawable.ic_layers),
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(8.dp)
                            .size(20.dp)
                    )
                }
            }
        }
    }

}