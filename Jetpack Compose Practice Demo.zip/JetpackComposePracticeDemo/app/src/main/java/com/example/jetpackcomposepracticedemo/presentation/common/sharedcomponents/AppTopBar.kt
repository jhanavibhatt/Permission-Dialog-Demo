package com.example.jetpackcomposepracticedemo.presentation.common.sharedcomponents

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBackIosNew
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.jetpackcomposepracticedemo.presentation.navigation.TopBarState
import com.example.jetpackcomposepracticedemo.presentation.ui.searchscreen.components.InstagramSearchHeader

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppTopBar(
    state: TopBarState,
    onBackClick: () -> Unit = {},
    onRightIconClick: () -> Unit = {}
) {
    var query by remember { mutableStateOf("") }

    CenterAlignedTopAppBar(
        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
            containerColor = Color.Black,
            titleContentColor = Color.White
        ),

        navigationIcon = {
            Row(verticalAlignment = Alignment.CenterVertically) {

                if (state.showBack) {
                    Icon(
                        Icons.Default.ArrowBackIosNew,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier
                            .clickable { onBackClick() }
                    )
                }

                if (state.showAdd) {
                    Icon(
                        Icons.Default.Add,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier
                            .padding(start = 8.dp)
                            .clickable {  }
                    )
                }
            }
        },

        title = {
            if (state.isSearchBar) {
                InstagramSearchHeader(
                   query = query,
                    onQueryChange = { query = it },
                )
            } else {
                Row(verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Start) {



                    if (state.showDropdown) {
                        Icon(Icons.Default.Lock, null, Modifier.size(14.dp), tint = Color.White)
                        Spacer(Modifier.width(4.dp))
                    }

                    Text(
                        text = state.title,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold
                    )

                    if (state.showDropdown) {
                        Icon(Icons.Default.KeyboardArrowDown, null, tint = Color.White)
                    }
                }
            }
        },

        actions = {
            state.rightIcon?.let {
                Icon(
                    imageVector = it,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.padding(end = 12.dp).clickable { onRightIconClick() }
                )
            }
        }
    )
}