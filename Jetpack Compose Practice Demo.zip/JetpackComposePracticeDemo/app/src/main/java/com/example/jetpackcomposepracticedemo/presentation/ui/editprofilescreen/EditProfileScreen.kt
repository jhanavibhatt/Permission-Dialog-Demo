package com.example.jetpackcomposepracticedemo.presentation.ui.editprofilescreen

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.jetpackcomposepracticedemo.R
import com.example.jetpackcomposepracticedemo.presentation.ui.editprofilescreen.components.EditProfileField
import com.example.jetpackcomposepracticedemo.ui.theme.BtnColor


@Preview(showBackground = true, showSystemUi = true)
@Composable
fun EditProfileScreen() {

    var name by remember { mutableStateOf("") }
    var userName by remember { mutableStateOf("") }
    var pronoun by remember { mutableStateOf("") }
    var bio by remember { mutableStateOf("") }
    var gender by remember { mutableStateOf("Prefer not to say") }


    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(15.dp),

        ) {

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {

            Box(
                modifier = Modifier
                    .size(80.dp)
                    .padding(5.dp)
                    .clip(CircleShape)
                    .background(Color.Black)

            ) {

                Image(
                    painter = painterResource(R.drawable.profile_img),
                    "profile",
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black),
                    contentScale = ContentScale.Crop,
                )
            }
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .padding(5.dp)
                    .clip(CircleShape)
                    .background(Color.Blue)

            ) {

                Image(
                    painter = painterResource(R.drawable.ic_avtar),
                    contentDescription = "profile",
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Blue),
                )
            }
        }
        Spacer(Modifier.height(5.dp))

        Text(
            "Edit picture or avatar",
            color = BtnColor,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )

        Spacer(Modifier.height(15.dp))

        EditProfileField(label = "Name", value = name, onValueChange = { name = it })
        Spacer(Modifier.height(10.dp))
        EditProfileField(label = "user Name", value = userName, onValueChange = { userName = it })
        Spacer(Modifier.height(10.dp))
        EditProfileField(label = "Pronoun", value = pronoun, onValueChange = { pronoun = it })
        Spacer(Modifier.height(10.dp))
        EditProfileField(label = "Bio", value = bio, onValueChange = { bio = it })
        Spacer(Modifier.height(10.dp))

        Text(
            "Add Link",
            color = Color.White
        )

        Spacer(Modifier.height(10.dp))
        Text(
            "Banners",
            style = MaterialTheme.typography.titleLarge,
            color = Color.White
        )

        Spacer(Modifier.height(10.dp))
        EditProfileField(
            "Gender",
            value = gender,
            onValueChange = { gender = it },
            isDropdown = true,
            options = listOf("Male", "Female", "Prefer not to say")
        )

        Spacer(Modifier.height(20.dp))



        Text(
            "Switch to Professional Account",
            color = BtnColor,
            style = MaterialTheme.typography.titleMedium
            )
        Spacer(Modifier.height(10.dp))
        Text(
            "Personal information settings",
            color = BtnColor,
            style = MaterialTheme.typography.titleMedium
        )
        Spacer(Modifier.height(10.dp))
        Text(
            "Show that your profile is varified",
            color = BtnColor,
            style = MaterialTheme.typography.titleMedium
        )


    }
}