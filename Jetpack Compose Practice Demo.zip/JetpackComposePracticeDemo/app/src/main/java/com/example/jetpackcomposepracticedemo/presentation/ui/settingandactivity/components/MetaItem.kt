package com.example.jetpackcomposepracticedemo.presentation.ui.settingandactivity.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun MetaItem(title: String,desc: String,icon: Int,onClick: () -> Unit) {

    Row(
        modifier = Modifier.fillMaxWidth().background(Color.Black),
        verticalAlignment = Alignment.CenterVertically
    )

    {

        Icon(
            painter = painterResource(icon),
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.padding(5.dp)
        )
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                title,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium,
            )
            Text(
                desc,
                color = Color.Gray,
                maxLines = 2,
                style = MaterialTheme.typography.titleSmall,
            )
        }
        Icon(Icons.AutoMirrored.Filled.ArrowForwardIos, contentDescription = null, tint = Color.Gray)


    }

}