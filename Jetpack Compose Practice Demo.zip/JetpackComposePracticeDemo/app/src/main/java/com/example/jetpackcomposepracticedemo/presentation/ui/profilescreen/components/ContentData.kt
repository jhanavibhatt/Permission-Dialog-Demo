package com.example.jetpackcomposepracticedemo.presentation.ui.profilescreen.components

data class ContentData(
    val id: Int,
    val imageRes: Int,
    val isVideo: Boolean = false,
    val isMultiPost: Boolean = false
)
