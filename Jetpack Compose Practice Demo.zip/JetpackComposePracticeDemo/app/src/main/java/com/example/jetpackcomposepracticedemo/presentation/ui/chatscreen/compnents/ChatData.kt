package com.example.jetpackcomposepracticedemo.presentation.ui.chatscreen.compnents

data class ChatData(
    val profileImg: Int,
    val name: String,
    val lastMsg: String,
    val time: String
)
