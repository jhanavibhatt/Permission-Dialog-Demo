package com.example.jetpackcomposepracticedemo.presentation.ui.reelscreen

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.example.jetpackcomposepracticedemo.R
import com.example.jetpackcomposepracticedemo.presentation.ui.reelscreen.components.Reel
import com.example.jetpackcomposepracticedemo.presentation.ui.reelscreen.components.ReelItem

@Composable
fun ReelScreen() {
    val dummyReels = listOf(
    Reel(
        id = 1,
        videoRes = R.drawable.img_1, // Replace with your image/video resource
        username = "joshua_l",
        caption = "Exploring the streets of Tokyo! 🇯🇵 #travel #tokyo",
        audioName = "joshua_l · Original Audio",
        likes = "1.2M",
        comments = "45.2K"
    ),
    Reel(
        id = 2,
        videoRes = R.drawable.img_2,
        username = "shivamsharmaavlogs",
        caption = "New vlog is out now! Check the link in bio. 🎥",
        audioName = "Trending Audio - Top 50",
        likes = "850K",
        comments = "12K"
    ),
    Reel(
        id = 3,
        videoRes = R.drawable.img_3,
        username = "nature_photography",
        caption = "Wait for the sunset... 🌅✨",
        audioName = "Calm Instrumental Beats",
        likes = "2.5M",
        comments = "98K"
    )
)

    val pagerState = rememberPagerState(pageCount = { dummyReels.size })

    VerticalPager(
        state = pagerState,
        modifier = Modifier.fillMaxSize().background(Color.Black)
    ) { page ->
        ReelItem(dummyReels[page])
    }
}