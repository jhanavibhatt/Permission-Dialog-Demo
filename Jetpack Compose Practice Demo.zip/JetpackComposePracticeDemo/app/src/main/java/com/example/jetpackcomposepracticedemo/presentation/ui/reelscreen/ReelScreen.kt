package com.example.jetpackcomposepracticedemo.presentation.ui.reelscreen

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.jetpackcomposepracticedemo.R
import com.example.jetpackcomposepracticedemo.data.mapper.toReel
import com.example.jetpackcomposepracticedemo.presentation.ui.reelscreen.components.Reel
import com.example.jetpackcomposepracticedemo.presentation.ui.reelscreen.components.ReelItem
import com.example.jetpackcomposepracticedemo.presentation.common.sharedcomponents.PostViewModel
import com.example.jetpackcomposepracticedemo.utils.Resource

@Composable
fun ReelScreen(
    startIndex: Int,
    viewModel: PostViewModel = viewModel()
) {
    val dummyReels = listOf(
        Reel(
            id = 1,
            videoRes = "https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?fm=jpg&w=400", // Replace with your image/video resource
            username = "joshua_l",
            caption = "Exploring the streets of Tokyo! 🇯🇵 #travel #tokyo",
            audioName = "joshua_l · Original Audio",
            likes = "1.2M",
            comments = "45.2K"
        ),
        Reel(
            id = 2,
            videoRes = "",
            username = "https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?fm=jpg&w=400",
            caption = "New vlog is out now! Check the link in bio. 🎥",
            audioName = "Trending Audio - Top 50",
            likes = "850K",
            comments = "12K"
        ),
        Reel(
            id = 3,
            videoRes = "https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?fm=jpg&w=400",
            username = "nature_photography",
            caption = "Wait for the sunset... 🌅✨",
            audioName = "Calm Instrumental Beats",
            likes = "2.5M",
            comments = "98K"
        )
    )

    val state = viewModel.postState.collectAsState()

    // 🔥 Only call API if coming from Search
    LaunchedEffect(Unit) {
        viewModel.getPosts()
    }
    if (startIndex >= 0) {

        when (val result = state.value) {

            is Resource.Loading -> {
                Box(Modifier.fillMaxSize(), Alignment.Center) {
                    CircularProgressIndicator()
                }
            }

            is Resource.Success -> {

                val reels = result.data.map { it.toReel() }

                val safeIndex = startIndex.coerceIn(0, reels.lastIndex)

                val pagerState = rememberPagerState(
                    initialPage = safeIndex,
                    pageCount = { reels.size }
                )

                VerticalPager(
                    state = pagerState,
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black)
                ) {
                    ReelItem(reels[it])
                }
            }

            is Resource.Error -> {
                Text("Error: ${result.message}", color = Color.White)
            }

            else -> {}
        }

    } else {
        val pagerState = rememberPagerState(
            initialPage = 0,
            pageCount = { dummyReels.size }
        )

        VerticalPager(
            state = pagerState,
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) { page ->
            ReelItem(dummyReels[page])
        }
    }
}