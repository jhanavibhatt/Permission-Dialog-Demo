package com.example.jetpackcomposepracticedemo.presentation.navigation

import androidx.compose.ui.graphics.vector.ImageVector

data class TopBarState(
    val title: String = "",
    val showDropdown: Boolean = false,
    val showAdd: Boolean = false,
    val showBack: Boolean = false,
    val rightIcon: ImageVector? = null,
    val isSearchBar: Boolean = false
)