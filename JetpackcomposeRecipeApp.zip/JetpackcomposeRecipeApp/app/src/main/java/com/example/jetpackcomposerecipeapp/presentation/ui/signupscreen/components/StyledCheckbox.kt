package com.example.jetpackcomposerecipeapp.presentation.ui.signupscreen.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun StyledCheckBox() {
    var checked by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .size(28.dp) // container size
            .background(
                color = Color(0xFFE8E0DD),
                shape = RoundedCornerShape(6.dp)
            )
            .border(
                width = 1.dp,
                color = Color.Gray,
                shape = RoundedCornerShape(6.dp)
            ),
        contentAlignment = Alignment.Center
    ) {
        Checkbox(
            checked = checked,
            onCheckedChange = { checked = it },
            modifier = Modifier.size(20.dp), // checkbox inside
            colors = CheckboxDefaults.colors(
                checkedColor = Color(0xFFE8E0DD),
                uncheckedColor = Color.Transparent, // hide default box
                checkmarkColor = Color.Gray
            )
        )
    }
}//