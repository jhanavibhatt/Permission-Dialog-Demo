package com.example.jetpackcomposerecipeapp.presentation.ui.mealdetailscreen.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.jetpackcomposerecipeapp.data.model.RecipeDetailResponse
import com.example.jetpackcomposerecipeapp.ui.theme.Tertiary

@Composable
fun MetaSection(meal: RecipeDetailResponse) {

    Card(
        modifier = Modifier
            .padding(16.dp)
            .fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        elevation = CardDefaults.cardElevation(8.dp)
    ) {

        Row(
            modifier = Modifier.fillMaxWidth().padding(10.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {

            MetaItem(Icons.Default.AccessTime,"Prep", "${meal.readyInMinutes} min")
            VerticalDivider(
                modifier = Modifier
                    .height(40.dp),
                thickness = 1.dp,
                color = Color.LightGray
            )
            MetaItem(Icons.Default.Star,"Score", meal.healthScore.toString())
            VerticalDivider(
                modifier = Modifier
                    .height(40.dp),
                thickness = 1.dp,
                color = Color.LightGray
            )
            MetaItem(Icons.Default.Restaurant,"Cal", meal.servings.toString())
        }
    }
}

@Composable
fun MetaItem(icon: ImageVector,label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = Tertiary
        )
        Text(value, fontWeight = FontWeight.Bold)
        Text(label, fontSize = 12.sp)
    }
}