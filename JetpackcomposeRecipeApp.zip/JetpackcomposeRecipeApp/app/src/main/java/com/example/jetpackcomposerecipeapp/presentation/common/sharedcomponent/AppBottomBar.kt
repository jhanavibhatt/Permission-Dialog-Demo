package com.example.jetpackcomposerecipeapp.presentation.common.sharedcomponent

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavController
import androidx.navigation.NavDestination
import androidx.navigation.NavDestination.Companion.hasRoute
import com.example.jetpackcomposerecipeapp.presentation.navigation.AppRoute
import com.example.jetpackcomposerecipeapp.ui.theme.Primary
import com.example.jetpackcomposerecipeapp.ui.theme.PrimaryContainer
import com.example.jetpackcomposerecipeapp.ui.theme.activeContentColor

data class BottomNavItem(
    val route: AppRoute,
    val label: String,
    val icon: ImageVector
)
val bottomNavItems = listOf(
    BottomNavItem(AppRoute.Home, "Home", Icons.Default.Home),
    BottomNavItem(AppRoute.Favorites, "Favorites", Icons.Default.Favorite),
    BottomNavItem(AppRoute.Profile, "Profile", Icons.Default.Person)
)
@Composable
fun AppBottomBar(
    navController: NavController,
    currentDestination: NavDestination?
) {
    val backgroundColor = Color(0xFFFBF5F3) // Very light peach
    val selectedPillColor = Color(0xFFFFEAD1) // Light orange/cream pill
    val inactiveContentColor = Color(0xFF999999)
    NavigationBar {

        bottomNavItems.forEach { item ->

            val isSelected =
                currentDestination?.hasRoute(item.route::class) == true

            NavigationBarItem(
                selected = isSelected,
                onClick = {
                    navController.navigate(item.route) {


                        popUpTo(navController.graph.startDestinationId) {
                            saveState = true
                        }

                        launchSingleTop = true
                        restoreState = true
                    }
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = activeContentColor,
                    selectedTextColor = activeContentColor,
                    indicatorColor = selectedPillColor,
                    unselectedIconColor = inactiveContentColor,
                    unselectedTextColor = inactiveContentColor,
                ),
                icon = {
                    Icon(item.icon, contentDescription = item.label)
                },
                label = {
                    Text(item.label)
                }
            )
        }
    }
}