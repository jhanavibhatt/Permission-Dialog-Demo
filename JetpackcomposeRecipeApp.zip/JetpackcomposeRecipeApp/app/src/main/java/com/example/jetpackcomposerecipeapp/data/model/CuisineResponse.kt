package com.example.jetpackcomposerecipeapp.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

data class CuisineResponse(
    val cuisine: List<CategoryDto>
)


@Entity(tableName = "cuisines")
data class CategoryDto(
    @PrimaryKey
    val name: String,
    val image: String
)
