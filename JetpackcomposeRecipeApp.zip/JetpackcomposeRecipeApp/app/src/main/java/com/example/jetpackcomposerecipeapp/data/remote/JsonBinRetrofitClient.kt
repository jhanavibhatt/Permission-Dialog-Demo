package com.example.jetpackcomposerecipeapp.data.remote

import com.example.jetpackcomposerecipeapp.data.remote.api.JsonBinApiService
import com.example.jetpackcomposerecipeapp.utils.Constants
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object JsonBinRetrofitClient {

    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BODY
    }

    private val okHttpClient = OkHttpClient.Builder()
        .addInterceptor(loggingInterceptor)
        .build()

    val api: JsonBinApiService by lazy {
        Retrofit.Builder()
            .baseUrl(Constants.JSON_BIN_BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(JsonBinApiService::class.java)
    }
}