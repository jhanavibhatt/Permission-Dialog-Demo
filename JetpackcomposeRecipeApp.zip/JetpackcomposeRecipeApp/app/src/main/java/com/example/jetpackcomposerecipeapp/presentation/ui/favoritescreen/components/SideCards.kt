package com.example.jetpackcomposerecipeapp.presentation.ui.favoritescreen.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.rememberAsyncImagePainter

@Composable
fun SideCards() {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        SmallCard("Pappardelle al Pomodoro", "25m", "Medium")
        SmallCard("Honey Glazed Brioche", "45m", "Hard")
    }
}

@Composable
fun SmallCard(title: String, time: String, difficulty: String) {
    Card(
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(4.dp)
    ) {
        Column {
            Image(
                painter = rememberAsyncImagePainter("https://your-image-url"),
                contentDescription = null,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp),
                contentScale = ContentScale.Crop
            )

            Column(Modifier.padding(12.dp)) {
                Text(title, fontWeight = FontWeight.Bold)
                Row {
                    Text(time, fontSize = 12.sp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(difficulty, fontSize = 12.sp)
                }
            }
        }
    }
}