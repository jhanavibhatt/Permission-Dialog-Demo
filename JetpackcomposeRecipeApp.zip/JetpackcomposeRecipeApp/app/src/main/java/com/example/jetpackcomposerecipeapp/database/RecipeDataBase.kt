package com.example.jetpackcomposerecipeapp.database

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.jetpackcomposerecipeapp.dao.CuisineDao
import com.example.jetpackcomposerecipeapp.dao.RecipeDao
import com.example.jetpackcomposerecipeapp.data.model.CategoryDto
import com.example.jetpackcomposerecipeapp.data.model.Recipe
import com.example.jetpackcomposerecipeapp.data.model.RecipeDetailResponse
import com.example.jetpackcomposerecipeapp.utils.Converters

@Database(entities = [RecipeDetailResponse::class, CategoryDto::class, Recipe::class], version = 4, exportSchema = false)
@TypeConverters(Converters::class)
abstract class RecipeDataBase: RoomDatabase() {

    abstract fun recipeDao(): RecipeDao
    abstract fun cuisineDao(): CuisineDao


}