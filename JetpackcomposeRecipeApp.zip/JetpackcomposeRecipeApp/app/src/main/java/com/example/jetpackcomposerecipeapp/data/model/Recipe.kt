package com.example.jetpackcomposerecipeapp.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey


@Entity(tableName = "cuisine_recipes_list")
data class Recipe(
    @PrimaryKey
    val id: Int,
    val image: String,
    val title: String,

    val cuisine: String,   // 🔥 ADD THIS
    val offset: Int
)