package com.example.jetpackcomposerecipeapp.presentation.ui.splashscreen.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.jetpackcomposerecipeapp.ui.theme.OnSurface
import com.example.jetpackcomposerecipeapp.ui.theme.OnSurfaceVariant
import com.example.jetpackcomposerecipeapp.ui.theme.SurfaceContainerLow

@Composable
fun InfoCard(
    modifier: Modifier = Modifier,
    icon: ImageVector,
    title: String,
    desc: String,
    iconColor: Color
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(
                SurfaceContainerLow,
                shape = RoundedCornerShape(12.dp)
            )
            .padding(12.dp)
    ) {
        Icon(icon, contentDescription = null, tint = iconColor)

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = title,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            color = OnSurface,
            maxLines = 1 // ✅ prevent uneven height
        )


        Text(
            text = desc,
            fontSize = 10.sp,
            color = OnSurfaceVariant,
            maxLines = 3, // ✅ consistent height
            lineHeight = 12.sp
        )
    }
}