package com.example.jetpackcomposerecipeapp.presentation.common.sharedcomponent

import androidx.compose.foundation.background
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowBackIosNew
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.example.jetpackcomposerecipeapp.ui.theme.PrimaryContainer
import com.example.jetpackcomposerecipeapp.ui.theme.SurfaceVariant


/*@Composable
fun CommonAppTopBar(
    topBarConfig: TopBarConfig,
    onBackClick: () -> Unit = {},
    onMenuClick: () -> Unit = {}
) {
    TopAppBar(
        title = { Text(text = topBarConfig.title, color = PrimaryContainer) },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = SurfaceVariant,
            titleContentColor = PrimaryContainer,
            navigationIconContentColor = PrimaryContainer,
            actionIconContentColor = PrimaryContainer
        ),
        navigationIcon = {
            when {
                topBarConfig.showBack -> {
                    IconButton(onClick = { onBackClick() }) {
                        Icon(
                            Icons.Filled.ArrowBack,
                            contentDescription = "back",
                            tint = PrimaryContainer
                        )
                    }
                }

                topBarConfig.showMenu -> {
                    IconButton(onClick = { onMenuClick() }) {
                        Icon(
                            Icons.Filled.Menu,
                            contentDescription = "menu",
                            tint = PrimaryContainer
                        )
                    }
                }
            }
        },
        actions = {
            topBarConfig.actions.forEach { action ->
                IconButton(onClick = action.onClick) {
                    Icon(action.icon, contentDescription = null, tint = PrimaryContainer)
                }
            }
        }
    )
}*/


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppTopBar(
    title: String,
    showBack: Boolean,
    showMenu: Boolean,
    onBackClick: () -> Unit,
    onMenuClick: () -> Unit
) {
    TopAppBar(
        title = { Text(title, color = PrimaryContainer) },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = SurfaceVariant,
            titleContentColor = PrimaryContainer,
            navigationIconContentColor = PrimaryContainer,
            actionIconContentColor = PrimaryContainer
        ),
        navigationIcon = {

            when {
                showBack -> {
                    IconButton(onClick = onBackClick) {
                        Icon(
                            Icons.Default.ArrowBackIosNew,
                            contentDescription = "Back",
                            tint = PrimaryContainer
                        )
                    }
                }

                showMenu -> {
                    IconButton(onClick = onMenuClick) {
                        Icon(
                            Icons.Default.Menu,
                            contentDescription = "Menu",
                            tint = PrimaryContainer
                        )
                    }
                }
            }
        }
    )
}