package com.example.jetpackcomposerecipeapp.presentation.ui.mealdetailscreen

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.jetpackcomposerecipeapp.data.model.RecipeDetailResponse
import com.example.jetpackcomposerecipeapp.presentation.ui.mealdetailscreen.components.HeroSection
import com.example.jetpackcomposerecipeapp.presentation.ui.mealdetailscreen.components.IngredientTabs
import com.example.jetpackcomposerecipeapp.presentation.ui.mealdetailscreen.components.MetaSection
import com.example.jetpackcomposerecipeapp.presentation.ui.mealdetailscreen.components.NutritionSection
import com.example.jetpackcomposerecipeapp.presentation.ui.mealdetailscreen.components.StepsSection
import com.example.jetpackcomposerecipeapp.presentation.ui.viewmodel.RecipeViewModel
import com.example.jetpackcomposerecipeapp.ui.theme.OnPrimary


@Composable
fun MealDetailScreen(meal: RecipeDetailResponse, viewModel: RecipeViewModel = hiltViewModel()) {
    val isFavorite by viewModel.isFavorite(meal.id).collectAsState(initial = false)
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(OnPrimary)
            .padding(16.dp)

    ) {

        item {
            HeroSection(
                meal, isFavorite = isFavorite,
                onFavoriteClick = {
                    viewModel.toggleFavorite(meal)
                })
        }

        item { MetaSection(meal) }

        item { NutritionSection(meal) }

        item { IngredientTabs(meal) }

        item { StepsSection(meal) }
    }

}