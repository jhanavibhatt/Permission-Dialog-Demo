package com.example.jetpackcomposerecipeapp.di

import com.example.jetpackcomposerecipeapp.data.remote.api.ApiService
import com.example.jetpackcomposerecipeapp.data.remote.api.JsonBinApiService
import com.example.jetpackcomposerecipeapp.utils.Constants
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Named
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {

    @Provides
    @Singleton
    fun provideLoggingInterceptor(): HttpLoggingInterceptor {
        return HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }
    }

    @Provides
    @Singleton
    fun provideOkHttpClient(
        loggingInterceptor: HttpLoggingInterceptor
    ): OkHttpClient {
        return OkHttpClient.Builder()
            .addInterceptor(loggingInterceptor)
            .build()
    }

    @Provides
    @Singleton
    @Named(Qualifiers.SPOONACULAR)
    fun provideRetrofit(
        okHttpClient: OkHttpClient
    ): Retrofit {
        return Retrofit.Builder()
            .baseUrl(Constants.BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create()) // 🔥 IMPORTANT
            .build()
    }
    @Provides
    @Singleton
    @Named(Qualifiers.JSONBIN)
    fun provideJsonBinRetrofit(
        okHttpClient: OkHttpClient
    ): Retrofit {
        return Retrofit.Builder()
            .baseUrl(Constants.JSON_BIN_BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }
    @Provides
    @Singleton
    fun provideApiService(
        @Named(Qualifiers.SPOONACULAR)   retrofit: Retrofit
    ): ApiService {
        return retrofit.create(ApiService::class.java)
    }
    @Provides
    @Singleton
    fun provideJsonBinApiService(
        @Named(Qualifiers.JSONBIN) retrofit: Retrofit
    ): JsonBinApiService {
        return retrofit.create(JsonBinApiService::class.java)
    }
}