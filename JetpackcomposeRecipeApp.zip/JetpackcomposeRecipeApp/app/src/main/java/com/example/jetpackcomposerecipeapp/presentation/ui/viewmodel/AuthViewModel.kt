package com.example.jetpackcomposerecipeapp.presentation.ui.viewmodel

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.jetpackcomposerecipeapp.data.repository.AuthRepository
import com.example.jetpackcomposerecipeapp.utils.AuthState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AuthViewModel @Inject constructor(
    private val repo: AuthRepository
) : ViewModel() {

    private val _loginState = MutableStateFlow<AuthState>(AuthState.Idle)
    val loginState: StateFlow<AuthState> = _loginState

    private val _signupState = MutableStateFlow<AuthState>(AuthState.Idle)
    val signupState: StateFlow<AuthState> = _signupState

    fun login(email: String, password: String) {
        viewModelScope.launch {
            _loginState.value = AuthState.Loading

            val success = repo.login(email, password)

            _loginState.value =
                if (success) AuthState.Success
                else AuthState.Error("Invalid credentials")
        }
    }

    fun signup(name: String, email: String, password: String) {
        viewModelScope.launch {
            _signupState.value = AuthState.Loading

            val success = repo.signup(name, email, password)

            _signupState.value =
                if (success) AuthState.Success
                else AuthState.Error("Signup failed")
        }
    }

    fun logout() {
        repo.logout()
    }
}