package com.example.jetpackcomposerecipeapp.presentation.ui.homescreen.components

import android.text.TextUtils
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.jetpackcomposerecipeapp.R
import com.example.jetpackcomposerecipeapp.data.model.RecipeDetailResponse

@Composable
fun TrendingRecipesList(recipe:List<RecipeDetailResponse>) {
//    val recipes = listOf(Recipe(
//        id = 1,
//        title = "Mediterranean Zest Bowl",
//        tag = "VEGAN",
//        tagBackgroundColor = Color(0xFFFFD700), // Yellow
//        time = "15 mins",
//        rating = 4.9,
//        imageRes = R.drawable.recipe_bg
//
//    ),
//        Recipe(
//            id = 1,
//            title = "Mediterranean Zest Bowl",
//            tag = "VEGAN",
//            tagBackgroundColor = Color(0xFFFFD700), // Yellow
//            time = "15 mins",
//            rating = 4.9,
//            imageRes = R.drawable.recipe_bg
//        ))
 Column(modifier = Modifier.fillMaxWidth()) {
     LazyRow(
         modifier = Modifier.fillMaxWidth(),
         horizontalArrangement = Arrangement.spacedBy(16.dp),
         contentPadding = PaddingValues(  horizontal = 16.dp)
     ){
         items(recipe) { recipe ->
             RecipeCard(recipe)
         }
     }
 }

}

@Composable
fun RecipeCard(recipe: RecipeDetailResponse) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.width(280.dp)
    ) {
        Column {
            // Image Section with Overlay
            Box(modifier = Modifier.height(200.dp).fillMaxWidth()) {
                AsyncImage(
                    model = recipe.image,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )


                Surface(
                    shape = CircleShape,
                    color = Color.White.copy(alpha = 0.3f),
                    modifier = Modifier
                        .padding(12.dp)
                        .size(36.dp)
                        .align(Alignment.TopEnd)
                ) {
                    Icon(
                        imageVector = Icons.Default.FavoriteBorder,
                        contentDescription = "Favorite",
                        tint = Color.White,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }

            Column(modifier = Modifier.padding(16.dp)) {
                val tag = when {
                    recipe.vegan -> "VEGAN"
                    recipe.vegetarian -> "VEG"
                    recipe.dishTypes?.contains("dessert") == true -> "DESSERT"
                    else -> "FOOD"
                }
                // Label Row
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = Color(0xFFFFD700),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = tag,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = " • Ready in ${recipe.readyInMinutes} mins",
                        color = Color.Gray,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(start = 4.dp)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = recipe.title,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(12.dp))


                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = null,
                            tint = Color(0xFF4CAF50), // Green star
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text =  (recipe.spoonacularScore?.div(20)).toString(),
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(start = 4.dp)
                        )
                    }

                    Text(
                        text = stringResource(R.string.view_recipe),
                        color = Color(0xFFE57373),
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }
        }
    }
}