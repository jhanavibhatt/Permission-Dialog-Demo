package com.example.jetpackcomposerecipeapp.presentation.ui.profilescreen

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.jetpackcomposerecipeapp.R
import com.example.jetpackcomposerecipeapp.presentation.ui.profilescreen.components.SettingsMenu
import com.example.jetpackcomposerecipeapp.presentation.ui.profilescreen.components.StatsSection
import com.example.jetpackcomposerecipeapp.presentation.ui.viewmodel.AuthViewModel
import com.example.jetpackcomposerecipeapp.ui.theme.OnPrimary
import com.example.jetpackcomposerecipeapp.ui.theme.activeContentColor

@Composable
fun ProfileScreen(
    viewModel: AuthViewModel = hiltViewModel(),
    onLogout: () -> Unit ) {
    var showLogoutDialog by remember { mutableStateOf(false) } // 👈 ADD HERE
    LazyColumn(
        modifier = Modifier.fillMaxSize()
            .background(OnPrimary),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        contentPadding = PaddingValues(16.dp)
    ) {
        item {
            Box(
                modifier = Modifier.size(140.dp)
            ) {

                Box(
                    modifier = Modifier
                        .size(120.dp)
                        .align(Alignment.Center)
                        .border(width = 4.dp, color = Color.LightGray, shape = CircleShape)
                        .padding(4.dp)
                        .clip(CircleShape)
                        .background(Color.White)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.profile_img), // Replace with your resource
                        contentDescription = "Profile Picture",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }
                SmallFloatingActionButton(
                    onClick = { /* Handle edit click */ },
                    shape = CircleShape,
                    containerColor = activeContentColor,
                    contentColor = Color.White,
                    modifier = Modifier
                        .size(36.dp)
                        .align(Alignment.BottomEnd)
                        .offset(x = (-8).dp, y = (-8).dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "Edit Profile",
                        modifier = Modifier.size(18.dp)
                    )

                }
            }
        }
        item {
            Spacer(Modifier.height(19.dp))
            Text(
                "Julian Thorne",
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Bold
            )
            Text(
                "julian.thorne@picurean.com",
                style = MaterialTheme.typography.bodyMedium,
                color = Color.Gray
            )
        }
        item {
            Spacer(Modifier.height(19.dp))
            StatsSection()
        }
        item {
            Spacer(Modifier.height(19.dp))
            SettingsMenu(
                onLogoutClick = {
                    showLogoutDialog = true
                }
                    )
        }
    }
    if (showLogoutDialog) {
        AlertDialog(
            modifier = Modifier.fillMaxWidth(),
            onDismissRequest = { showLogoutDialog = false },
            title = { Text(stringResource(R.string.logout)) },
            text = { Text(stringResource(R.string.logout_confirm)) },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.logout()
                        showLogoutDialog = false
                        onLogout()
                    }
                ) {
                    Text(stringResource(R.string.yes))
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showLogoutDialog = false }
                ) {
                    Text(stringResource(R.string.cancel))
                }
            }
        )
    }

}

