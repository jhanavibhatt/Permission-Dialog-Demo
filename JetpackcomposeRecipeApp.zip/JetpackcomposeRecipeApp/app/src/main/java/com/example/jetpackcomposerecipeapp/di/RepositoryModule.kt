//package com.example.jetpackcomposerecipeapp.di
//
//import com.example.jetpackcomposerecipeapp.data.remote.api.ApiService
//import com.example.jetpackcomposerecipeapp.data.repository.RecipeRepository
//import com.example.jetpackcomposerecipeapp.data.repository.RecipeRepositoryImpl
//import dagger.Module
//import dagger.Provides
//import dagger.hilt.InstallIn
//import dagger.hilt.components.SingletonComponent
//import javax.inject.Singleton
//
//@Module
//@InstallIn(SingletonComponent::class)
//object RepositoryModule {
//
//    @Provides
//    @Singleton
//    fun provideRecipeRepository(
//        apiService: ApiService,
//
//    ): RecipeRepository {
//        return RecipeRepositoryImpl(apiService)
//    }
//}