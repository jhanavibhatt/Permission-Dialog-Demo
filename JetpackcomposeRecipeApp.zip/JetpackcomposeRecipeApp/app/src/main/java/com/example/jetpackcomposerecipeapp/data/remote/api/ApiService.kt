package com.example.jetpackcomposerecipeapp.data.remote.api

import com.example.jetpackcomposerecipeapp.data.model.RandomRecipesResponse
import com.example.jetpackcomposerecipeapp.data.model.RecipeDetailResponse
import com.example.jetpackcomposerecipeapp.data.model.RecipeResponse
import com.example.jetpackcomposerecipeapp.utils.Constants
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {


    @GET("recipes/complexSearch")
    suspend fun getRecipesByCuisine(
        @Query("cuisine") cuisine: String,
        @Query("number") number: Int = 10,
        @Query("offset") offset: Int,
        @Query("apiKey") apiKey: String = Constants.API_KEY
    ): RecipeResponse

    @GET("recipes/{id}/information")
    suspend fun getRecipeDetails(
        @Path("id") id: Int,
        @Query("includeNutrition") includeNutrition: Boolean = true,
        @Query("apiKey") apiKey: String = Constants.API_KEY
    ): RecipeDetailResponse


    @GET("recipes/random")
    suspend fun getRandomRecipes(
        @Query("number") number: Int = 10,
        @Query("apiKey") apiKey: String = Constants.API_KEY
    ): RandomRecipesResponse


}