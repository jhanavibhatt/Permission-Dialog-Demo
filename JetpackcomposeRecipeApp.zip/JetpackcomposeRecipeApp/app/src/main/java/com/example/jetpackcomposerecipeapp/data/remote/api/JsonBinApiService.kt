package com.example.jetpackcomposerecipeapp.data.remote.api

import com.example.jetpackcomposerecipeapp.data.model.CuisineResponse
import retrofit2.http.GET

interface JsonBinApiService {
    @GET("v3/b/69d5f7bb856a6821890dcb44?meta=false")
    suspend fun getCuisines(): CuisineResponse
}