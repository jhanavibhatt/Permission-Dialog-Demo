package com.example.jetpackcomposerecipeapp.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "recipes")
data class RecipeDetailResponse(
    @PrimaryKey
    val id: Int,

    val title: String,
    val image: String,
    val readyInMinutes: Int,
    val healthScore: Int,
    val servings: Int?,
    val creditsText: String,

    val spoonacularScore: Double?,
    val aggregateLikes: Int?,
    val vegan: Boolean,
    val vegetarian: Boolean,
    val dishTypes: List<String>?,
    val extendedIngredients: List<Ingredient>,
    val analyzedInstructions: List<Instruction>,

    val nutrition: Nutrition?,
    val isFavorite: Boolean = false,
)

data class Ingredient(
    val name: String,
    val amount: Double,
    val unit: String
)

data class Instruction(
    val steps: List<Step>
)

data class Step(
    val number: Int,
    val step: String
)

data class Nutrition(
    val nutrients: List<Nutrient>
)

data class Nutrient(
    val name: String,
    val amount: Double,
    val unit: String
)