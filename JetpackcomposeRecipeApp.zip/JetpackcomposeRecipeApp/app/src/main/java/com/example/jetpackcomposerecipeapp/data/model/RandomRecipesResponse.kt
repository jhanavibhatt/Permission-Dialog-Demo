package com.example.jetpackcomposerecipeapp.data.model

data class RandomRecipesResponse(
    val recipes: List<RecipeDetailResponse>
)
