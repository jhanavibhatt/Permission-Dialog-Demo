package com.example.jetpackcomposerecipeapp.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.jetpackcomposerecipeapp.data.model.CategoryDto


@Dao
interface CuisineDao {

    @Query("SELECT * FROM cuisines")
    suspend fun getCuisines(): List<CategoryDto>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCuisines(cuisines: List<CategoryDto>)




}