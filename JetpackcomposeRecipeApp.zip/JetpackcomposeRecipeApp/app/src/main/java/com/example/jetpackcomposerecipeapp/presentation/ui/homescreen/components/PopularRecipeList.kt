package com.example.jetpackcomposerecipeapp.presentation.ui.homescreen.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.jetpackcomposerecipeapp.R


@Composable
fun  PopularRecipeList() {
    val recipe = listOf(
        PopularRecipe(
            "Classic Carbonara",
            "20 mins",
            4.7,
            R.drawable.italian
        ),
        PopularRecipe(
            "Classic Carbonara",
            "20 mins",
            4.7,
            R.drawable.american
        ),
        PopularRecipe(
            "Classic Carbonara",
            "20 mins",
            4.7,
            R.drawable.indian
        )
    )

    Column(modifier = Modifier.fillMaxWidth()) {
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(horizontal = 16.dp)
        ) {
            items(recipe) { recipe ->
                PopularRecipeCard(recipe)
            }
        }
    }
}
@Composable
fun PopularRecipeCard(recipe: PopularRecipe) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {

            Box(
                modifier = Modifier.size(200.dp)
                    .clip(
                        RoundedCornerShape(20.dp)
                    )
            ) {
                Image(
                    painter = painterResource(recipe.imageRes),
                    contentDescription = "recipe",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.matchParentSize()
                )
            }
            Spacer(Modifier.height(5.dp))
            Text(
                recipe.title,
                color = Color.Black,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Row(horizontalArrangement = Arrangement.Start) {
                Text(
                    recipe.time,
                    style = MaterialTheme.typography.titleSmall,
                    color = Color.Gray
                )
                Text(
                    text = "\u00B7",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.Gray
                )
                Text(
                    recipe.rating.toString(),
                    style = MaterialTheme.typography.titleSmall,
                    color = Color.Gray
                )
                Icon(
                    imageVector = Icons.Default.Star,
                    contentDescription = null,
                    modifier = Modifier.size(14.dp),
                    tint = Color.Gray
                )
            }

        }
}
