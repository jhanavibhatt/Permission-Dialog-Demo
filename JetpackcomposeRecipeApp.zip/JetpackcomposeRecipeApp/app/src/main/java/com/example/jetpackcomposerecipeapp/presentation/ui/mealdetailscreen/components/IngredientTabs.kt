package com.example.jetpackcomposerecipeapp.presentation.ui.mealdetailscreen.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.jetpackcomposerecipeapp.R
import com.example.jetpackcomposerecipeapp.data.model.RecipeDetailResponse

@Composable
fun IngredientTabs(meal: RecipeDetailResponse) {

    var selected by remember { mutableStateOf(0) }

    Column(Modifier.padding(16.dp)) {

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.LightGray, RoundedCornerShape(50))
        ) {

            TabButton(stringResource(R.string.ingredients), selected == 0) { selected = 0 }
            TabButton(stringResource(R.string.instructions), selected == 1) { selected = 1 }
        }

        Spacer(Modifier.height(16.dp))

        if (selected == 0) {
            IngredientsList(meal.extendedIngredients)
        } else {
            StepsSection(meal)
        }
    }
}

@Composable
fun RowScope.TabButton(title: String, isSelected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .weight(1f)
            .clickable { onClick() }
            .background(
                if (isSelected) Color(0xFFFF7A2B) else Color.Transparent,
                RoundedCornerShape(50)
            )
            .padding(12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(title, color = if (isSelected) Color.White else Color.Black)
    }
}