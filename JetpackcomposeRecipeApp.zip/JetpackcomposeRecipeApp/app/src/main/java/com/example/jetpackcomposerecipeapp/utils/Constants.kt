package com.example.jetpackcomposerecipeapp.utils

object Constants {

const val BASE_URL = "https://api.spoonacular.com/"
    const val API_KEY = "4c98b77a5b304ad280ec9817bcfbce14"
    const val JSON_BIN_BASE_URL = "https://api.jsonbin.io/"
}