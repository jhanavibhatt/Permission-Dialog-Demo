package com.example.jetpackcomposerecipeapp.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.jetpackcomposerecipeapp.data.model.Recipe
import com.example.jetpackcomposerecipeapp.data.model.RecipeDetailResponse
import kotlinx.coroutines.flow.Flow


@Dao
interface RecipeDao {

    @Query("SELECT * FROM recipes")
    suspend fun getRecipes(): List<RecipeDetailResponse>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecipes(recipes: List<RecipeDetailResponse>)

    @Query("DELETE FROM recipes")
    suspend fun clearRecipes()

    @Query("SELECT * FROM recipes WHERE isFavorite = 1")
    fun getFavoriteRecipesFlow(): Flow<List<RecipeDetailResponse>>

    @Query("SELECT isFavorite FROM recipes WHERE id = :id LIMIT 1")
    fun isFavorite(id: Int): Flow<Boolean>

    @Query("UPDATE recipes SET isFavorite = :isFav WHERE id = :id")
    suspend fun updateFavorite(id: Int, isFav: Boolean)

    @Query("SELECT * FROM recipes WHERE id = :id LIMIT 1")
    suspend fun getRecipeById(id: Int): RecipeDetailResponse?

    //  Get by cuisine
    @Query("SELECT * FROM cuisine_recipes_list WHERE cuisine = :cuisine ORDER BY offset ASC")
    suspend fun getRecipesByCuisine(cuisine: String): List<Recipe>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCuisineRecipes(recipes: List<Recipe>)

    @Query("UPDATE recipes SET isFavorite = 0")
    suspend fun clearAllFavorites()


}