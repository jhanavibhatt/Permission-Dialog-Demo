package com.example.jetpackcomposerecipeapp.presentation.ui.meallistScreen

import android.annotation.SuppressLint
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.jetpackcomposerecipeapp.presentation.navigation.AppRoute
import com.example.jetpackcomposerecipeapp.presentation.ui.meallistScreen.components.MealListGrid
import com.example.jetpackcomposerecipeapp.presentation.ui.viewmodel.RecipeViewModel
import com.example.jetpackcomposerecipeapp.ui.theme.OnPrimary

@SuppressLint("SuspiciousIndentation")
@Composable
fun MealListScreen(
    cuisine: String, navController: NavController,
    viewModel: RecipeViewModel = hiltViewModel()
) {

    val recipes by viewModel.recipes.collectAsState()


    LaunchedEffect(cuisine) {
        viewModel.loadInitial(cuisine)
    }

    Column(
        modifier = Modifier.fillMaxHeight()
            .background(OnPrimary)

    ) {

        MealListGrid(recipes, onLoadMore = {
            viewModel.loadMore(cuisine)
        }, onItemClick = { id ->
            navController.navigate(AppRoute.MealDetail(id))
        })

    }

}