package com.example.jetpackcomposerecipeapp.presentation.ui.profilescreen.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SettingsMenu(onLogoutClick: () -> Unit ) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        // --- Section 1 ---
        SectionHeader("ACCOUNT ACTIVITY")

        MenuCard(
            title = "My Recipes",
            subtitle = "View and edit your culinary creations",
            icon = Icons.Default.MenuBook,
            iconBgColor = Color(0xFFFFEAD1), // Light peach
            iconTintColor = Color(0xFF9E5233) // Brown
        )

        Spacer(modifier = Modifier.height(12.dp))

        MenuCard(
            title = "Settings",
            subtitle = "Preferences, Privacy, and Account",
            icon = Icons.Default.Settings,
            iconBgColor = Color(0xFFE8F5E9), // Light green
            iconTintColor = Color(0xFF3E603B) // Forest green
        )

        Spacer(modifier = Modifier.height(24.dp))

        // --- Section 2 ---
        SectionHeader("SYSTEM")

        MenuCard(
            title = "Logout",
            subtitle = "Sign out of your account",
            icon = Icons.AutoMirrored.Filled.Logout,
            iconBgColor = Color(0xFFFFEBEE), // Light red/pink
            iconTintColor = Color(0xFFB71C1C), // Dark red
            titleColor = Color(0xFFB71C1C),
            onClick = onLogoutClick // Logout title is often red
        )
    }
}

@Composable
fun SectionHeader(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelMedium.copy(
            color = Color.Gray,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        ),
        modifier = Modifier.padding(bottom = 12.dp, start = 4.dp)
    )
}

@Composable
fun MenuCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    iconBgColor: Color,
    iconTintColor: Color,
    titleColor: Color = Color(0xFF333333),
    onClick: () -> Unit = {}
) {
    Surface(
        modifier = Modifier.fillMaxWidth().clickable{onClick()},
        shape = RoundedCornerShape(16.dp),
        color = Color.White,
        shadowElevation = 1.dp // Subtle lift
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Rounded Icon Background
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(iconBgColor, RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTintColor,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            // Text Content
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = titleColor
                    )
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = Color.Gray
                    )
                )
            }

            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = Color(0xFFCCCCCC)
            )
        }
    }
}