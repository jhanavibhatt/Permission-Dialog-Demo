package com.example.jetpackcomposerecipeapp.di

object Qualifiers {
    const val SPOONACULAR = "spoonacular"
    const val JSONBIN = "jsonbin"
}