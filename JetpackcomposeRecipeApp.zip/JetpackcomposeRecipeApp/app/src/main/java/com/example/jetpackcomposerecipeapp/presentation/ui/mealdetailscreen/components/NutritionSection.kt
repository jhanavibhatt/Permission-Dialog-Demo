package com.example.jetpackcomposerecipeapp.presentation.ui.mealdetailscreen.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.jetpackcomposerecipeapp.R
import com.example.jetpackcomposerecipeapp.data.model.RecipeDetailResponse

@Composable
fun NutritionSection(meal: RecipeDetailResponse) {
    val nutrients = meal.nutrition?.nutrients ?: emptyList()

    fun getValue(name: String): String {
        return nutrients.find { it.name.equals(name, true) }?.amount?.toString() ?: "0"
    }
    Column(Modifier.padding(16.dp)) {

        Text(stringResource(R.string.nutritional_profile), fontWeight = FontWeight.Bold)



        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.height(200.dp)
        ) {

            item { NutritionItem(stringResource(R.string.protein), "${getValue("Protein")}g") }
            item { NutritionItem(stringResource(R.string.carbs), "${getValue("Carbohydrates")}g") }
            item { NutritionItem(stringResource(R.string.fat), "${getValue("Fat")}g") }
            item { NutritionItem(stringResource(R.string.fiber), "${getValue("Fiber")}g") }
        }
    }
}

@Composable
fun NutritionItem(title: String, value: String) {
    Card(
        modifier = Modifier
            .padding(6.dp)
            .fillMaxWidth(),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(Modifier.padding(12.dp)) {
            Text(title, fontSize = 12.sp)
            Text(value, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
    }
}