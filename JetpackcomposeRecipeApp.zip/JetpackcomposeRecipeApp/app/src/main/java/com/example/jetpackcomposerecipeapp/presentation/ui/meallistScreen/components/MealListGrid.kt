package com.example.jetpackcomposerecipeapp.presentation.ui.meallistScreen.components

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.jetpackcomposerecipeapp.data.model.Recipe

@Composable
fun MealListGrid( meals: List<Recipe>, onLoadMore: () -> Unit,  onItemClick: (Int) -> Unit){
    val listState = rememberLazyListState()

    // 🔥 Load more when last item visible
    LaunchedEffect(meals.size) {
        snapshotFlow {
            listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index
        }.collect { lastVisibleIndex ->

            if (lastVisibleIndex != null &&
                lastVisibleIndex >= meals.size - 3
            ) {
                onLoadMore()
            }
        }
    }
    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(10.dp),
    ){

        items(meals) { recipe->
            MealListCard(recipe=recipe, onClick = onItemClick)
        }
    }
}