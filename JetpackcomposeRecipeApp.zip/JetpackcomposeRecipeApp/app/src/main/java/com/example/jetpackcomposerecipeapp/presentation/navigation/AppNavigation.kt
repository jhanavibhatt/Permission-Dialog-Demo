package com.example.jetpackcomposerecipeapp.presentation.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.jetpackcomposerecipeapp.presentation.ui.loginscreen.LoginScreen
import com.example.jetpackcomposerecipeapp.presentation.ui.mainscreen.MainScreen
import com.example.jetpackcomposerecipeapp.presentation.ui.signupscreen.SignUpScreen
import com.example.jetpackcomposerecipeapp.presentation.ui.splashscreen.SplashScreen
import com.example.jetpackcomposerecipeapp.utils.PrefsManager
import kotlinx.coroutines.delay

@Composable
fun AppNavigation() {

    val navController = rememberNavController()
    val context = LocalContext.current
    val prefs = remember { PrefsManager(context) }

    NavHost(
        navController = navController,
        startDestination = AppRoute.Splash
    ) {

        composable<AppRoute.Splash> {
            LaunchedEffect(Unit) {
                delay(2000)

                if (prefs.isLoggedIn()) {
                    navController.navigate(AppRoute.Home) {
                        popUpTo(AppRoute.Splash) { inclusive = true }
                    }
                } else {
                    navController.navigate(AppRoute.Login) {
                        popUpTo(AppRoute.Splash) { inclusive = true }
                    }
                }
            }

            SplashScreen()
        }

        composable<AppRoute.Login> {
            LoginScreen(
                onLoginSuccess = {
                    navController.navigate(AppRoute.Home) {
                        popUpTo(AppRoute.Login) { inclusive = true }
                    }
                },
                onSignUpClick = {
                    navController.navigate(AppRoute.Signup)
                }
            )
        }

        composable<AppRoute.Signup> {
            SignUpScreen(
                onSignUpSuccess = {
                    navController.navigate(AppRoute.Home) {
                        popUpTo(AppRoute.Signup) { inclusive = true }
                    }
                },
                onLoginClick = {
                    navController.popBackStack()
                }
            )
        }


        composable<AppRoute.Home> {
            MainScreen(navController)
        }


    }
}