package com.example.jetpackcomposerecipeapp.presentation.ui.meallistScreen.components

data class Meal(
    val title: String,
    val image : Int
)
