package com.example.jetpackcomposerecipeapp.presentation.ui.loginscreen.components

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.jetpackcomposerecipeapp.R
import com.example.jetpackcomposerecipeapp.presentation.common.sharedcomponent.CommonButton
import com.example.jetpackcomposerecipeapp.ui.theme.Primary
import com.example.jetpackcomposerecipeapp.ui.theme.Surface
import com.example.jetpackcomposerecipeapp.utils.PrefsManager


@Composable
fun WelcomeCard(onMessage: (String) -> Unit,onLoginSuccess: (String, String) -> Unit ) {

    val context = LocalContext.current
    val prefs = remember { PrefsManager(context) }

    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    Card(
        modifier = Modifier.fillMaxWidth().wrapContentHeight().padding(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F5F5)),
        shape = RoundedCornerShape(32.dp)

    ){

        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {


            Text(
                stringResource(R.string.login_screen_welcome_text),
                style = MaterialTheme.typography.headlineSmall,
                color = Color.Black,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(16.dp))

            AppTextField(
                value = email,
                onValueChange = {email=it},
                hint = stringResource(R.string.email_hint),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(16.dp))
            AppTextField(
                value = password,
                onValueChange = {password=it},
                hint = stringResource(R.string.password_hint),
                modifier = Modifier.fillMaxWidth(),
            )
            Text(
                stringResource(R.string.forgot_password), modifier = Modifier
                    .fillMaxWidth()
                    .wrapContentWidth(Alignment.End), color = Primary, fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(16.dp))
            CommonButton(text = stringResource(R.string.login_btn), onClick = {
                val success = prefs.login(email, password)

                if (success) {
                    prefs.setLoggedIn(true)
                    onMessage("Login Success")
                    onLoginSuccess(email, password)
                } else {
                    onMessage("Invalid Credentials")
                }
            })

            Spacer(Modifier.height(16.dp))


            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {

                HorizontalDivider(
                    modifier = Modifier.weight(1f),
                    thickness = 1.dp,
                    color = Color.LightGray.copy(alpha = 0.5f)
                )

                Text(
                    text = stringResource(R.string.or_continue),
                    modifier = Modifier.padding(horizontal = 16.dp),
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.DarkGray
                )

                HorizontalDivider(
                    modifier = Modifier.weight(1f),
                    thickness = 1.dp,
                    color = Color.LightGray.copy(alpha = 0.5f)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth()  ,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {

                LoginOptionsBtn(
                    stringResource(R.string.google_ntn),
                    painterResource(R.drawable.ic_google),
                    Surface,
                    Color.Black,
                    modifier = Modifier.weight(1f)
                )

                LoginOptionsBtn(
                    stringResource(R.string.apple_btn),
                    painterResource(R.drawable.ic_ios),
                    Color.Black,
                    Color.White,
                    modifier = Modifier.weight(1f)
                )

            }
        }


    }

}