package com.example.jetpackcomposerecipeapp.presentation.ui.loginscreen

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.jetpackcomposerecipeapp.R
import com.example.jetpackcomposerecipeapp.presentation.common.sharedcomponent.ClickableAnnotatedText
import com.example.jetpackcomposerecipeapp.presentation.ui.loginscreen.components.WelcomeCard
import com.example.jetpackcomposerecipeapp.presentation.ui.viewmodel.AuthViewModel
import com.example.jetpackcomposerecipeapp.ui.theme.OnPrimary
import com.example.jetpackcomposerecipeapp.ui.theme.Primary
import com.example.jetpackcomposerecipeapp.ui.theme.Secondary
import com.example.jetpackcomposerecipeapp.utils.AuthState
import com.example.jetpackcomposerecipeapp.utils.showAppSnackbar
import kotlinx.coroutines.launch

@Composable
fun LoginScreen(
    viewModel: AuthViewModel = hiltViewModel(),
    onLoginSuccess: () -> Unit,
    onSignUpClick: () -> Unit) {
    val state = viewModel.loginState.collectAsState().value

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    LaunchedEffect(state) {
        when (state) {
            is AuthState.Success -> {
                showAppSnackbar(snackbarHostState, "Login Success")
                onLoginSuccess()
            }

            is AuthState.Error -> {
                showAppSnackbar(snackbarHostState, state.message)
            }

            else -> Unit
        }
    }
    when (state) {
        is AuthState.Loading -> {
            CircularProgressIndicator()
        }

        is AuthState.Error -> {
            Toast.makeText(
                LocalContext.current,
                state.message,
                Toast.LENGTH_SHORT
            ).show()
        }

        else -> Unit
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->

        Column(
            modifier = Modifier.fillMaxSize()
                .background(OnPrimary).padding(padding).padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {


            Box(
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .size(80.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .background(Primary),
                contentAlignment = Alignment.Center

            ) {
                Icon(
                    imageVector = Icons.Default.Restaurant,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(36.dp)
                )
            }
            Spacer(Modifier.height(10.dp))
            Text(
                text = stringResource(R.string.login_screen_title),
                style = MaterialTheme.typography.headlineMedium,
                color = Color.Black,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = stringResource(R.string.login_screen_subtitle),
                style = MaterialTheme.typography.bodyMedium,
                color = Color.Gray,
                fontWeight = FontWeight.Bold
            )

            Spacer(Modifier.height(16.dp))

            WelcomeCard(
                onLoginSuccess = { email, password ->
                    viewModel.login(email, password)
                }, onMessage = { message ->
                    scope.launch {
                        showAppSnackbar(snackbarHostState, message)
                    }
                }
            )

            Spacer(Modifier.height(16.dp))


            ClickableAnnotatedText(
                normalText = stringResource(R.string.login_screen_annotated_text),
                clickableText = stringResource(R.string.sign_up_btn),
                clickableColor = Secondary,
                onClick = { onSignUpClick() },
            )


        }
    }

}
