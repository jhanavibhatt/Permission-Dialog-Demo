package com.example.jetpackcomposerecipeapp.data.repository

import com.example.jetpackcomposerecipeapp.data.model.CategoryDto
import com.example.jetpackcomposerecipeapp.data.model.RandomRecipesResponse
import com.example.jetpackcomposerecipeapp.data.model.Recipe
import com.example.jetpackcomposerecipeapp.data.model.RecipeDetailResponse
import com.example.jetpackcomposerecipeapp.utils.UiState
import kotlinx.coroutines.flow.Flow

interface RecipeRepository {
    fun getRecipesByCuisine(cuisine: String,offset: Int): Flow<UiState<List<Recipe>>>

    fun getRecipeDetails(id: Int): Flow<UiState<RecipeDetailResponse>>

    fun getRandomRecipes(): Flow<UiState<List<RecipeDetailResponse>>>


    fun getCuisines(): Flow<UiState<List<CategoryDto>>>

    suspend fun toggleFavorite(recipe: RecipeDetailResponse)

    fun getFavorites(): Flow<List<RecipeDetailResponse>>

    fun isFavorite(id: Int): Flow<Boolean>
    suspend fun clearFavorites()
}



