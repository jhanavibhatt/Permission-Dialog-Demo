package com.example.jetpackcomposerecipeapp.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)



val Primary = Color(0xFF9A4000)
val OnPrimary = Color(0xFFFFF0EA)

val Background = Color(0xFFFEF4F2)
val Surface = Color(0xFFFDF5F2)

val SurfaceContainerLow = Color(0xFFF8EFEC)
val SurfaceVariant = Color(0xFFFFF5F5)

val OnSurface = Color(0xFF322E2D)

val OnSurfaceVariant = Color(0xFF605A59)

val Secondary = Color(0xFF386631)

val Secondary_dim = Color(color = 0xFFabdf9e)
val Tertiary = Color(0xFF755700)

val PrimaryContainer = Color(0xFFFF7A2B)

val activeContentColor = Color(0xFF9E5233)
//ed6e1d
val OnPrimaryContainer = Color(0xFF401600)