package com.example.jetpackcomposerecipeapp.presentation.common.sharedcomponent

import androidx.compose.ui.graphics.vector.ImageVector

data class TopBarConfig(
    val title: String = "",
    val showBack: Boolean = false,
    val showMenu: Boolean = false,
    val actions: List<TopBarAction> = emptyList()
)

data class TopBarAction(
    val icon: ImageVector,
    val onClick: () -> Unit
)