package com.example.jetpackcomposerecipeapp.presentation.ui.splashscreen

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.jetpackcomposerecipeapp.R
import com.example.jetpackcomposerecipeapp.presentation.common.sharedcomponent.CommonButton
import com.example.jetpackcomposerecipeapp.presentation.ui.splashscreen.components.InfoCard
import com.example.jetpackcomposerecipeapp.ui.theme.Background
import com.example.jetpackcomposerecipeapp.ui.theme.OnPrimaryContainer
import com.example.jetpackcomposerecipeapp.ui.theme.OnSurface
import com.example.jetpackcomposerecipeapp.ui.theme.OnSurfaceVariant
import com.example.jetpackcomposerecipeapp.ui.theme.Primary
import com.example.jetpackcomposerecipeapp.ui.theme.PrimaryContainer
import com.example.jetpackcomposerecipeapp.ui.theme.Secondary
import com.example.jetpackcomposerecipeapp.ui.theme.Tertiary


@Composable
@Preview(showBackground = true)
fun SplashScreen(){
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Background)
    ) {


        Image(
            painter = painterResource(id = R.drawable.food_bg), // replace with your image
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.75f)
        )


        Box(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.75f)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Transparent,
                            Background.copy(alpha = 0.9f),
                            Background
                        )
                    )
                )
        )

        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(horizontal = 24.dp, vertical = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Spacer(modifier = Modifier.height(32.dp))

            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .background(PrimaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Restaurant,
                    contentDescription = null,
                    tint = OnPrimaryContainer,
                    modifier = Modifier.size(36.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            //  Title
            Text(
                text = "The Epicurean",
                fontSize = 32.sp,
                fontWeight = FontWeight.ExtraBold,
                color = OnSurface
            )

            Text(
                text = "Curate your kitchen, master your craft.",
                fontSize = 16.sp,
                color = OnSurfaceVariant,
                modifier = Modifier.padding(top = 6.dp)
            )

            Spacer(modifier = Modifier.height(28.dp))


            Row(
                modifier = Modifier.fillMaxWidth()  ,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                InfoCard(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Default.AutoAwesome,
                    title = "Smart Prep",
                    desc = "AI-driven ingredient scaling for any guest list.",
                    iconColor = Secondary
                )

                InfoCard(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Default.MenuBook,
                    title = "Curated Collections",
                    desc = "Hand-picked recipes from world-class chefs.",
                    iconColor = Tertiary
                )
            }

            Spacer(modifier = Modifier.height(32.dp))


        }
    }
}

