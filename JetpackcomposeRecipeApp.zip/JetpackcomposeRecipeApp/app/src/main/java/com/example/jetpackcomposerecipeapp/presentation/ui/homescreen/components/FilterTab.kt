package com.example.jetpackcomposerecipeapp.presentation.ui.homescreen.components

data class FilterTab(
    val name: String,
    val diet: String? = null,
    val minProtein: Int? = null
)