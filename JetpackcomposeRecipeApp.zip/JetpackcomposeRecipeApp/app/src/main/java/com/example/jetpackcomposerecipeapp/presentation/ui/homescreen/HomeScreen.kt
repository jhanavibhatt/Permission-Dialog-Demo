package com.example.jetpackcomposerecipeapp.presentation.ui.homescreen

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.jetpackcomposerecipeapp.R
import com.example.jetpackcomposerecipeapp.presentation.navigation.AppRoute
import com.example.jetpackcomposerecipeapp.presentation.ui.homescreen.components.CuisineCategoryGrid
import com.example.jetpackcomposerecipeapp.presentation.ui.homescreen.components.CustomSearchBar
import com.example.jetpackcomposerecipeapp.presentation.ui.homescreen.components.PopularRecipeList
import com.example.jetpackcomposerecipeapp.presentation.ui.homescreen.components.RecipeCardOfDay
import com.example.jetpackcomposerecipeapp.presentation.ui.homescreen.components.TrendingRecipesList
import com.example.jetpackcomposerecipeapp.presentation.ui.viewmodel.RecipeViewModel
import com.example.jetpackcomposerecipeapp.ui.theme.OnPrimary

@Composable
fun HomeScreen(navController: NavController, viewModel: RecipeViewModel = hiltViewModel()) {
    var query by remember { mutableStateOf("") }
    val trendingRecipes by viewModel.trendingRecipes.collectAsState()

    val cuisinesState by viewModel.cuisines.collectAsState()
    LaunchedEffect(Unit) {
        viewModel.getRandomRecipes()
    }
    LaunchedEffect(Unit) {
        viewModel.getCuisines()
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxWidth()
            .background(OnPrimary),
        contentPadding = PaddingValues(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(15.dp)
    ) {

        item {
            Spacer(Modifier.height(8.dp))
            CustomSearchBar(
                query = query,
                onQueryChange = { query = it }
            )
        }
        item { RecipeCardOfDay() }

        item {
            Text(
                stringResource(R.string.cuisine),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            Text(
                stringResource(R.string.cuisine_title),
                color = Color.Gray,
                style = MaterialTheme.typography.bodyMedium
            )
        }

        item {
            CuisineCategoryGrid(  cuisines = cuisinesState,
                onCuisineClick = { cuisine ->
                navController.navigate(
                    AppRoute.MealList(cuisine.lowercase())
                )
            })
        }


        item {
            Text(
                text = stringResource(R.string.trending_recipes),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
        }

        item { TrendingRecipesList(trendingRecipes)
        Spacer(Modifier.height(16.dp))}

//        item {
//            Text(
//                text = "Popular Recipes",
//                style = MaterialTheme.typography.headlineSmall,
//                fontWeight = FontWeight.Bold
//            )
//        }
//
//        item { PopularRecipeList() }
    }
}



