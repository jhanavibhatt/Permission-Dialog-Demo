package com.example.jetpackcomposerecipeapp.utils

import androidx.room.TypeConverter
import com.google.gson.Gson
import com.example.jetpackcomposerecipeapp.data.model.Ingredient
import com.example.jetpackcomposerecipeapp.data.model.Instruction
import com.example.jetpackcomposerecipeapp.data.model.Nutrition
import com.google.gson.reflect.TypeToken


class Converters {

    private val gson = Gson()

    @TypeConverter
    fun fromList(value: List<String>): String = value.joinToString(",")

    @TypeConverter
    fun toList(value: String): List<String> = value.split(",")

    // 🔹 List<ExtendedIngredient>
    @TypeConverter
    fun fromIngredientList(value: List<Ingredient>?): String {
        return gson.toJson(value)
    }

    @TypeConverter
    fun toIngredientList(value: String): List<Ingredient> {
        val type = object : TypeToken<List<Ingredient>>() {}.type
        return gson.fromJson(value, type)
    }

    // 🔹 List<AnalyzedInstruction>
    @TypeConverter
    fun fromInstructionList(value: List<Instruction>?): String {
        return gson.toJson(value)
    }

    @TypeConverter
    fun toInstructionList(value: String): List<Instruction> {
        val type = object : TypeToken<List<Instruction>>() {}.type
        return gson.fromJson(value, type)
    }

    // 🔹 Nutrition → String
    @TypeConverter
    fun fromNutrition(value: Nutrition?): String {
        return gson.toJson(value)
    }

    // 🔹 String → Nutrition
    @TypeConverter
    fun toNutrition(value: String): Nutrition? {
        val type = object : TypeToken<Nutrition>() {}.type
        return gson.fromJson(value, type)
    }
}