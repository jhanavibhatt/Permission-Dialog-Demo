package com.example.jetpackcomposerecipeapp.data.model

data class RecipeResponse(
    val number: Int,
    val offset: Int,
    val results: List<Recipe>,
    val totalResults: Int
)