package com.example.jetpackcomposerecipeapp.di

import android.content.Context
import androidx.room.Room
import com.example.jetpackcomposerecipeapp.dao.CuisineDao
import com.example.jetpackcomposerecipeapp.dao.RecipeDao
import com.example.jetpackcomposerecipeapp.data.remote.api.ApiService
import com.example.jetpackcomposerecipeapp.data.remote.api.JsonBinApiService
import com.example.jetpackcomposerecipeapp.data.repository.AuthRepository
import com.example.jetpackcomposerecipeapp.data.repository.RecipeRepository
import com.example.jetpackcomposerecipeapp.data.repository.RecipeRepositoryImpl
import com.example.jetpackcomposerecipeapp.database.RecipeDataBase
import com.example.jetpackcomposerecipeapp.utils.PrefsManager
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object  AppModule {
    @Singleton
    @Provides
    fun provideRecipeDatabase(@ApplicationContext context: Context): RecipeDataBase {
        return Room.databaseBuilder(
            context,
            RecipeDataBase::class.java,
            "recipe_db"
        )
            .fallbackToDestructiveMigration(true)
            .build()
    }

    @Singleton
    @Provides
    fun provideRecipeDao(db: RecipeDataBase) = db.recipeDao()


    @Singleton
    @Provides
    fun provideCuisineDao(db: RecipeDataBase) = db.cuisineDao()


    @Singleton
    @Provides
    fun provideRecipeRepository(apiService: ApiService, jsonBinApiService: JsonBinApiService, recipeDao: RecipeDao,cuisineDao: CuisineDao): RecipeRepository {
        return RecipeRepositoryImpl(apiService, jsonBinApiService,recipeDao,cuisineDao)
    }

    @Provides
    fun providePrefsManager(
        @ApplicationContext context: Context
    ): PrefsManager = PrefsManager(context)

    @Provides
    fun provideAuthRepository(
        prefs: PrefsManager
    ): AuthRepository = AuthRepository(prefs)

}