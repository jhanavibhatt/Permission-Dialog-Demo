package com.example.jetpackcomposerecipeapp.presentation.ui.signupscreen.components

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.jetpackcomposerecipeapp.presentation.common.sharedcomponent.ClickableAnnotatedText
import com.example.jetpackcomposerecipeapp.presentation.common.sharedcomponent.CommonButton
import com.example.jetpackcomposerecipeapp.ui.theme.Primary
import com.example.jetpackcomposerecipeapp.utils.PrefsManager

@Composable
fun CreateAccountCard(context: Context = LocalContext.current,onSignUpSuccess: (String, String, String) -> Unit) {
    var checked = remember { mutableStateOf(false) }
    val prefs = remember { PrefsManager(context) }

    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    Card(
        modifier = Modifier.fillMaxWidth().wrapContentHeight().padding(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F5F5)),
        shape = RoundedCornerShape(32.dp)
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Create an Account",
                style = MaterialTheme.typography.headlineMedium,
                color = Color.Black,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Start your culinary journey with us today",
                style = MaterialTheme.typography.bodyMedium,
                color = Color.Gray,
                fontWeight = FontWeight.Bold
            )

            Spacer(Modifier.padding(16.dp))

            AppIconTextField(
                value = name,
                onValueChange = {name=it},
                hint = "Full Name",
                leadingIcon = Icons.Default.Person
            )
            Spacer(Modifier.height(16.dp))
            AppIconTextField(
                value =email,
                onValueChange = {email=it},
                hint = "Email Address",
                leadingIcon = Icons.Default.Email
            )
            Spacer(Modifier.height(16.dp))
            AppIconTextField(
                value = password,
                onValueChange = {password=it},
                hint = "Password",
                leadingIcon = Icons.Default.Lock,
                isPassword = true
            )
            Spacer(Modifier.height(16.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
            )
            {
                StyledCheckBox()

                Spacer(Modifier.width(6.dp))

                ClickableAnnotatedText(
                    normalText = "I agree to the ",
                    clickableText = "Terms & Conditions \n and Private Policy",
                    clickableColor = Primary,
                    onClick = { },
                    fontSize = 14.sp
                )
            }
            Spacer(Modifier.height(16.dp))
            CommonButton(
                text = "Sign Up",
                onClick = {
                    prefs.saveUser(name, email, password)
                    prefs.setLoggedIn(true)
                    onSignUpSuccess(name, email, password)
                }
            )
        }
    }
}