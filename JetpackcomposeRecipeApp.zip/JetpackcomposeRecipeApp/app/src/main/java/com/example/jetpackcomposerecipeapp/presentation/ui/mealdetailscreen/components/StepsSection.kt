package com.example.jetpackcomposerecipeapp.presentation.ui.mealdetailscreen.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.jetpackcomposerecipeapp.R
import com.example.jetpackcomposerecipeapp.data.model.RecipeDetailResponse

@Composable
fun StepsSection(meal: RecipeDetailResponse) {
    val steps = if (meal.analyzedInstructions.isNotEmpty()) {
        meal.analyzedInstructions.flatMap { it.steps }
    } else {
        emptyList()
    }

    Column(Modifier.padding(16.dp)) {

        Text(stringResource(R.string.steps), fontWeight = FontWeight.Bold)


        steps.forEachIndexed { index, step ->

            Row(Modifier.padding(vertical = 8.dp)) {

                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .background(Color(0xFFFF7A2B), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text("${index + 1}", color = Color.White)
                }

                Spacer(Modifier.width(12.dp))

                Card(shape = RoundedCornerShape(16.dp)) {
                    Text(
                        step.step,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }
        }
    }
}