package com.example.jetpackcomposerecipeapp.data.repository

import com.example.jetpackcomposerecipeapp.utils.PrefsManager
import javax.inject.Inject

class AuthRepository @Inject constructor(
    private val prefs: PrefsManager
) {

    fun login(email: String, password: String): Boolean {
        val success = prefs.login(email, password)
        if (success) prefs.setLoggedIn(true)
        return success
    }

    fun signup(name: String, email: String, password: String): Boolean {
        prefs.saveUser(name, email, password)
        prefs.setLoggedIn(true)
        return true
    }

    fun logout() {
        prefs.logout()
    }

}