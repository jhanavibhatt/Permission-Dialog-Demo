package com.example.jetpackcomposerecipeapp.presentation.ui.mealdetailscreen

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.jetpackcomposerecipeapp.presentation.ui.viewmodel.RecipeViewModel

@Composable
fun MealDetailRoute(
    id: Int,
    viewModel: RecipeViewModel = hiltViewModel()
) {

    val state by viewModel.recipeDetails.collectAsState()

    LaunchedEffect(id) {
        viewModel.getRecipeDetails(id)
    }

    when {

        state == null -> {
            Box(
                Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
        }

        else -> {
            MealDetailScreen(meal = state!!)
        }
    }
}