package com.example.jetpackcomposerecipeapp.presentation.ui.homescreen.components

import androidx.annotation.DrawableRes
import androidx.compose.ui.graphics.Color

data class Recipe(
    val id: Int,
    val title: String,
    val tag: String,
    val tagBackgroundColor: Color = Color(0xFFFFD700),
    val time: String,
    val rating: Double,
    @DrawableRes val imageRes: Int,
    val isFavorite: Boolean = false
)
