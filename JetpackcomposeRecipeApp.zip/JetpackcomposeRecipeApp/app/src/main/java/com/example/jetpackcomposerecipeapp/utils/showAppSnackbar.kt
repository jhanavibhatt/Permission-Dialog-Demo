package com.example.jetpackcomposerecipeapp.utils

import androidx.compose.material3.SnackbarHostState


suspend fun showAppSnackbar(
    snackbarHostState: SnackbarHostState,
    message: String
) {
    snackbarHostState.showSnackbar(message)
}