package com.example.jetpackcomposerecipeapp.presentation.ui.signupscreen

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.jetpackcomposerecipeapp.R
import com.example.jetpackcomposerecipeapp.presentation.common.sharedcomponent.ClickableAnnotatedText
import com.example.jetpackcomposerecipeapp.presentation.ui.signupscreen.components.CreateAccountCard
import com.example.jetpackcomposerecipeapp.presentation.ui.viewmodel.AuthViewModel
import com.example.jetpackcomposerecipeapp.ui.theme.OnPrimary
import com.example.jetpackcomposerecipeapp.ui.theme.Primary
import com.example.jetpackcomposerecipeapp.utils.AuthState
import com.example.jetpackcomposerecipeapp.utils.showAppSnackbar
import kotlinx.coroutines.launch


@Composable
fun SignUpScreen(
    viewModel: AuthViewModel = hiltViewModel(),
    onSignUpSuccess: () -> Unit,
    onLoginClick: () -> Unit ) {
    val state = viewModel.signupState.collectAsState().value
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    LaunchedEffect(state) {
        when (state) {

            is AuthState.Success -> {
                scope.launch {
                    showAppSnackbar(snackbarHostState, "User Registered")
                }
                onSignUpSuccess()
            }

            is AuthState.Error -> {
                scope.launch {
                    showAppSnackbar(snackbarHostState, state.message)
                }
            }

            else -> Unit
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize()
                .background(OnPrimary).padding(padding)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {

            CreateAccountCard(
                onSignUpSuccess = { name, email, password ->
                    viewModel.signup(name, email, password)
                })
            Spacer(Modifier.height(16.dp))

            ClickableAnnotatedText(
                normalText = stringResource(R.string.conform_login),
                clickableText = stringResource(R.string.login_btn),
                clickableColor = Primary,
                onClick = { onLoginClick() },
            )


        }
    }
}
