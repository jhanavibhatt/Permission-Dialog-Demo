package com.example.jetpackcomposerecipeapp

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class RecipeApp: Application() {

}