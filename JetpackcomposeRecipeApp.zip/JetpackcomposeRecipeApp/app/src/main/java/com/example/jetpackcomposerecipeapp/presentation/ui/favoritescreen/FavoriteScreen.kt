package com.example.jetpackcomposerecipeapp.presentation.ui.favoritescreen

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.jetpackcomposerecipeapp.R
import com.example.jetpackcomposerecipeapp.presentation.ui.favoritescreen.components.FavoriteRecipe
import com.example.jetpackcomposerecipeapp.presentation.ui.favoritescreen.components.HeaderSection
import com.example.jetpackcomposerecipeapp.presentation.ui.favoritescreen.components.HeroCard
import com.example.jetpackcomposerecipeapp.presentation.ui.viewmodel.RecipeViewModel
import com.example.jetpackcomposerecipeapp.ui.theme.OnPrimary

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun FavoriteScreen(viewModel: RecipeViewModel = hiltViewModel()) {

    val favoriteRecipes by viewModel.favoriteRecipes.collectAsState(initial = emptyList())

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(OnPrimary)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {

        item {
            HeaderSection()
        }

        items(favoriteRecipes) { recipe ->
            HeroCard(recipe)
        }
    }
}