package com.example.jetpackcomposerecipeapp.presentation.navigation

import kotlinx.serialization.Serializable

@Serializable
sealed class AppRoute {
    @Serializable
    data object Splash : AppRoute()

    @Serializable
    data object Login : AppRoute()

    @Serializable
    data object Signup : AppRoute()

    // Main
    @Serializable
    data object Home : AppRoute()

    @Serializable
    data class MealList(val cuisine: String) : AppRoute()


    @Serializable
    data class MealDetail(val id: Int): AppRoute()

    @Serializable
    data object Favorites : AppRoute()

    @Serializable
    data object Profile : AppRoute()
}
