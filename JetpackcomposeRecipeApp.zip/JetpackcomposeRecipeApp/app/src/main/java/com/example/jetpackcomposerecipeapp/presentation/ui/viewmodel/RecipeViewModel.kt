        package com.example.jetpackcomposerecipeapp.presentation.ui.viewmodel

        import androidx.lifecycle.ViewModel
        import androidx.lifecycle.viewModelScope
        import com.example.jetpackcomposerecipeapp.data.model.CategoryDto
        import com.example.jetpackcomposerecipeapp.data.model.Recipe
        import com.example.jetpackcomposerecipeapp.data.model.RecipeDetailResponse
        import com.example.jetpackcomposerecipeapp.data.remote.RetrofitClient.api
        import com.example.jetpackcomposerecipeapp.data.repository.RecipeRepository
        import com.example.jetpackcomposerecipeapp.utils.UiState
        import dagger.hilt.android.lifecycle.HiltViewModel
        import kotlinx.coroutines.flow.Flow
        import kotlinx.coroutines.flow.MutableStateFlow
        import kotlinx.coroutines.flow.StateFlow
        import kotlinx.coroutines.launch
        import javax.inject.Inject

        @HiltViewModel
        class RecipeViewModel @Inject constructor(private val recipeRepository: RecipeRepository) :
            ViewModel() {

            private val _recipes = MutableStateFlow<List<Recipe>>(emptyList())
            val recipes: StateFlow<List<Recipe>> = _recipes

            private val _recipeDetails = MutableStateFlow<RecipeDetailResponse?>(null)
            val recipeDetails: StateFlow<RecipeDetailResponse?> = _recipeDetails

            private val _trendingRecipes = MutableStateFlow<List<RecipeDetailResponse>>(emptyList())
            val trendingRecipes: StateFlow<List<RecipeDetailResponse>> = _trendingRecipes


            private val _cuisines = MutableStateFlow<List<CategoryDto>>(emptyList())
            val cuisines: StateFlow<List<CategoryDto>> = _cuisines


            private var currentOffset = 0
            private val pageSize = 10
            private var isLoading = false


            fun loadInitial(cuisine: String) {
                currentOffset = 0
                _recipes.value = emptyList()
                loadMore(cuisine)
            }


            fun loadMore(cuisine: String) {

                if (isLoading) return

                viewModelScope.launch {
                    isLoading = true

                    recipeRepository.getRecipesByCuisine(cuisine, currentOffset)
                        .collect { state ->

                            when (state) {

                                is UiState.Success -> {
                                    currentOffset += pageSize

                                    _recipes.value += state.data
                                }

                                is UiState.Error -> {
                                    // handle error (optional)
                                }

                                is UiState.Loading -> {
                                    // optional loader
                                }
                            }
                        }

                    isLoading = false
                }
            }

            fun getRecipeDetails(id: Int) {
                viewModelScope.launch {
                    recipeRepository.getRecipeDetails(id).collect { state ->

                        when (state) {

                            is UiState.Success -> {
                                _recipeDetails.value = state.data
                            }

                            is UiState.Error -> {
                                _recipeDetails.value = null
                            }

                            is UiState.Loading -> {
                                // optional loading handling
                            }
                        }
                    }
                }

            }

            fun getRandomRecipes() {
                viewModelScope.launch {
                    recipeRepository.getRandomRecipes().collect { state ->
                        when (state) {
                            is UiState.Success -> {
                                _trendingRecipes.value = state.data
                            }
                            is UiState.Error -> {

                            }
                            is UiState.Loading -> {
                                // Handle loading
                            }
                        }
                    }
                }
            }
            fun getCuisines(){
                viewModelScope.launch {
                    recipeRepository.getCuisines().collect { state ->
                        when (state) {
                            is UiState.Success -> {
                                _cuisines.value = state.data
                            }
                            is UiState.Error -> {
                                // Handle error
                            }
                            is UiState.Loading -> {
                                // Handle loading
                            }
                        }
                    }
                }
            }
                fun toggleFavorite(recipe: RecipeDetailResponse) {
                    viewModelScope.launch {
                        recipeRepository.toggleFavorite(recipe)
                    }
                }

                fun isFavorite(id: Int): Flow<Boolean> {
                    return recipeRepository.isFavorite(id)
                }

                val favoriteRecipes = recipeRepository.getFavorites()


            fun logout() {
                viewModelScope.launch {
                    recipeRepository.clearFavorites()
                }
            }
            }

