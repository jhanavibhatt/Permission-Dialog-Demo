package com.example.jetpackcomposerecipeapp.presentation.ui.mainscreen

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.jetpackcomposerecipeapp.R
import com.example.jetpackcomposerecipeapp.presentation.common.sharedcomponent.AppBottomBar
import com.example.jetpackcomposerecipeapp.presentation.common.sharedcomponent.AppTopBar
import com.example.jetpackcomposerecipeapp.presentation.navigation.AppRoute
import com.example.jetpackcomposerecipeapp.presentation.ui.favoritescreen.FavoriteScreen
import com.example.jetpackcomposerecipeapp.presentation.ui.homescreen.HomeScreen
import com.example.jetpackcomposerecipeapp.presentation.ui.mealdetailscreen.MealDetailRoute
import com.example.jetpackcomposerecipeapp.presentation.ui.meallistScreen.MealListScreen
import com.example.jetpackcomposerecipeapp.presentation.ui.profilescreen.ProfileScreen
import com.example.jetpackcomposerecipeapp.presentation.ui.viewmodel.AuthViewModel
import com.example.jetpackcomposerecipeapp.presentation.ui.viewmodel.RecipeViewModel
import com.example.jetpackcomposerecipeapp.utils.Constants
import com.example.jetpackcomposerecipeapp.utils.PrefsManager

@Composable
fun MainScreen(rootNavController: NavHostController) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val authViewModel: AuthViewModel = hiltViewModel()
    val recipeViewModel: RecipeViewModel = hiltViewModel()

    ProfileScreen(
        onLogout = {
            recipeViewModel.logout()
            authViewModel.logout()

            navController.navigate(AppRoute.Login) {
                popUpTo(0)
            }
        }
    )
    val currentDestination = backStackEntry?.destination
    val showBottomBar = when {
        currentDestination?.hasRoute<AppRoute.MealList>() == true -> false
        currentDestination?.hasRoute<AppRoute.MealDetail>() == true -> false
        else -> true
    }
    val (title, showBack, showMenu) = when {
        currentDestination?.hasRoute<AppRoute.Home>() == true ->
            Triple(stringResource(R.string.home), false, true)

        currentDestination?.hasRoute<AppRoute.MealList>() == true ->
            Triple(stringResource(R.string.meal), true, false)

        currentDestination?.hasRoute<AppRoute.MealDetail>() == true ->
            Triple(stringResource(R.string.meal_detail), true, false)

        currentDestination?.hasRoute<AppRoute.Favorites>() == true ->
            Triple(stringResource(R.string.favorite), false, true)

        currentDestination?.hasRoute<AppRoute.Profile>() == true ->
            Triple(stringResource(R.string.profile), false, true)

        else -> Triple("", false, false)
    }

    Scaffold(
        topBar = {
            AppTopBar(
                title = title,
                showBack = showBack,
                showMenu = showMenu,
                onBackClick = { navController.popBackStack() },
                onMenuClick = { }
            )
        },
        bottomBar = {
            if (showBottomBar) {
                AppBottomBar(navController, currentDestination)
            }
        }
    ) { padding ->

        NavHost(
            navController = navController,
            startDestination = AppRoute.Home,
            modifier = Modifier.padding(padding)
        ) {

            composable<AppRoute.Home> {
                HomeScreen(navController)
            }

            composable<AppRoute.MealList> { backStackEntry ->
                val route = backStackEntry.toRoute<AppRoute.MealList>()
                MealListScreen(route.cuisine, navController)
            }
            composable<AppRoute.MealDetail> { backStackEntry ->
                val route = backStackEntry.toRoute<AppRoute.MealDetail>()

                MealDetailRoute(
                    id = route.id,
                    viewModel = hiltViewModel()
                )
            }
            composable<AppRoute.Favorites> {
                FavoriteScreen()
            }
            composable<AppRoute.Profile> {
                val context = LocalContext.current
                val prefs = remember { PrefsManager(context) }

                ProfileScreen(
                    viewModel = authViewModel,
                    onLogout = {
                        recipeViewModel.logout()
                        authViewModel.logout()
                        rootNavController.navigate(AppRoute.Login) {
                            popUpTo(navController.graph.startDestinationId) {
                                inclusive = true
                            }
                        }
                    }
                )
            }
        }
    }
}