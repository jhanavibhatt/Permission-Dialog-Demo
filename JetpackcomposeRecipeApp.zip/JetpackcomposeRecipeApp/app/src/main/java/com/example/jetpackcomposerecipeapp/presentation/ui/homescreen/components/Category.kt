package com.example.jetpackcomposerecipeapp.presentation.ui.homescreen.components

data class Category(
   val name: String,
    val image: Int
)
