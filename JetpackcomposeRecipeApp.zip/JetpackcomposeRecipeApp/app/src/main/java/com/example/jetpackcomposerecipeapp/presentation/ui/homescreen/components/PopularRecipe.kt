package com.example.jetpackcomposerecipeapp.presentation.ui.homescreen.components

import androidx.annotation.DrawableRes

data class PopularRecipe(
    val title : String,
    val time: String,
    val rating: Double,
    @DrawableRes val imageRes: Int
)
