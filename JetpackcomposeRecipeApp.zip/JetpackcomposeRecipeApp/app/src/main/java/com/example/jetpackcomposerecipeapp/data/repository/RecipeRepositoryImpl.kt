package com.example.jetpackcomposerecipeapp.data.repository

import com.example.jetpackcomposerecipeapp.dao.CuisineDao
import com.example.jetpackcomposerecipeapp.dao.RecipeDao
import com.example.jetpackcomposerecipeapp.data.model.CategoryDto
import com.example.jetpackcomposerecipeapp.data.model.RandomRecipesResponse
import com.example.jetpackcomposerecipeapp.data.model.Recipe
import com.example.jetpackcomposerecipeapp.data.model.RecipeDetailResponse
import com.example.jetpackcomposerecipeapp.data.remote.api.ApiService
import com.example.jetpackcomposerecipeapp.data.remote.api.JsonBinApiService
import com.example.jetpackcomposerecipeapp.utils.UiState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import javax.inject.Inject

class RecipeRepositoryImpl @Inject constructor(
    private val apiService: ApiService,
    private val jsonBinApiService: JsonBinApiService,
    private val recipeDao: RecipeDao,
    private val cuisineDao: CuisineDao

) :
    RecipeRepository {
    override fun getRecipesByCuisine(cuisine: String, offset: Int): Flow<UiState<List<Recipe>>> {
        return flow {
            emit(UiState.Loading)
            try {
                val localData = recipeDao.getRecipesByCuisine(cuisine)

                if (localData.size > offset) {
                    emit(UiState.Success(localData.drop(offset).take(10)))
                } else {
                    val response = apiService.getRecipesByCuisine(
                        cuisine = cuisine,
                        offset = offset
                    )

                    val mapped = response.results.map {
                        it.copy(
                            cuisine = cuisine,
                            offset = offset
                        )
                    }

                    recipeDao.insertCuisineRecipes(mapped)

                    emit(UiState.Success(mapped))
                }
            } catch (e: Exception) {
                emit(UiState.Error(e.message ?: "Something went wrong"))
            }
        }.flowOn(Dispatchers.IO)
    }

    override fun getRecipeDetails(id: Int): Flow<UiState<RecipeDetailResponse>> {
        return flow {
            emit(UiState.Loading)
            try {
                val response = apiService.getRecipeDetails(id)
                emit(UiState.Success(response))
            } catch (e: Exception) {
                emit(UiState.Error(e.message ?: "Something went wrong"))
            }
        }.flowOn(Dispatchers.IO)
    }

    override fun getRandomRecipes(): Flow<UiState<List<RecipeDetailResponse>>> {

        return flow {
            emit(UiState.Loading)
            try {
                val localData = recipeDao.getRecipes()

                if (localData.isNotEmpty()) {
                    emit(UiState.Success(localData))
                } else {
                    val response = apiService.getRandomRecipes()

                    recipeDao.insertRecipes(response.recipes)

                    emit(UiState.Success(response.recipes))
                }
            } catch (e: Exception) {
                emit(UiState.Error(e.message ?: "Something went wrong"))
            }
        }
    }

    override fun getCuisines(): Flow<UiState<List<CategoryDto>>> {
        return flow {
            emit(UiState.Loading)
            try {
                val localData = cuisineDao.getCuisines()

                if (localData.isNotEmpty()) {


                    emit(UiState.Success(localData))
                } else {
                    val response = jsonBinApiService.getCuisines()

                    emit(UiState.Success(response.cuisine))
                }
            } catch (e: Exception) {
                emit(UiState.Error(e.message ?: "Something went wrong"))
            }


        }

    }

    override suspend fun toggleFavorite(recipe: RecipeDetailResponse) {
        val existing = recipeDao.getRecipeById(recipe.id)

        if (existing == null) {

            recipeDao.insertRecipes(listOf(recipe.copy(isFavorite = true)))
        } else {
            recipeDao.updateFavorite(recipe.id, !existing.isFavorite)
        }
    }

    override fun getFavorites(): Flow<List<RecipeDetailResponse>> {
        return recipeDao.getFavoriteRecipesFlow()

}

    override fun isFavorite(id: Int): Flow<Boolean> {
        return recipeDao.isFavorite(id)
    }

    override suspend fun clearFavorites() {
        recipeDao.clearAllFavorites()
    }




}
