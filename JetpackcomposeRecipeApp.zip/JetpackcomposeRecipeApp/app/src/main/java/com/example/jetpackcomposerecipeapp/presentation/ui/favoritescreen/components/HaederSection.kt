package com.example.jetpackcomposerecipeapp.presentation.ui.favoritescreen.components

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.jetpackcomposerecipeapp.R

@Composable
fun HeaderSection() {
    Column {
        Text(
            text = stringResource(R.string.favorite_screen_title),
            fontSize = 28.sp,
            fontWeight = FontWeight.ExtraBold
        )
        Text(
            text = stringResource(R.string.favorite_screen_subtitle),
            color = Color.Gray
        )
    }
}