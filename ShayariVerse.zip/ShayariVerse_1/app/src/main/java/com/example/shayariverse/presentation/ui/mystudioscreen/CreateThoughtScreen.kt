package com.example.shayariverse.presentation.ui.mystudioscreen

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.FormatListBulleted
import androidx.compose.material.icons.automirrored.filled.FormatAlignLeft
import androidx.compose.material.icons.automirrored.filled.FormatAlignRight
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Popup
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import androidx.compose.ui.res.stringResource
import com.example.shayariverse.R
import com.example.shayariverse.model.UserThoughtEntity
import com.example.shayariverse.presentation.common.sharedcomponent.HomeTopBar
import com.example.shayariverse.presentation.ui.homescreen.PrimaryColor
import com.example.shayariverse.ui.theme.*
import com.example.shayariverse.viewmodel.MyStudioViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateThoughtScreen(
    thoughtId: Int? = null,
    initialType: String? = "Quotes",
    navController: NavController,
    viewModel: MyStudioViewModel = hiltViewModel()
) {
    var thoughtToEdit by remember { mutableStateOf<UserThoughtEntity?>(null) }
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf(initialType ?: "Quotes") }
    var textAlign by remember { mutableStateOf(TextAlign.Start) }
    var showTextStylePopup by remember { mutableStateOf(false) }

    // Text Styling States
    var isBold by remember { mutableStateOf(false) }
    var isItalic by remember { mutableStateOf(false) }
    var isUnderline by remember { mutableStateOf(false) }
    var fontSize by remember { mutableStateOf(18.sp) }
    var selectedFont by remember { mutableStateOf<FontFamily>(FontFamily.Default) }
    var showFormattingSheet by remember { mutableStateOf(false) }

    val sheetState = rememberModalBottomSheetState()

    val allThoughts by viewModel.thoughts.collectAsState(initial = emptyList())

    LaunchedEffect(selectedType) {
        viewModel.selectTab(selectedType)
    }

    LaunchedEffect(allThoughts, thoughtId) {
        if (thoughtId != null && thoughtToEdit == null) {
            val thought = allThoughts.find { it.id == thoughtId }
            if (thought != null) {
                thoughtToEdit = thought
                title = thought.title
                content = thought.content
                selectedType = thought.type
                textAlign = when (thought.textAlign) {
                    "Center" -> TextAlign.Center
                    "End" -> TextAlign.End
                    else -> TextAlign.Start
                }
                fontSize = thought.fontSize.sp
                isBold = thought.isBold
                isItalic = thought.isItalic
                isUnderline = thought.isUnderline
                selectedFont = FontManager.getFont(thought.fontFamily)
//                    when (thought.fontFamily) {
//                    "Serif" -> FontFamily.Serif
//                    "SansSerif" -> FontFamily.SansSerif
//                    "Monospace" -> FontFamily.Monospace
//                    "Cursive" -> FontFamily.Cursive
//                    "Kalam" -> KalamFont
//                    "Satisfy" -> SatisfyFont
//                    "Courgette" -> CourgetteFont
//                    "GreatVibes" -> GreatVibesFont
//                    "Sacramento" -> SacramentoFont
//                    "Playfair" -> PlayfairFont
//                    "DancingScript" -> DancingScriptFont
//                    "Merienda" -> MeriendaFont
//                    else -> FontFamily.Default
             //   }
            }
        }
    }

    val addThoughtTitle = stringResource(R.string.add_thought)
    val editThoughtTitle = stringResource(R.string.edit_thought)

    Scaffold(
        topBar = {
            HomeTopBar(
                title = if (thoughtToEdit != null) editThoughtTitle else addThoughtTitle,
                showBack = true,
                onBackClick = { navController.popBackStack() },
                actions = {
                    IconButton(onClick = { /* Undo */ }) {
                        Icon(Icons.AutoMirrored.Filled.Undo, contentDescription = null, tint = PrimaryColor)
                    }
                    IconButton(onClick = { /* Redo */ }) {
                        Icon(Icons.AutoMirrored.Filled.Redo, contentDescription = null, tint = PrimaryColor)
                    }
                    IconButton(
                        onClick = {
                            if (content.isNotBlank()) {
                                val fontName = FontManager.getFontName(selectedFont)
//                                    when (selectedFont) {
//                                    FontFamily.Serif -> "Serif"
//                                    FontFamily.SansSerif -> "SansSerif"
//                                    FontFamily.Monospace -> "Monospace"
//                                    FontFamily.Cursive -> "Cursive"
//                                    KalamFont -> "Kalam"
//                                    SatisfyFont -> "Satisfy"
//                                    CourgetteFont -> "Courgette"
//                                    GreatVibesFont -> "GreatVibes"
//                                    SacramentoFont -> "Sacramento"
//                                    PlayfairFont -> "Playfair"
//                                    DancingScriptFont -> "DancingScript"
//                                    MeriendaFont -> "Merienda"
//                                    else -> "Default"
//                                }

                                if (thoughtToEdit != null) {
                                    viewModel.updateThought(
                                        thoughtToEdit!!.copy(
                                            title = title,
                                            content = content,
                                            type = selectedType,
                                            textAlign = textAlign.toString(),
                                            fontSize = fontSize.value,
                                            isBold = isBold,
                                            isItalic = isItalic,
                                            isUnderline = isUnderline,
                                            fontFamily = fontName
                                        )
                                    )
                                } else {
                                    viewModel.addThought(
                                        title = title,
                                        content = content,
                                        type = selectedType,
                                        textAlign = textAlign.toString(),
                                        fontSize = fontSize.value,
                                        isBold = isBold,
                                        isItalic = isItalic,
                                        isUnderline = isUnderline,
                                        fontFamily = fontName
                                    )
                                }
                                navController.popBackStack()
                            }
                        },
                        enabled = title.isNotBlank() && content.isNotBlank()
                    ) {
                        Icon(
                            Icons.Default.Check,
                            contentDescription = null,
                            tint = if (title.isNotBlank() && content.isNotBlank()) PrimaryColor else Color.Gray
                        )
                    }
                    IconButton(onClick = { /* More */ }) {
                        Icon(Icons.Default.MoreVert, contentDescription = null, tint = PrimaryColor)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            // Type Selector
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                FilterChip(
                    selected = selectedType == "Quotes",
                    onClick = { selectedType = "Quotes" },
                    label = { Text("Quotes") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = PrimaryColor,
                        selectedLabelColor = Color.White,
                        labelColor = Color.Gray
                    )
                )
                Spacer(modifier = Modifier.width(8.dp))
                FilterChip(
                    selected = selectedType == "Shayari",
                    onClick = { selectedType = "Shayari" },
                    label = { Text("Shayari") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = PrimaryColor,
                        selectedLabelColor = Color.White,
                        labelColor = Color.Gray
                    )
                )
            }

            // Editor Fields
            TextField(
                value = title,
                onValueChange = { title = it },
                placeholder = { Text("Title", fontSize = 22.sp, color = Color.Gray) },
                modifier = Modifier.fillMaxWidth(),
                textStyle = LocalTextStyle.current.copy(
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color.White
                ),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    cursorColor = Color(0xFFF1B440)
                )
            )

            TextField(
                value = content,
                onValueChange = { content = it },
                placeholder = { Text("Write your inspiration here...", fontSize = 18.sp, color = Color.Gray) },
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                textStyle = LocalTextStyle.current.copy(
                    fontSize = fontSize,
                    color = Color.White,
                    textAlign = textAlign,
                    fontFamily = selectedFont,
                    fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal,
                    fontStyle = if (isItalic) FontStyle.Italic else FontStyle.Normal,
                    textDecoration = if (isUnderline) TextDecoration.Underline else TextDecoration.None
                ),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    cursorColor = Color(0xFFF1B440)
                )
            )

            // Bottom Actions Area
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp)
            ) {
//                Surface(
//                    color = Color(0xFF2D2E33),
//                    shape = RoundedCornerShape(8.dp),
//                    modifier = Modifier.align(Alignment.CenterStart)
//                ) {
//                    Row(
//                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
//                        verticalAlignment = Alignment.CenterVertically
//                    ) {
//                        Icon(
//                            Icons.Default.NotificationsNone,
//                            contentDescription = null,
//                            tint = Color.Gray,
//                            modifier = Modifier.size(18.dp)
//                        )
//                        Spacer(modifier = Modifier.width(8.dp))
//                        Text("Set Reminder", color = Color.Gray, fontSize = 14.sp)
//                    }
//                }

                IconButton(
                    onClick = { /* Voice/Profile */ },
                    modifier = Modifier.align(Alignment.CenterEnd)
                ) {
                    Icon(
                        Icons.Default.AccountCircle,
                        contentDescription = null,
                        tint = Color(0xFF4285F4),
                        modifier = Modifier.size(32.dp)
                    )
                }
            }

            // Tool Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { showFormattingSheet = true }) {
                    Icon(Icons.Default.TextFields, contentDescription = null, tint = Color.Gray)
                }
                
                Box {
                    IconButton(onClick = { showTextStylePopup = true }) {
                        Icon(
                            Icons.AutoMirrored.Filled.FormatListBulleted,
                            contentDescription = null,
                            tint = Color.Gray
                        )
                    }

                    if (showTextStylePopup) {
                        Popup(
                            alignment = Alignment.TopCenter,
                            onDismissRequest = { showTextStylePopup = false },
                            offset = IntOffset(0, -350)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = Color(0xFF2D2E33),
                                tonalElevation = 8.dp,
                                modifier = Modifier
                                    .width(220.dp)
                                    .padding(8.dp)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "Text Style",
                                            color = Color.White,
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        IconButton(
                                            onClick = { showTextStylePopup = false },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(
                                                Icons.Default.Close,
                                                contentDescription = "Close",
                                                tint = Color.Gray,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(16.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceEvenly
                                    ) {
                                        IconButton(onClick = {
                                            textAlign = TextAlign.Start
                                            showTextStylePopup = false
                                        }) {
                                            Icon(
                                                Icons.AutoMirrored.Filled.FormatAlignLeft,
                                                contentDescription = "Left",
                                                tint = Color.White
                                            )
                                        }
                                        IconButton(onClick = {
                                            textAlign = TextAlign.Center
                                            showTextStylePopup = false
                                        }) {
                                            Icon(
                                                Icons.Default.FormatAlignCenter,
                                                contentDescription = "Center",
                                                tint = Color.White
                                            )
                                        }
                                        IconButton(onClick = {
                                            textAlign = TextAlign.End
                                            showTextStylePopup = false
                                        }) {
                                            Icon(
                                                Icons.AutoMirrored.Filled.FormatAlignRight,
                                                contentDescription = "Right",
                                                tint = Color.White
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                
//                Icon(Icons.Default.MicNone, conte ntDescription = null, tint = Color.Gray)
//                Icon(Icons.Default.Gesture, contentDescription = null, tint = Color.Gray)
//                Icon(Icons.Default.Image, contentDescription = null, tint = Color.Gray)
                Icon(Icons.Default.Palette, contentDescription = null, tint = Color.Gray)
            }
        }
    }

    if (showFormattingSheet) {
        ModalBottomSheet(
            onDismissRequest = { showFormattingSheet = false },
            sheetState = sheetState,
            containerColor = Color(0xFF1C1D21),
            dragHandle = { BottomSheetDefaults.DragHandle(color = Color.Gray) }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 32.dp, start = 16.dp, end = 16.dp, top = 8.dp)
            ) {
                // Formatting Toolbar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // B, I, U Buttons
                    Row(
                        modifier = Modifier
                            .background(Color(0xFF2D2E33), RoundedCornerShape(8.dp))
                            .padding(4.dp)
                    ) {
                        FormattingToggleButton(
                            selected = isBold,
                            onClick = { isBold = !isBold },
                            icon = Icons.Default.FormatBold,
                            label = "B"
                        )
                        FormattingToggleButton(
                            selected = isItalic,
                            onClick = { isItalic = !isItalic },
                            icon = Icons.Default.FormatItalic,
                            label = "I"
                        )
                        FormattingToggleButton(
                            selected = isUnderline,
                            onClick = { isUnderline = !isUnderline },
                            icon = Icons.Default.FormatUnderlined,
                            label = "U"
                        )
                    }

                    VerticalDivider(
                        modifier = Modifier
                            .height(24.dp)
                            .padding(horizontal = 4.dp),
                        color = Color.Gray.copy(alpha = 0.5f)
                    )

                    IconButton(onClick = { /* Text Color */ }) {
                        Icon(Icons.Default.FormatColorText, null, tint = Color.White)
                    }

                    IconButton(onClick = { /* Highlight Color */ }) {
                        Icon(Icons.Default.FormatColorFill, null, tint = Color.White)
                    }

                    Text(
                        "H1",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        modifier = Modifier.padding(horizontal = 4.dp)
                    )

                    Spacer(modifier = Modifier.weight(1f))

                    // Font Size Dropdown
                    var expanded by remember { mutableStateOf(false) }
                    Box {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = Color(0xFF2D2E33),
                            modifier = Modifier.clickable { expanded = true }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "${fontSize.value.toInt()}",
                                    color = Color.White,
                                    fontSize = 14.sp
                                )
                                Icon(
                                    Icons.Default.ArrowDropDown,
                                    null,
                                    tint = Color.Gray,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        DropdownMenu(
                            expanded = expanded,
                            onDismissRequest = { expanded = false },
                            modifier = Modifier.background(Color(0xFF2D2E33))
                        ) {
                            listOf(12, 14, 16, 18, 20, 24, 28, 32).forEach { size ->
                                DropdownMenuItem(
                                    text = { Text("$size", color = Color.White) },
                                    onClick = {
                                        fontSize = size.sp
                                        expanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Font Grid
                val fonts = listOf(
                    FontFamily.Default,
                    FontFamily.Serif,
                    FontFamily.SansSerif,
                    FontFamily.Monospace,
                    FontFamily.Cursive,
                    KalamFont,
                    SatisfyFont,
                    CourgetteFont,
                    GreatVibesFont,
                    SacramentoFont,
                    PlayfairFont,
                    DancingScriptFont,
                    MeriendaFont
                )
                
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.height(320.dp)
                ) {
                    items(fonts.size) { index ->
                        FontPreviewCard(
                            isSelected = selectedFont == fonts[index],
                            label = when(fonts[index]) {
                                FontFamily.Default -> "Default"
                                FontFamily.Serif -> "Serif"
                                FontFamily.SansSerif -> "SansSerif"
                                FontFamily.Monospace -> "Mono"
                                FontFamily.Cursive -> "Cursive"
                                KalamFont -> "Kalam"
                                SatisfyFont -> "Satisfy"
                                CourgetteFont -> "Courgette"
                                GreatVibesFont -> "GreatVibes"
                                SacramentoFont -> "Sacramento"
                                PlayfairFont -> "Playfair"
                                DancingScriptFont -> "Dancing"
                                MeriendaFont -> "Merienda"
                                else -> "Font $index"
                            },
                            fontFamily = fonts[index],
                            onClick = { selectedFont = fonts[index] }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun FormattingToggleButton(
    selected: Boolean,
    onClick: () -> Unit,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String
) {
    IconButton(
        onClick = onClick,
        modifier = Modifier
            .size(36.dp)
            .background(
                if (selected) Color(0xFFF1B440).copy(alpha = 0.2f) else Color.Transparent,
                RoundedCornerShape(4.dp)
            )
    ) {
        if (label.isNotEmpty()) {
            Text(
                text = label,
                color = if (selected) Color(0xFFF1B440) else Color.White,
                fontWeight = if (label == "B") FontWeight.Bold else FontWeight.Normal,
                fontStyle = if (label == "I") FontStyle.Italic else FontStyle.Normal,
                textDecoration = if (label == "U") TextDecoration.Underline else TextDecoration.None,
                fontSize = 16.sp
            )
        } else {
            Icon(
                icon,
                null,
                tint = if (selected) Color(0xFFF1B440) else Color.White,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
fun FontPreviewCard(
    isSelected: Boolean,
    label: String,
    fontFamily: FontFamily,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = Color(0xFF2D2E33),
        border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF1B440)) else null,
        modifier = Modifier
            .fillMaxWidth()
            .height(60.dp)
            .clickable { onClick() }
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = label,
                color = if (isSelected) Color(0xFFF1B440) else Color.White,
                fontSize = 14.sp,
                fontFamily = fontFamily
            )
        }
    }
}
