package com.example.shayariverse.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.sp
import com.example.shayariverse.R

// Custom Font Families
val KalamFont = FontFamily(Font(R.font.kalam_regular))
val SatisfyFont = FontFamily(Font(R.font.satisfy_regular))
val CourgetteFont = FontFamily(Font(R.font.courgette_regular))
val GreatVibesFont = FontFamily(Font(R.font.greatvibes_regular))
val SacramentoFont = FontFamily(Font(R.font.sacramento_regular))
val PlayfairFont = FontFamily(Font(R.font.playfairdisplay_bold))
val DancingScriptFont = FontFamily(Font(R.font.dancingscript_regular))
val MeriendaFont = FontFamily(Font(R.font.merienda_variablefont_wght))

object StyleManager {
    fun getTextAlign(name: String?): TextAlign {
        return when (name) {
            "Center" -> TextAlign.Center
            "End" -> TextAlign.End
            else -> TextAlign.Start
        }
    }
}

object FontManager {
    fun getFont(name: String?): FontFamily {
        return when (name) {
            "Serif" -> FontFamily.Serif
            "SansSerif" -> FontFamily.SansSerif
            "Monospace" -> FontFamily.Monospace
            "Cursive" -> FontFamily.Cursive
            "Kalam" -> KalamFont
            "Satisfy" -> SatisfyFont
            "Courgette" -> CourgetteFont
            "GreatVibes" -> GreatVibesFont
            "Sacramento" -> SacramentoFont
            "Playfair" -> PlayfairFont
            "DancingScript" -> DancingScriptFont
            "Merienda" -> MeriendaFont
            else -> FontFamily.Default
        }
    }

    fun getFontName(fontFamily: FontFamily): String {
        return when (fontFamily) {
            FontFamily.Serif -> "Serif"
            FontFamily.SansSerif -> "SansSerif"
            FontFamily.Monospace -> "Monospace"
            FontFamily.Cursive -> "Cursive"
            KalamFont -> "Kalam"
            SatisfyFont -> "Satisfy"
            CourgetteFont -> "Courgette"
            GreatVibesFont -> "GreatVibes"
            SacramentoFont -> "Sacramento"
            PlayfairFont -> "Playfair"
            DancingScriptFont -> "DancingScript"
            MeriendaFont -> "Merienda"
            else -> "Default"
        }
    }
}

// Set of Material typography styles to start with
val Typography = Typography(
    bodyLarge = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp,
        lineHeight = 24.sp,
        letterSpacing = 0.5.sp
    )
    /* Other default text styles to override
    titleLarge = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Normal,
        fontSize = 22.sp,
        lineHeight = 28.sp,
        letterSpacing = 0.sp
    ),
    labelSmall = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Medium,
        fontSize = 11.sp,
        lineHeight = 16.sp,
        letterSpacing = 0.5.sp
    )
    */
)