package com.example.shayariverse.presentation.navigation

import androidx.annotation.StringRes
import com.example.shayariverse.R
import kotlinx.serialization.Serializable

@Serializable
sealed class AppRoute(@StringRes val title :Int? = null) {

    @Serializable
    data object Splash : AppRoute()

    @Serializable
    data object Home : AppRoute(R.string.app_name)

    @Serializable
    data object Favorites : AppRoute(R.string.favorites)

    @Serializable
    data object MyStudio : AppRoute(R.string.my_studio)

    @Serializable
    data class CreateThought(
        val thoughtId: Int? = null,
        val initialType: String? = null
    ) : AppRoute()

    @Serializable
    data object Settings : AppRoute(R.string.Settings)

    @Serializable
    data object  About : AppRoute(R.string.About)

    @Serializable
    data class Categories(val type: CategoryType) : AppRoute()

    @Serializable
    data class ListScreen(
        val type: CategoryType,
        val category: String
    ) : AppRoute()
}
@Serializable
enum class CategoryType {
    SHAYARI,
    QUOTES
}