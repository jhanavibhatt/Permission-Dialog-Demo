package com.example.shayariverse.repository

import com.example.shayariverse.dao.UserThoughtDao
import com.example.shayariverse.model.UserThoughtEntity
import kotlinx.coroutines.flow.Flow

class UserThoughtRepository(private val userThoughtDao: UserThoughtDao) {
    fun getThoughtsByType(type: String): Flow<List<UserThoughtEntity>> = userThoughtDao.getThoughtsByType(type)

    suspend fun insertThought(thought: UserThoughtEntity) = userThoughtDao.insertThought(thought)

    suspend fun updateThought(thought: UserThoughtEntity) = userThoughtDao.updateThought(thought)

    suspend fun deleteThought(thought: UserThoughtEntity) = userThoughtDao.deleteThought(thought)

    suspend fun getThoughtById(id: Int) = userThoughtDao.getThoughtById(id)
}
