package com.example.shayariverse.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_thoughts")
data class UserThoughtEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val title: String = "",
    val content: String,
    val type: String, // "Quotes" or "Shayari"
    val textAlign: String = "Start",
    val fontSize: Float = 18f,
    val isBold: Boolean = false,
    val isItalic: Boolean = false,
    val isUnderline: Boolean = false,
    val fontFamily: String = "Default",
    val timestamp: Long = System.currentTimeMillis()
)
