package com.example.shayariverse.presentation.ui.mystudioscreen

import android.content.Intent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FormatQuote
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.shayariverse.R
import com.example.shayariverse.model.UserThoughtEntity
import com.example.shayariverse.presentation.navigation.AppRoute
import com.example.shayariverse.presentation.ui.homescreen.PrimaryColor
import com.example.shayariverse.ui.theme.*
import com.example.shayariverse.viewmodel.MyStudioViewModel

@Composable
fun MyStudioScreen(
    navController: NavController,
    viewModel: MyStudioViewModel = hiltViewModel()
) {
    val selectedTab by viewModel.selectedTab.collectAsState()
    val thoughts by viewModel.thoughts.collectAsState(initial = emptyList())

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ScreenBg)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            TabSwitcher(
                selectedItemIndex = if (selectedTab == "Quotes") 0 else 1,
                items = listOf("Quotes", "Shayari"),
                onClick = { index ->
                    viewModel.selectTab(if (index == 0) "Quotes" else "Shayari")
                }
            )

            Spacer(modifier = Modifier.height(16.dp))

            if (thoughts.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(text = stringResource(R.string.no_thoughts), color = Color.Gray)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    items(thoughts) { thought ->
                        ThoughtCard(
                            thought = thought,
                            onEdit = { 
                                navController.navigate(AppRoute.CreateThought(thoughtId = thought.id, initialType = thought.type))
                            },
                            onDelete = { viewModel.deleteThought(thought) }
                        )
                    }
                }
            }
        }

        FloatingActionButton(
            onClick = { 
                navController.navigate(AppRoute.CreateThought(initialType = selectedTab))
            },
            containerColor = PrimaryColor,
            contentColor = Color.White,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
        ) {
            Icon(Icons.Default.Add, contentDescription = stringResource(R.string.add_thought))
        }
    }
}

@Composable
fun TabSwitcher(
    selectedItemIndex: Int,
    items: List<String>,
    modifier: Modifier = Modifier,
    onClick: (Int) -> Unit
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(
                color = Color(0xFF2A1E3D),
                shape = RoundedCornerShape(12.dp)
            )
    ) {
        items.forEachIndexed { index, title ->
            val selected = index == selectedItemIndex
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(15.dp))
                    .background(
                        if (selected) PrimaryColor
                        else Color.Transparent
                    )
                    .clickable { onClick(index) }
                    .padding(vertical = 5.dp),
                contentAlignment = Alignment.Center
            ) {
                MyTabItem(
                    isSelected = selected,
                    text = title,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
private fun MyTabItem(
    isSelected: Boolean,
    text: String,
    modifier: Modifier = Modifier
) {
    val tabTextColor by animateColorAsState(
        targetValue = if (isSelected) Color.White else Color.Gray,
        animationSpec = tween(easing = LinearEasing),
        label = ""
    )

    Text(
        modifier = modifier
            .clip(RoundedCornerShape(15.dp))
            .padding(vertical = 10.dp),
        text = text,
        color = tabTextColor,
        textAlign = TextAlign.Center
    )
}

@Composable
fun ThoughtCard(
    thought: UserThoughtEntity,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF2A1E3D)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.FormatQuote,
                    contentDescription = null,
                    tint = PrimaryColor.copy(alpha = 0.4f),
                    modifier = Modifier.size(24.dp)
                )
                if (thought.title.isNotBlank()) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = thought.title,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = thought.content,
                color = Color.White,
                fontSize = thought.fontSize.sp,
                textAlign = when (thought.textAlign) {
                    "Center" -> TextAlign.Center
                    "End" -> TextAlign.End
                    else -> TextAlign.Start
                },
                fontWeight = if (thought.isBold) FontWeight.Bold else FontWeight.Normal,
                fontStyle = if (thought.isItalic) FontStyle.Italic else FontStyle.Normal,
                textDecoration = if (thought.isUnderline) androidx.compose.ui.text.style.TextDecoration.Underline else androidx.compose.ui.text.style.TextDecoration.None,
                fontFamily  = FontManager.getFont(thought.fontFamily),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = {
                    clipboardManager.setText(AnnotatedString(thought.content))
                }) {
                    Icon(Icons.Default.ContentCopy, contentDescription = stringResource(R.string.copy), tint = Color.Gray)
                }
                IconButton(onClick = {
                    val intent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, thought.content)
                    }
                    context.startActivity(Intent.createChooser(intent, "Share via"))
                }) {
                    Icon(Icons.Default.Share, contentDescription = stringResource(R.string.share), tint = Color.Gray)
                }
                IconButton(onClick = onEdit) {
                    Icon(Icons.Default.Edit, contentDescription = stringResource(R.string.edit), tint = Color.Gray)
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, contentDescription = stringResource(R.string.delete), tint = Color.Red)
                }
            }
        }
    }
}
