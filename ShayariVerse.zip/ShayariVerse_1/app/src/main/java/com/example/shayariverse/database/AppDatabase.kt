package com.example.shayariverse.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.shayariverse.dao.FavoriteDao
import com.example.shayariverse.dao.UserThoughtDao
import com.example.shayariverse.model.FavoriteEntity
import com.example.shayariverse.model.UserThoughtEntity

@Database(entities = [FavoriteEntity::class, UserThoughtEntity::class], version = 7, exportSchema = false )
abstract class AppDatabase : RoomDatabase() {
    abstract fun favoriteDao(): FavoriteDao
    abstract fun userThoughtDao(): UserThoughtDao
}