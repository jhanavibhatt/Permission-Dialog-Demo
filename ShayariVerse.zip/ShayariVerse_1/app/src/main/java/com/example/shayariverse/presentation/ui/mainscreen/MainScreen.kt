package com.example.shayariverse.presentation.ui.mainscreen

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavBackStackEntry
import androidx.navigation.NavDestination
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.shayariverse.R
import com.example.shayariverse.model.TopBarUiState
import com.example.shayariverse.presentation.common.sharedcomponent.HomeTopBar
import com.example.shayariverse.presentation.navigation.AppRoute
import com.example.shayariverse.presentation.navigation.CategoryType
import com.example.shayariverse.presentation.ui.AboutScreen
import com.example.shayariverse.presentation.ui.mainscreen.components.BottomNavBar
import com.example.shayariverse.presentation.ui.categoryscreen.CategoryScreen
import com.example.shayariverse.presentation.ui.favoritescreen.FavoriteScreen
import com.example.shayariverse.presentation.ui.homescreen.HomeScreen
import com.example.shayariverse.presentation.ui.listscreen.ListScreen
import com.example.shayariverse.presentation.ui.mystudioscreen.CreateThoughtScreen
import com.example.shayariverse.presentation.ui.mystudioscreen.MyStudioScreen
import com.example.shayariverse.presentation.ui.settingsscreen.SettingsScreen
import com.example.shayariverse.presentation.ui.splashscreen.SplashScreen
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.serialization.Serializable
import java.util.Map.entry

@Composable
fun MainScreen() {

    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val destination = backStackEntry?.destination
    val isSplash =
        destination?.hasRoute<AppRoute.Splash>() == true

    var topBarState by remember {
        mutableStateOf(TopBarUiState())
    }
    val topLevelScreens = setOf(
        AppRoute.Home,
        AppRoute.MyStudio,
        AppRoute.Favorites,
        AppRoute.Settings
    )

    val currentScreen = when {
        destination?.hasRoute<AppRoute.Home>() == true ->
            AppRoute.Home

        destination?.hasRoute<AppRoute.MyStudio>() == true ->
            AppRoute.MyStudio

        destination?.hasRoute<AppRoute.Favorites>() == true ->
            AppRoute.Favorites

        destination?.hasRoute<AppRoute.Settings>() == true ->
            AppRoute.Settings

        destination?.hasRoute<AppRoute.About>() == true ->
            AppRoute.About

        else -> null
    }


    val title = when {

        currentScreen?.title != null ->
            stringResource(currentScreen.title)

        destination?.hasRoute<AppRoute.Categories>() == true -> {
            val type = backStackEntry
                ?.toRoute<AppRoute.Categories>()
                ?.type

            when (type) {
                CategoryType.SHAYARI ->
                    stringResource(R.string.shayari_categories)

                CategoryType.QUOTES ->
                    stringResource(R.string.quote_categories)

                null ->
                    stringResource(R.string.categories)
            }
        }

        destination?.hasRoute<AppRoute.ListScreen>() == true -> {
            backStackEntry
                ?.toRoute<AppRoute.ListScreen>()
                ?.category
                ?: stringResource(R.string.collection)
        }

        destination?.hasRoute<AppRoute.CreateThought>() == true -> ""

        else ->
            stringResource(R.string.app_name)
    }
    val showBack = currentScreen !in topLevelScreens

    

    Scaffold(
        topBar = {
            if (!isSplash && destination?.hasRoute<AppRoute.CreateThought>() != true) {
                HomeTopBar(
                    title = title,
                    subtitle = null,
                    showBack = showBack,
                    onBackClick = {
                        navController.popBackStack()
                    },
                    actions = {

                        if (topBarState.showUndo) {
                            IconButton(onClick = {}) {
                                Icon(
                                    Icons.AutoMirrored.Filled.Undo,
                                    contentDescription = null
                                )
                            }
                        }

                        if (topBarState.showRedo) {
                            IconButton(onClick = {}) {
                                Icon(
                                    Icons.AutoMirrored.Filled.Redo,
                                    contentDescription = null
                                )
                            }
                        }

                        if (topBarState.showSave) {
                            IconButton(onClick = {}) {
                                Icon(
                                    Icons.Default.Check,
                                    contentDescription = null
                                )
                            }
                        }

                        if (topBarState.showMore) {
                            IconButton(onClick = {}) {
                                Icon(
                                    Icons.Default.MoreVert,
                                    contentDescription = null
                                )
                            }
                        }
                    }
                )
            }
        },
        bottomBar = {
            if (!isSplash && currentScreen in topLevelScreens) {
                BottomNavBar(
                    currentScreen = currentScreen,
                    onTabSelected = { screen ->

                        navController.navigate(screen) {

                            popUpTo(navController.graph.startDestinationId) {
                                saveState = true
                            }

                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
            }
        } //  only bottom bar here
    ) { padding ->

        val navHostPadding = if (destination?.hasRoute<AppRoute.CreateThought>() == true) {
            PaddingValues(0.dp)
        } else {
            padding
        }

        NavHost(
            navController = navController,
            startDestination = AppRoute.Splash,
            modifier = Modifier.padding(navHostPadding)
        ) {
            composable<AppRoute.Splash> {
                SplashScreen(
                    onSplashFinished = {
                        navController.navigate(AppRoute.Home) {
                            popUpTo<AppRoute.Splash> {
                                inclusive = true
                            }
                        }
                    }
                )
            }
            composable<AppRoute.Home> {
                HomeScreen(navController)
            }

            composable<AppRoute.Favorites> {
                FavoriteScreen()
            }
            composable<AppRoute.MyStudio> {
                MyStudioScreen(navController = navController)
            }
            composable<AppRoute.CreateThought> { entry ->
                val args = entry.toRoute<AppRoute.CreateThought>()
                CreateThoughtScreen(
                    thoughtId = args.thoughtId,
                    initialType = args.initialType,
                    navController = navController
                )
            }
            composable<AppRoute.Settings> {
                SettingsScreen(navController)
            }
            composable<AppRoute.About> {
                AboutScreen()
            }

            composable<AppRoute.Categories> { entry ->
                val args = entry.toRoute<AppRoute.Categories>()

                CategoryScreen(
                    type = args.type,
                    navController = navController
                )
            }

            composable<AppRoute.ListScreen> { entry ->
                val args = entry.toRoute<AppRoute.ListScreen>()

                ListScreen(
                    category = args.category,
                    type = args.type,
                    navController = navController
                )
            }

        }
    }
}
