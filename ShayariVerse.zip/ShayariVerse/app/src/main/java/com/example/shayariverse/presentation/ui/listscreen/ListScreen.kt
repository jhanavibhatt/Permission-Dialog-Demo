package com.example.shayariverse.presentation.ui.listscreen

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FormatQuote
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.shayariverse.presentation.common.sharedcomponent.HomeTopBar
import com.example.shayariverse.QuoteRepository
import com.example.shayariverse.model.Quote
import com.example.shayariverse.model.Shayri
import com.example.shayariverse.presentation.ui.homescreen.PrimaryColor
import com.example.shayariverse.presentation.ui.listscreen.components.QuoteItemCard
import com.example.shayariverse.presentation.ui.listscreen.components.ShayriItemCard
import com.example.shayariverse.ui.theme.ScreenBg
import com.example.shayariverse.viewmodel.FavoriteViewModel
import kotlin.collections.filter


@Composable
fun ListScreen(  category: String?,type: String?,
                 navController: NavController,viewModel: FavoriteViewModel = hiltViewModel()) {

    var selectedFilter by remember { mutableIntStateOf(0) }


    val context = LocalContext.current

//    val allQuotes = remember(type) {
//        when (type) {
//            "quotes" -> QuoteRepository.loadQuotes(context)
//            "shayari" -> QuoteRepository.loadShayri(context)
//            else -> emptyList()
//        }
//    }
    val allQuotes by produceState<List<Any>>(
        initialValue = emptyList(),
        key1 = type
    ) {
        value = when (type) {
            "quotes" -> QuoteRepository.loadQuotes(context)
            "shayari" -> QuoteRepository.loadShayri(context)
            else -> emptyList()
        }
    }

//    val filteredQuotes = remember(category, allQuotes) {
//        if (category == null) allQuotes
//        else allQuotes.filter {
//            it.category.equals(category, ignoreCase = true)
//        }
//    }
    val filteredQuotes = remember(category, allQuotes) {
        if (category == null) {
            allQuotes
        } else {
            allQuotes.filter { item ->
                when (item) {
                    is Quote -> item.category.equals(category, ignoreCase = true)
                    is Shayri -> item.category.equals(category, ignoreCase = true)
                    else -> false
                }
            }
        }
    }



    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ScreenBg)
            .padding(16.dp)
    ) {

        Spacer(Modifier.height(16.dp))

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {

                items(filteredQuotes) { item ->

                    when (item) {
                        is Quote -> QuoteItemCard(item, viewModel)
                        is Shayri -> ShayriItemCard(item, viewModel)
                    }
                }
            }
        }
    }



