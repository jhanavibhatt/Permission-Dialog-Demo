package com.example.shayariverse.repository

import com.example.shayariverse.dao.FavoriteDao
import com.example.shayariverse.model.FavoriteEntity
import kotlinx.coroutines.flow.first
import javax.inject.Inject

class FavoriteRepository @Inject constructor(
    private val dao: FavoriteDao
) {

    fun getFavorites() = dao.getAll()

    fun isFavorite(text: String) = dao.isFavorite(text)

    suspend fun toggleFavorite(item: FavoriteEntity) {
        val isFav = dao.isFavorite(item.text).first()

        if (isFav) {
            dao.deleteByText(item.text) // ✅ was dao.delete(item.id) — id was always 0
        } else {
            dao.insert(item)
        }
    }
    suspend fun deleteFavorite(id: Int) {
        dao.delete(id)
    }
}