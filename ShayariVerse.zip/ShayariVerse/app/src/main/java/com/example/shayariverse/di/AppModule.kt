package com.example.shayariverse.di

import android.content.Context
import androidx.room.Room
import com.example.shayariverse.dao.FavoriteDao
import com.example.shayariverse.database.AppDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): AppDatabase {
        return Room.databaseBuilder(
            context,
            AppDatabase::class.java,
            "shayari_db"
        ).fallbackToDestructiveMigration(true)
            .build()
    }

    @Provides
    fun provideDao(db: AppDatabase): FavoriteDao {
        return db.favoriteDao()
    }
}