package com.example.shayariverse

import androidx.compose.runtime.mutableStateListOf
import com.example.shayariverse.presentation.ui.favoritescreen.ContentItem

object FavoriteManager {

    private val _favorites = mutableStateListOf<ContentItem>()
    val favorites: List<ContentItem> = _favorites

    fun toggleFavorite(item: ContentItem) {
        if (_favorites.any { it.text == item.text }) {
            _favorites.removeAll { it.text == item.text }
        } else {
            _favorites.add(item.copy(isFavorite = true))
        }
    }

    fun isFavorite(text: String): Boolean {
        return _favorites.any { it.text == text }
    }
}