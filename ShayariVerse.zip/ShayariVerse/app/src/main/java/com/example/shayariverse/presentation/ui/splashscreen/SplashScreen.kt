package com.example.shayariverse.presentation.ui.splashscreen

import androidx.compose.runtime.Composable
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FormatQuote
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import kotlinx.coroutines.delay


val Primary = Color(0xFF7F19E6)
val BackgroundLight = Color(0xFFF7F6F8)
val BackgroundDark = Color(0xFF191121)

@Composable
fun SplashScreen(
    onSplashFinished: () -> Unit
) {

    var progress by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(Unit) {

        while (progress < 1f) {
            delay(40)
            progress += 0.01f
        }

        onSplashFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDark)
    ) {

        SoftBackground()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Spacer(modifier = Modifier.height(40.dp))

            CenterContent()

            BottomProgress(progress)

        }
    }
}
@Composable
fun CenterContent() {

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxWidth()
    ) {

        Box(
            modifier = Modifier
                .size(120.dp)
                .background(
                    color = Primary.copy(alpha = 0.1f),
                    shape = CircleShape
                )
                .border(
                    1.dp,
                    Primary.copy(alpha = 0.2f),
                    CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {

            Icon(
                imageVector = Icons.Filled.FormatQuote,
                contentDescription = "Quote",
                tint = Primary,
                modifier = Modifier.size(48.dp)
            )

        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "ShayariVerse",
            fontSize = 34.sp,
            fontWeight = FontWeight.ExtraBold,
            color = Color.White
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Words that touch the soul",
            fontSize = 16.sp,
            color = Color.Gray
        )
    }
}

@Composable
fun BottomProgress(progress: Float) {

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Column(modifier = Modifier.fillMaxWidth()) {

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {

                Text(
                    text = "Entering Universe",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.Gray
                )

                Text(
                    text = "${(progress * 100).toInt()}%",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Primary
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            LinearProgressIndicator(
                progress = progress,
                color = Primary,
                trackColor = Color.Gray.copy(alpha = 0.2f),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
            )
        }

        Spacer(modifier = Modifier.height(30.dp))

        CircularProgressIndicator(
            color = Primary,
            strokeWidth = 4.dp,
            modifier = Modifier.size(40.dp)
        )

        Spacer(modifier = Modifier.height(40.dp))
    }
}
@Preview
@Composable
fun SoftBackground() {

    Box(
        modifier = Modifier.fillMaxSize()
    ) {

        Box(
            modifier = Modifier
                .size(260.dp)
                .offset((-80).dp, (-80).dp)
                .background(
                    Primary.copy(alpha = 0.08f),
                    CircleShape
                )
                .blur(120.dp)
        )

        Box(
            modifier = Modifier
                .size(320.dp)
                .align(Alignment.BottomEnd)
                .offset(80.dp, 80.dp)
                .background(
                    Primary.copy(alpha = 0.12f),
                    CircleShape
                )
                .blur(140.dp)
        )
    }
}