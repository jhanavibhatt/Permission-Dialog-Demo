package com.example.shayariverse.presentation.ui.homescreen.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.DeviceHub
import androidx.compose.material.icons.filled.EmojiEmotions
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.SentimentSatisfied
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.shayariverse.model.Category
import com.example.shayariverse.presentation.navigation.AppRoute
import com.example.shayariverse.presentation.navigation.CategoryType


val categoriesQuotes = listOf(
    Category("Wisdom", "124 quotes", Icons.Filled.AutoStories, Color(0xFF6A11CB)),
    Category("Life", "332 quotes", Icons.Filled.DeviceHub, Color(0xFF3A1C71)),
    Category("Inspirational", "89 quotes", Icons.Filled.Lightbulb, Color(0xFFFF8008)),
    Category("Success", "154 quotes", Icons.Filled.EmojiEvents, Color(0xFF4A00E0)),
    Category("Happiness", "245 quotes", Icons.Filled.SentimentSatisfied, Color(0xFFC33764)),
    Category("Funny", "47 quotes", Icons.Filled.EmojiEmotions, Color(0xFF734B6D)),
    Category("Motivational", "72 quotes", Icons.AutoMirrored.Filled.TrendingUp, Color(0xFF243B55)),
    Category("Hope", "189 quotes", Icons.Filled.WbSunny, Color(0xFFFFAF7B))
)


@Composable
fun QuotesTabContent(navController: NavController) {

    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {

        item(key = "quote_of_day", span = { GridItemSpan(2) }, contentType = "header") {
            Column {
                QuoteOfDayCard()
            }
        }
        item(key = "explore_header", span = { GridItemSpan(2) }, contentType = "header") {
            Column {
                ExploreHeader("Explore Quotes",onSeeAllClick = {
                    navController.navigate(AppRoute.Categories(CategoryType.QUOTES))
                })
                Spacer(Modifier.height(16.dp))
            }
        }

        items(categoriesQuotes, key = { it.title }, contentType = { "category_card" }) { category ->
                CategoryCard(category, CategoryType.QUOTES, navController)
        }

        item(key = "ad_banner", span = { GridItemSpan(2) }, contentType = "ad") {
            AdBanner()
        }

    }

}




