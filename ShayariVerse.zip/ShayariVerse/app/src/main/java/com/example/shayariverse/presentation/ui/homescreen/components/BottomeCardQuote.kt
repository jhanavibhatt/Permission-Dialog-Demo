package com.example.shayariverse.presentation.ui.homescreen.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun BottomCradQuote(){
    Card(modifier = Modifier.fillMaxWidth()
        .height(100.dp),
        colors = CardDefaults.cardColors(Color.DarkGray),
        shape = RoundedCornerShape(20.dp)) {

        Column(
            modifier = Modifier.padding(30.dp)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("SPONSORED CONTENT",
                style = MaterialTheme.typography.titleMedium,
                color = Color.White)
            Text("Premimum AdPlacement"
                , color = Color.Gray,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Normal)
        }
    }
}