package com.example.shayariverse.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)
val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)
val ScreenBg = Color(0xFF191121)
val AccentPurple = Color(0XFF0C0512)
val AccentPurpleL = Color(0xFFA774FF)
val HeroBgStart = Color(0xFF1A0533)
val HeroBgMid = Color(0xFF2D0A4E)
val QuoteStripBg = Color(0xFF3A3048)
val QuoteText = Color(0xFFE7D9FF)
val QuoteStripBdr = Color(0xFFE9D9FF)

