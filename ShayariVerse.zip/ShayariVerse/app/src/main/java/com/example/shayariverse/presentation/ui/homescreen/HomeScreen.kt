package com.example.shayariverse.presentation.ui.homescreen

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.shayariverse.presentation.common.sharedcomponent.HomeTopBar
import com.example.shayariverse.presentation.ui.homescreen.components.QuotesTabContent
import com.example.shayariverse.presentation.ui.homescreen.components.ShayariTabContent
import com.example.shayariverse.ui.theme.ScreenBg

val PrimaryColor = Color(0xFF7F19E6)

@Composable
fun HomeScreen(navController: NavController) {


    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ScreenBg)
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {

        TabSwitcher(navController)
    }
}


@Composable
fun TabSwitcher(navController: NavController) {

    var selectedTab by remember { mutableIntStateOf(0) }

    val tabs = listOf("Shayari", "Quotes")
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    color = Color(0xFF2A1E3D), // dark background
                    shape = RoundedCornerShape(10.dp)
                )
            // inner padding
        ) {

            tabs.forEachIndexed { index, title ->

                val isSelected = selectedTab == index

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(15.dp))
                        .background(
                            if (isSelected) Color(0xFF7F19E6) // purple
                            else Color.Transparent
                        )
                        .clickable { selectedTab = index }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {

                    Text(
                        text = title,
                        color = if (isSelected) Color.White else Color.Gray
                    )
                }
            }
        }

        // Content
        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            when (selectedTab) {
                0 -> ShayariTabContent(navController)
                1 -> QuotesTabContent(navController)
            }
        }
    }

}
@Preview(showBackground = true, showSystemUi = true)
@Composable
fun HomeScreenPreview() {

        Example( )

}
@Composable
fun Example(){
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ScreenBg)
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        CustomTab(
            selectedItemIndex = selectedTab,
            items = listOf("Shayari", "Quotes"),
            onClick = { index -> selectedTab = index }
        )

        Spacer(modifier = Modifier.height(16.dp))

        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            when (selectedTab) {
                0 -> QuoteItems()
                1 -> ShayriItems()
            }
        }
    }
}
val PrimaryColor_1 = Color(0xFF7F19E6)
val TabBgColor = Color(0xFF2A1E3D)
@Composable
fun CustomTab(
    selectedItemIndex: Int,
    items: List<String>,
    modifier: Modifier = Modifier,
    onClick: (Int) -> Unit,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(
                color = TabBgColor,
                shape = RoundedCornerShape(10.dp)
            )
    ) {
        items.forEachIndexed { index, text ->
            val selected = index == selectedItemIndex

            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(15.dp))
                    .background(
                        if (selected) PrimaryColor_1 else Color.Transparent
                    ),
                contentAlignment = Alignment.Center
            ) {
                MyTabItem(
                    isSelected = selected,
                    onClick = { onClick(index) },
                    text = text,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}
@Composable
private fun MyTabItem(
    isSelected: Boolean,
    onClick: () -> Unit,
    text: String,
    modifier: Modifier = Modifier
) {
    val tabTextColor by animateColorAsState(
        targetValue = if (isSelected) Color.White else Color.Gray,
        animationSpec = tween(easing = LinearEasing),
        label = ""
    )

    Text(
        modifier = modifier
            .clip(RoundedCornerShape(15.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        text = text,
        color = tabTextColor,
        textAlign = TextAlign.Center
    )
}


@Composable
fun QuoteItems(){
    Text(text = "Quote Items")
}
@Composable
fun ShayriItems(){
    Text(text = "Shayri Items")
}

