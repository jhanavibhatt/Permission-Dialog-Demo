package com.example.shayariverse.presentation.ui.homescreen

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.shayariverse.R
import com.example.shayariverse.presentation.common.sharedcomponent.HomeTopBar
import com.example.shayariverse.presentation.ui.homescreen.components.QuotesTabContent
import com.example.shayariverse.presentation.ui.homescreen.components.ShayariTabContent
import com.example.shayariverse.ui.theme.ScreenBg

val PrimaryColor = Color(0xFF7F19E6)

@Composable
fun HomeScreen(navController: NavController) {
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }


    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ScreenBg)
            .padding(15.dp)
    ) {

        TabSwitcher(
            selectedItemIndex = selectedTab,
            items = listOf(stringResource(R.string.shayari), stringResource(R.string.quotes)),
            onClick = { index -> selectedTab = index },
        )
        Spacer(modifier = Modifier.height(16.dp))
        Box(modifier = Modifier
            .weight(1f)
            .fillMaxWidth()) {
            when (selectedTab) {
                0 -> ShayariTabContent(navController)
                1 -> QuotesTabContent(navController)
            }
        }
    }
}


@Composable
fun TabSwitcher(
    selectedItemIndex: Int,
    items: List<String>,
    modifier: Modifier = Modifier,
    onClick: (Int) -> Unit
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(
                color = Color(0xFF2A1E3D),
                shape = RoundedCornerShape(12.dp)
            )
    ) {

        items.forEachIndexed { index, title ->

            val selected = index == selectedItemIndex

            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(15.dp))
                    .background(
                        if (selected) Color(0xFF7F19E6) // purple
                        else Color.Transparent
                    )
                    .clickable { onClick(index) }
                    .padding(vertical = 5.dp),
                contentAlignment = Alignment.Center
            ) {

                MyTabItem(
                    isSelected = selected,
                    text = title,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }

}

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun HomeScreenPreview() {

    HomeScreen(navController = rememberNavController())

}


@Composable
private fun MyTabItem(
    isSelected: Boolean,
    text: String,
    modifier: Modifier = Modifier
) {
    val tabTextColor by animateColorAsState(
        targetValue = if (isSelected) Color.White else Color.Gray,
        animationSpec = tween(easing = LinearEasing),
        label = ""
    )

    Text(
        modifier = modifier
            .clip(RoundedCornerShape(15.dp))
            .padding(vertical = 10.dp),
        text = text,
        color = tabTextColor,
        textAlign = TextAlign.Center
    )
}



