package com.example.shayariverse.presentation.ui.homescreen.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.FormatQuote
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun QuoteOfDayCard() {

    val gradient = remember {
        Brush.linearGradient(
            colors = listOf(
                Color(0xFF1E1230),
                Color(0xFF2A1E3D)
            )
        )
    }

    Card(
        modifier = Modifier
            .fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {

        Box(
            modifier = Modifier
                .background(gradient)
                .padding(16.dp)
        ) {


            Icon(
                imageVector = Icons.Default.FormatQuote,
                contentDescription = null,
                tint = Color.White.copy(alpha = 0.05f),
                modifier = Modifier
                    .size(120.dp)
                    .align(Alignment.TopEnd)
                    .offset(x = 20.dp, y = (-10).dp)
            )

            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {

                // ✅ 1️⃣ Pill Background Label
                Box(
                    modifier = Modifier
                        .background(
                            color = Color(0xFF7F19E6).copy(alpha = 0.2f),
                            shape = RoundedCornerShape(50)
                        )
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "QUOTE OF THE DAY",
                        color = Color(0xFFB388FF),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // 🔹 Quote Text
                Text(
                    text = "\"The soul always knows what to do to heal itself. The challenge is to silence the mind.\"",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontStyle = FontStyle.Italic,
                    lineHeight = 22.sp
                )

                // 🔹 Bottom Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {

                    // Author
                    Row(verticalAlignment = Alignment.CenterVertically) {

                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(
                                    Color(0xFF7F19E6),
                                    shape = CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("C", color = Color.White)
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        Text(
                            text = "Caroline Myss",
                            color = Color.White.copy(alpha = 0.8f)
                        )
                    }

                    // ✅ 2️⃣ Action Buttons with Background
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {

                        ActionIconButton(icon = Icons.Default.Share)

                        ActionIconButton(icon = Icons.Default.ContentCopy)
                    }
                }
            }
        }
    }
}
@Composable
fun ActionIconButton(icon: ImageVector) {

    Box(
        modifier = Modifier
            .size(36.dp)
            .background(
                Color.White.copy(alpha = 0.08f), // 👈 glass effect
                shape = RoundedCornerShape(10.dp)
            ),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(18.dp)
        )
    }
}