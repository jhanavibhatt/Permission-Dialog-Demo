package com.example.shayariverse.model

interface BaseItem {
    val category: String
}