package com.example.shayariverse.presentation.ui.listscreen.components

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FileCopy
import androidx.compose.material.icons.filled.FormatQuote
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.outlined.FileCopy
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.shayariverse.FavoriteManager
import com.example.shayariverse.model.FavoriteEntity
import com.example.shayariverse.model.Quote
import com.example.shayariverse.presentation.ui.favoritescreen.ContentItem
import com.example.shayariverse.presentation.ui.homescreen.PrimaryColor
import com.example.shayariverse.viewmodel.FavoriteViewModel
import kotlinx.coroutines.delay

@Composable
fun QuoteItemCard(quote: Quote,viewModel: FavoriteViewModel) {

    val isFav by viewModel.isFavorite(quote.quote).collectAsState()

    val clipboardManager = LocalClipboardManager.current
    val context = LocalContext.current
    var isCopied by remember { mutableStateOf(false) }


    LaunchedEffect(isCopied) {
        if (isCopied) {
            delay(1500)
            isCopied = false
        }
    }
    val entity = FavoriteEntity(
        text = quote.quote,
        type = "quote",
        category = quote.category,
        author = quote.author
    )
    val contentItem = ContentItem(
        text = quote.quote,
        type = "quote",
        category = quote.category,
        author = quote.author
    )

//    var isFav by remember {
//        mutableStateOf(FavoriteManager.isFavorite(contentItem.text))
//    }

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF2A1E3D)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {

        Column(modifier = Modifier.padding(16.dp)) {

            Icon(
                imageVector = Icons.Default.FormatQuote,
                contentDescription = null,
                tint = PrimaryColor.copy(alpha = 0.4f),
                modifier = Modifier.size(20.dp)
            )

            Spacer(Modifier.height(8.dp))

            Text(
                text = "\"${quote.quote}\"",
                color = Color.White
            )

            Spacer(Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {

                Text(
                    text = "— ${quote.author}",
                    color = Color.Gray,
                    fontSize = 12.sp
                )

                CategoryBadge(quote.category)
            }

            Spacer(Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
            ) {

                ActionItem(
                    icon = Icons.Default.Favorite,
                    tint = if (isFav) Color.Red else Color.Gray,
                    onClick = {
                        viewModel.toggleFavorite(entity)
                    },
                    modifier = Modifier.weight(1f),
                    text = "Add to Favorite "

                )
                ActionItem(
                    icon = if (isCopied) Icons.Filled.FileCopy else Icons.Outlined.FileCopy,
                    text = if (isCopied) "Copied" else "Copy",
                    modifier = Modifier.weight(1f),
                    onClick = {
                        clipboardManager.setText(AnnotatedString(quote.quote))
                        isCopied = true
                    }
                )
                ActionItem(Icons.Default.Share, "Share",onClick = {
                    val shareText = "\"${quote.quote}\" \n\n— ${quote.author}"

                    val intent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, shareText)
                    }

                    context.startActivity(
                        Intent.createChooser(intent, "Share via")
                    )
                },
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}
@Composable
fun ActionItem(icon: ImageVector, text: String? = null, tint: Color = Color.Gray,
               onClick: (() -> Unit)? = null,  modifier: Modifier = Modifier) {
    Column(horizontalAlignment = Alignment.CenterHorizontally,

            modifier = modifier.clickable { onClick?.invoke() }) {
        Icon(icon, contentDescription = null, tint =tint)

        if (text != null) {
            Text(text, color = Color.Gray, fontSize = 10.sp)
        }
    }
}
@Composable
fun CategoryBadge(text: String) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(PrimaryColor.copy(alpha = 0.2f))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text = text.uppercase(),
            color = PrimaryColor,
            fontSize = 10.sp
        )
    }
}