package com.example.shayariverse.presentation.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.FormatQuote
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

import com.example.shayariverse.ui.theme.ScreenBg

private val AccentPurple  = Color(0xFF7C3AED)
private val AccentPurpleL = Color(0xFFA774FF)
private val HeroBgStart   = Color(0xFF1A0533)
private val HeroBgMid     = Color(0xFF2D0A4E)
private val BadgeBg       = Color(0x33A774FF)
private val BadgeText     = Color(0xFFC9A4FF)
private val QuoteStripBg  = Color(0xFF3A3048)
private val QuoteText     = Color(0xFFE7D9FF)
private val QuoteStripBdr = Color(0xFFE9D9FF)


private data class FeatureItem(
    val iconRes: ImageVector,         // e.g. R.drawable.ic_grid
    val label: String,
    val bgColor: Color,
    val iconColor: Color
)

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun AboutScreen() {
    val gradient = remember {
        Brush.linearGradient(
            colors = listOf(
                Color(0xFF1E1230),
                Color(0xFF2A1E3D)
            )
        )
    }
    LazyColumn(modifier = Modifier
        .fillMaxSize()
        .background(ScreenBg)) {
        item {
            HeroSection()
        }
        item {
            HorizontalDivider(color = QuoteStripBdr, thickness = 0.5.dp)
        }
        item {
            QuoteBannerSection()
        }

        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth().padding(15.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent)
            ) {

                Box(
                    modifier = Modifier
                        .background(gradient)
                        .padding(16.dp)
                ) {


                    Icon(
                        imageVector = Icons.Default.FormatQuote,
                        contentDescription = null,
                        tint = Color.White.copy(alpha = 0.05f),
                        modifier = Modifier
                            .size(120.dp)
                            .align(Alignment.TopEnd)
                            .offset(x = 20.dp, y = (-10).dp)
                    )


                    Column(
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {


                            Text(
                                text = "Our Story",
                                color = Color(0xFFB388FF),
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )

           Spacer(Modifier.height(10.dp))
                        // 🔹 Quote Text
                        Text(
                            text = "ShayariVerse was born as a sanctuary for those who find beauty in words. We bridge the gap between the timeless art of traditional Shayari and the sharpness of contemporary quotes. In a world of fleeting digital noise, we curate moments of profound literary resonance, creating an ethereal anthology for the modern reader.",
                            color = Color.White,
                            fontSize = 16.sp,
                            fontStyle = FontStyle.Italic,
                            lineHeight = 22.sp
                        )
                    }
                }
            }
        }
        item {
            AboutDescription()
        }
       item{
           FeaturesGridSection()
       }
        item{
            MadeWithFooter()
        }
    }
}


@Composable
private fun HeroSection() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.linearGradient(
                    colors = listOf(HeroBgStart, HeroBgMid, HeroBgStart),
                    start = Offset(0f, 0f),
                    end = Offset(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY)
                ),
                shape = RoundedCornerShape(15.dp)
            )
            .padding(vertical = 32.dp, horizontal = 24.dp),
        contentAlignment = Alignment.Center
    ) {
        // Decorative circle — top left
        Box(
            modifier = Modifier
                .size(140.dp)
                .offset(x = (-40).dp, y = (-40).dp)
                .clip(CircleShape)
                .background(Color(0x1FA774FF))
                .align(Alignment.TopStart)
        )
        // Decorative circle — bottom right
        Box(
            modifier = Modifier
                .size(100.dp)
                .offset(x = 30.dp, y = 30.dp)
                .clip(CircleShape)
                .background(Color(0x14FFB464))
                .align(Alignment.BottomEnd)
        )

        Column(horizontalAlignment = Alignment.CenterHorizontally) {

            // App icon
            Box(
                modifier = Modifier
                    .size(76.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(AccentPurpleL, AccentPurple)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                // Replace with your actual feather / logo icon:
                // Icon(painter = painterResource(R.drawable.ic_feather), ...)
                Text(text = "✦", fontSize = 34.sp, color = Color.White)
            }

            Spacer(Modifier.height(16.dp))

            Text(
                text = "ShayriVerse",
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                letterSpacing = 0.5.sp
            )

            Spacer(Modifier.height(4.dp))

            Text(
                text = "WHERE WORDS FIND A SOUL",
                fontSize = 11.sp,
                color = Color.White.copy(alpha = 0.5f),
                letterSpacing = 2.5.sp
            )

            Spacer(Modifier.height(14.dp))


        }
    }
}

@Composable
fun QuoteBannerSection() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(QuoteStripBg)
            .padding(15.dp),
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Quote icon
        Icon(
            imageVector = Icons.Default.FormatQuote,
            contentDescription = null,
            tint = Color(0xFF9C6BFF),
            modifier = Modifier
                .size(28.dp)
        )
        Text(
            text = "Words have the power to both destroy and heal. " +
                    "When words are both true and kind, they can change the world.",
            style = MaterialTheme.typography.bodyMedium,
            fontStyle = FontStyle.Italic,
            color = QuoteText,
            lineHeight = 20.sp,
            modifier = Modifier.padding(top=2.dp)
        )
    }
    HorizontalDivider(color = QuoteStripBdr, thickness = 0.5.dp)


}

@Composable
private fun AboutDescription() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .padding(top = 20.dp, bottom = 8.dp)
    ) {
        Text(
            text = "ABOUT THIS APP",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Medium,
            color = Color.White,
            letterSpacing = 1.2.sp
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = "ShayriVerse is your personal collection of beautiful Shayri and inspiring quotes. " +
                    "Explore thousands of handpicked verses across categories — love, motivation, " +
                    "life, friendship, and more.",
            style = MaterialTheme.typography.bodyMedium,
            color = Color.White,
            lineHeight = 21.sp
        )
    }
}

/*@Composable
private fun FeaturesSection() {
    // Replace iconRes with your actual drawable resource IDs
    val features = listOf(
        FeatureItem(
            iconRes = Icons.Default.Share, // replace: R.drawable.ic_grid
            label = "100+ Categories",
            bgColor = Color(0xFFF0E9FF),
            iconColor = Color.Blue
        ),
        FeatureItem(
            iconRes = Icons.Default.Favorite,        // replace: R.drawable.ic_heart
            label = "Save Favourites",
            bgColor = Color(0xFFFFF4E0),
            iconColor = Color(0xFFB45309)
        ),
        FeatureItem(
            iconRes = Icons.Default.Share,   // replace: R.drawable.ic_share
            label = "Easy Sharing",
            bgColor = FeatureTealBg,
            iconColor = FeatureTealIcon
        ),
        FeatureItem(
            iconRes = android.R.drawable.ic_menu_edit,    // replace: R.drawable.ic_copy
            label = "Copy Instantly",
            bgColor = FeaturePinkBg,
            iconColor = FeaturePinkIcon
        )
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .padding(top = 16.dp, bottom = 20.dp)
    ) {
        SectionLabel(text = "FEATURES")
        Spacer(Modifier.height(10.dp))

        // Two-column grid — Row 1
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FeatureCard(item = features[0], modifier = Modifier.weight(1f))
            FeatureCard(item = features[1], modifier = Modifier.weight(1f))
        }
        Spacer(Modifier.height(8.dp))
        // Row 2
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FeatureCard(item = features[2], modifier = Modifier.weight(1f))
            FeatureCard(item = features[3], modifier = Modifier.weight(1f))
        }
    }
}*/
@Composable
fun FeaturesGridSection() {

    Column(Modifier.fillMaxWidth().padding(15.dp)) {
        Text(
            text = "FEATURES",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Medium,
            color = Color.White,
            letterSpacing = 1.2.sp
        )
        Spacer(Modifier.height(10.dp))

        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {

            FeatureGridCard(
                modifier = Modifier.weight(1f),
                icon = Icons.Default.GridView,
                iconBg = Color(0xFF4B1FA6),
                iconTint = Color(0xFF9C6BFF),
                title = "100+ Categories"
            )

            FeatureGridCard(
                modifier = Modifier.weight(1f),
                icon = Icons.Default.FavoriteBorder,
                iconBg = Color(0xFF5B3417),
                iconTint = Color(0xFFFF8A33),
                title = "Save Favourites"
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {

            FeatureGridCard(
                modifier = Modifier.weight(1f),
                icon = Icons.Default.Share,
                iconBg = Color(0xFF063B35),
                iconTint = Color(0xFF00C896),
                title = "Easy Sharing"
            )

            FeatureGridCard(
                modifier = Modifier.weight(1f),
                icon = Icons.Default.ContentCopy,
                iconBg = Color(0xFF4A1732),
                iconTint = Color(0xFFFF4D8D),
                title = "Copy Instantly"
            )
        }
    }
}
@Composable
fun FeatureGridCard(
    modifier: Modifier = Modifier,
    icon: ImageVector,
    iconBg: Color,
    iconTint: Color,
    title: String
) {

    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF232323)
        ),
        border = BorderStroke(
            1.dp,
            Color.White.copy(alpha = 0.08f)
        )
    ) {

        Column(
            modifier = Modifier
                .padding(16.dp)
                .height(80.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {

            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(iconBg),
                contentAlignment = Alignment.Center
            ) {

                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(18.dp)
                )
            }

            Text(
                text = title,
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
private fun MadeWithFooter() {
    HorizontalDivider(
        color = Color(0xFFEEEEEE),
        thickness = 0.5.dp
    )
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Text(
                text = "Made with ",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.45f)
            )
            Text(
                text = "♥",
                fontSize = 12.sp,
                color = Color.Red
            )
            Text(
                text = " by ",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.45f)
            )
            Text(
                text = "ShayriVerse Team",
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
            )
        }
        Spacer(Modifier.height(4.dp))
        Text(
            text = "© 2026 ShayriVerse. All rights reserved.",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.35f),
            textAlign = TextAlign.Center
        )
    }
}

