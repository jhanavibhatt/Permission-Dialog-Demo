package com.example.shayariverse.presentation.ui.categoryscreen

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.DeviceHub
import androidx.compose.material.icons.filled.EmojiEmotions
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.HighlightOff
import androidx.compose.material.icons.filled.HourglassBottom
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.MonitorHeart
import androidx.compose.material.icons.filled.Mood
import androidx.compose.material.icons.filled.Nightlight
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.SentimentSatisfied
import androidx.compose.material.icons.filled.ShieldMoon
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TagFaces
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.VolunteerActivism
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.shayariverse.presentation.common.sharedcomponent.HomeTopBar
import com.example.shayariverse.model.Category
import com.example.shayariverse.presentation.ui.categoryscreen.components.AllCategoryGrid
import com.example.shayariverse.ui.theme.ScreenBg


val shayariCategories = listOf(
    Category("Love","64 Shayari",Icons.Default.Favorite,Color.Red),
    Category("Motivation","46 Shayari",Icons.Default.Bolt,Color.Yellow),
    Category("Sad","53 Shayari",Icons.Default.Cloud,Color.Blue),
    Category("Friendship","24 Shayari",Icons.Default.Group,Color.Green),
    Category("Life","24 Shayari",Icons.Default.Psychology,Color(0xFFFF9800)),
    Category("Good Morning","20 Shayari",Icons.Default.WbSunny,Color(0xFFFFC107)),
    Category("Good Night","30 Shayari",Icons.Default.Nightlight,Color(0xFFFFC107)),
    Category("Heart Touching","59 Shayari",Icons.Default.Favorite,Color(0xFFE91E63)),
    Category("Flirty","37 Shayari",Icons.Default.TagFaces,Color(0xFFFF4081)),
    Category("Funny","36 Shayari",Icons.Default.EmojiEmotions,Color(0xFFFF9800)),
    Category("Family","44 Shayari",Icons.Default.Groups,Color(0xFF4CAF50)),
    Category("Attitude","34 Shayari",Icons.Default.Star,Color(0xFF3F51B5))

)

val categoriesQuotes = listOf(
    Category("Wisdom", "124 quotes", Icons.Filled.AutoStories, Color(0xFF6A11CB)),
    Category("Life", "332 quotes", Icons.Filled.DeviceHub, Color(0xFF3A1C71)),
    Category("Inspirational", "89 quotes", Icons.Filled.Lightbulb, Color(0xFFFF8008)),
    Category("Success", "154 quotes", Icons.Filled.EmojiEvents, Color(0xFF4A00E0)),
    Category("Happiness", "245 quotes", Icons.Filled.SentimentSatisfied, Color(0xFFC33764)),
    Category("Funny", "47 quotes", Icons.Filled.EmojiEmotions, Color(0xFF734B6D)),
    Category("Motivational", "72 quotes", Icons.AutoMirrored.Filled.TrendingUp, Color(0xFF243B55)),
    Category("Hope", "189 quotes", Icons.Filled.WbSunny, Color(0xFFFFAF7B)),
    Category("Attitude", "189 quotes", Icons.Filled.Mood, Color(0xFFFFAF7B)),
    Category("Dreams", "189 quotes", Icons.Filled.Bedtime, Color(0xFF7F19E6)),
    Category("Confidence", "189 quotes", Icons.Filled.ThumbUp, Color(0xFF4CAF50)),
    Category("Failure", "189 quotes", Icons.Filled.HighlightOff, Color(0xFFE53935)),
    Category("Courage", "189 quotes", Icons.Filled.Security, Color(0xFFFF9800)),
    Category("Kindness", "189 quotes", Icons.Filled.VolunteerActivism, Color(0xFFE91E63)),
    Category("Discipline", "189 quotes", Icons.Filled.Schedule, Color(0xFF03A9F4)),
    Category("Growth", "189 quotes", Icons.AutoMirrored.Filled.TrendingUp, Color(0xFF4CAF50)),
    Category("Patience", "189 quotes", Icons.Filled.HourglassBottom, Color(0xFFFFC107)),
    Category("Focus", "189 quotes", Icons.Filled.CenterFocusStrong, Color(0xFF9C27B0)),
    Category("Positivity", "189 quotes", Icons.Filled.WbSunny, Color(0xFFFFEB3B)),
    Category("Leadership", "189 quotes", Icons.Filled.Groups, Color(0xFF3F51B5)),
    Category("Gratitude", "189 quotes", Icons.Filled.Favorite, Color(0xFFE91E63)),
    Category("Peace", "189 quotes", Icons.Filled.SelfImprovement, Color(0xFF009688))
)
@Composable
fun CategoryScreen(
    type: String?,
    navController: NavController
) {

    val title = when (type) {
        "quotes" -> "All Quotes Categories"
        "shayari" -> "All Shayari Categories"
        else -> "Categories"
    }

    val data = when (type) {
        "shayari" -> shayariCategories
        "quotes" -> categoriesQuotes
        else -> emptyList()
    }



        AllCategoryGrid(
            categories = data,
            type = type ?: "quotes",
            navController = navController,
            modifier = Modifier
                .fillMaxWidth()
                .background(ScreenBg)
                .padding(16.dp)
        )
    }






