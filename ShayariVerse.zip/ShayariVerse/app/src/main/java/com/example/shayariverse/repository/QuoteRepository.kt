package com.example.shayariverse.repository

import android.content.Context
import com.example.shayariverse.model.Quote
import com.example.shayariverse.model.Shayri
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object QuoteRepository {
    private var quotesCache: List<Quote>? = null
    private var shayriCache: List<Shayri>? = null

    suspend fun loadQuotes(context: Context): List<Quote> =
        quotesCache ?: withContext(Dispatchers.IO) {
            val json = context.assets
                .open("quotes_with_authors.json")
                .bufferedReader()
                .use { it.readText() }
            val type = object : TypeToken<List<Quote>>() {}.type
            Gson().fromJson<List<Quote>>(json, type).also { quotesCache = it }
        }


    suspend fun loadShayri(context: Context): List<Shayri> =
        shayriCache ?: withContext(Dispatchers.IO) {
            val json = context.assets
                .open("shayri.json")
                .bufferedReader()
                .use { it.readText() }
            val type = object : TypeToken<List<Shayri>>() {}.type
            Gson().fromJson<List<Shayri>>(json, type).also { shayriCache = it }
        }

}