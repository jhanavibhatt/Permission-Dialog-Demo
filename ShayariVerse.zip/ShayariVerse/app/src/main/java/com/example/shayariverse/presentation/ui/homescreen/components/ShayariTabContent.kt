package com.example.shayariverse.presentation.ui.homescreen.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.shayariverse.R
import com.example.shayariverse.model.Category
import com.example.shayariverse.presentation.navigation.AppRoute
import com.example.shayariverse.presentation.navigation.CategoryType


val categories = listOf(
    Category("Love","64 Shayari",Icons.Default.Favorite,Color.Red),
    Category("Motivation","46 Shayari",Icons.Default.Bolt,Color.Yellow),
    Category("Sad","53 Shayari",Icons.Default.Cloud,Color.Blue),
    Category("Friendship","24 Shayari",Icons.Default.Group,Color.Green),
    Category("Life","24 Shayari",Icons.Default.Psychology,Color(0xFFFF9800)),
    Category("Good Morning","20 Shayari",Icons.Default.WbSunny,Color(0xFFFFC107)),
    Category("Heart Touching","59 Shayari",Icons.Default.Favorite,Color(0xFFE91E63)),
    Category("Attitude","34 Shayari",Icons.Default.Star,Color(0xFF3F51B5))
)

@Composable
fun ShayariTabContent(navController: NavController) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column {
                ShayariOfDayCard()
            }
        }

        // 2. Explore Header (Span 2 columns to take full width)
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column {
                ExploreHeader(stringResource(R.string.explore_shayari), onSeeAllClick = {
                    navController.navigate(AppRoute.Categories(CategoryType.SHAYARI))
                })
                Spacer(Modifier.height(16.dp))
            }
        }
        items(categories, key = { it.title }) { category ->
            CategoryCard(category, CategoryType.SHAYARI, navController)
        }

        // 4. Ad Banner (Span 2 columns to take full width)
        item(span = { GridItemSpan(2) }) {
            AdBanner()
        }
    }

    }