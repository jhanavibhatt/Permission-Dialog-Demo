package com.example.shayariverse.presentation.ui.homescreen.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.shayariverse.model.Category
import com.example.shayariverse.presentation.navigation.AppRoute


val categories = listOf(
    Category("Love","1.2k+ Shayari",Icons.Default.Favorite,Color.Red),
    Category("Motivation","850+ Shayari",Icons.Default.Bolt,Color.Yellow),
    Category("Sad","2.1k+ Shayari",Icons.Default.Cloud,Color.Blue),
    Category("Friendship","640+ Shayari",Icons.Default.Group,Color.Green),
    Category("Life","920+ Shayari",Icons.Default.Psychology,Color(0xFFFF9800)),
    Category("Good Morning","430+ Shayari",Icons.Default.WbSunny,Color(0xFFFFC107)),
    Category("Success","1.1k+ Shayari",Icons.Default.EmojiEvents,Color(0xFF00C853)),
    Category("Attitude","1.5k+ Shayari",Icons.Default.Star,Color(0xFF3F51B5))
)

@Composable
fun ShayariTabContent(navController: NavController) {
/*
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(
            vertical = 16.dp
        )
    ) {

        item {
            Spacer(Modifier.height(16.dp))
            ShayariOfDayCard()
            Spacer(Modifier.height(16.dp))
        }

        item {
            Spacer(Modifier.height(16.dp))
            ExploreHeader("Explore Shayari", onSeeAllClick = {
                navController.navigate(AppRoute.Categories("shayari"))
            })
            Spacer(Modifier.height(16.dp))
        }

        items(categories.chunked(2)) { rowItems ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                rowItems.forEach { category ->
                    Box(modifier = Modifier.weight(1f)) {
                        CategoryCard(category, "shayari", navController)
                    }
                }
                if (rowItems.size == 1) {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
        }

        item {
            AdBanner()
        }
    }*/
    LazyVerticalGrid(
        columns = GridCells.Fixed(2), // 2 columns for categories
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        // 1. Shayari of Day (Span 2 columns to take full width)
        item(span = { GridItemSpan(2) }) {
            Column {
                Spacer(Modifier.height(16.dp))
                ShayariOfDayCard()
                Spacer(Modifier.height(16.dp))
            }
        }

        // 2. Explore Header (Span 2 columns to take full width)
        item(span = { GridItemSpan(2) }) {
            Column {
                Spacer(Modifier.height(16.dp))
                ExploreHeader("Explore Shayari", onSeeAllClick = {
                    navController.navigate(AppRoute.Categories("shayari"))
                })
                Spacer(Modifier.height(16.dp))
            }
        }
        items(categories, key = { it.title }) { category ->
            CategoryCard(category, "shayari", navController)
        }

        // 4. Ad Banner (Span 2 columns to take full width)
        item(span = { GridItemSpan(2) }) {
            AdBanner()
        }
    }

    }