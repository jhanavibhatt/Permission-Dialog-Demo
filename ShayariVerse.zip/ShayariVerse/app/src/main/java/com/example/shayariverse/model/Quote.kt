package com.example.shayariverse.model

data class Quote(
    override val category: String,
    val quote: String,
    val author: String
) : BaseItem
