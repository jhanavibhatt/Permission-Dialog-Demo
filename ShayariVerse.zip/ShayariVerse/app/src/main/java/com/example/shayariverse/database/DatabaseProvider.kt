package com.example.shayariverse.database

import android.content.Context
import androidx.room.Room

object DatabaseProvider {

    private var INSTANCE: AppDatabase? = null

    fun getDatabase(context: Context): AppDatabase {
        return INSTANCE ?: synchronized(this) {
            Room.databaseBuilder(
                context,
                AppDatabase::class.java,
                "shayari_db"
            ).fallbackToDestructiveMigration(true)
                .build().also { INSTANCE = it }
        }
    }
}