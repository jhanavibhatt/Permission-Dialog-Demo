package com.example.shayariverse

enum class ContentType {
    SHAYARI,
    QUOTE
}