package com.example.shayariverse.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.shayariverse.dao.FavoriteDao
import com.example.shayariverse.model.FavoriteEntity

@Database(entities = [FavoriteEntity::class], version = 3, exportSchema = false )
abstract class AppDatabase : RoomDatabase() {
    abstract fun favoriteDao(): FavoriteDao
}