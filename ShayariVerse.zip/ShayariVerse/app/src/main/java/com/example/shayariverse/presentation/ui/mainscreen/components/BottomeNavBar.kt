package com.example.shayariverse.presentation.ui.mainscreen.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.navigation.NavController
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.compose.currentBackStackEntryAsState
import com.example.shayariverse.presentation.navigation.AppRoute

@Composable
fun BottomNavBar(navController: NavController) {

    val items = listOf(
        AppRoute.Home,
        AppRoute.Favorites,
        AppRoute.Settings
    )

    val icons = listOf(
        Icons.Default.Home,
        Icons.Default.Settings,
        Icons.Default.Favorite,
    )

    val labels = listOf(
        "Home",
        "Settings",
        "Favorites",

    )

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination


    NavigationBar {

        items.forEach { route ->
            val isSelected = when (route) {
                is AppRoute.Home ->
                    currentDestination?.hasRoute<AppRoute.Home>() == true

                is AppRoute.Favorites ->
                    currentDestination?.hasRoute<AppRoute.Favorites>() == true

                is AppRoute.Settings ->
                    currentDestination?.hasRoute<AppRoute.Settings>() == true

                else -> false
            }
            NavigationBarItem(
                selected = isSelected,
                onClick = {
                    navController.navigate(route) {
                        popUpTo(0) { saveState = true } // clean backstack
                        launchSingleTop = true
                        restoreState = true
                    }
                },
                icon = {
                    when (route) {
                        is AppRoute.Home ->
                            Icon(Icons.Default.Home, null)

                        is AppRoute.Settings ->
                            Icon(Icons.Default.Settings, null) // ✅ saved icon

                        is AppRoute.Favorites ->
                            Icon(Icons.Default.Favorite, null)

                        else -> {}
                    }
                },
                label = {
                    Text(
                        when (route) {
                            is AppRoute.Home -> "Home"
                            is AppRoute.Settings -> "Settings"
                            is AppRoute.Favorites -> "Favorites"
                            else -> ""
                        }
                    )
                }
            )
        }
    }
}