package com.example.shayariverse.presentation.navigation

import kotlinx.serialization.Serializable

@Serializable
sealed class AppRoute {

    @Serializable
    data object Home : AppRoute()

    @Serializable
    data object Favorites : AppRoute()

    @Serializable
    data object Settings : AppRoute()

    @Serializable
    data object  About : AppRoute()

    @Serializable
    data class Categories(val type: String) : AppRoute()

    @Serializable
    data class ListScreen(
        val type: String,
        val category: String
    ) : AppRoute()
}