package com.example.shayariverse.presentation.ui.mainscreen

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavBackStackEntry
import androidx.navigation.NavDestination
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.shayariverse.presentation.common.sharedcomponent.HomeTopBar
import com.example.shayariverse.presentation.navigation.AppRoute
import com.example.shayariverse.presentation.ui.AboutScreen
import com.example.shayariverse.presentation.ui.mainscreen.components.BottomNavBar
import com.example.shayariverse.presentation.ui.categoryscreen.CategoryScreen
import com.example.shayariverse.presentation.ui.favoritescreen.FavoriteScreen
import com.example.shayariverse.presentation.ui.homescreen.HomeScreen
import com.example.shayariverse.presentation.ui.listscreen.ListScreen
import com.example.shayariverse.presentation.ui.settingsscreen.SettingsScreen
import dagger.hilt.android.AndroidEntryPoint
import java.util.Map.entry

@Composable
fun MainScreen() {

    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val destination = backStackEntry?.destination

    val title = when {
        destination?.hasRoute<AppRoute.Home>()      == true -> "ShayariVerse"
        destination?.hasRoute<AppRoute.Favorites>() == true -> "Favorites"
        destination?.hasRoute<AppRoute.Settings>()  == true -> "Settings"
        destination?.hasRoute<AppRoute.About>()     == true -> "About"
        destination?.hasRoute<AppRoute.Categories>() == true -> {
            val type = runCatching {
                backStackEntry?.toRoute<AppRoute.Categories>()?.type
            }.getOrNull()
            when (type) {
                "shayari" -> "All Shayari Categories"
                "quotes"  -> "All Quotes Categories"
                else      -> "Categories"
            }
        }
        destination?.hasRoute<AppRoute.ListScreen>() == true -> {
            runCatching {
                backStackEntry?.toRoute<AppRoute.ListScreen>()?.category
            }.getOrNull() ?: "Collection"
        }
        else -> "ShayariVerse"
    }
    val showBack = destination?.hasRoute<AppRoute.Home>() != true &&
            destination?.hasRoute<AppRoute.Favorites>() != true &&
            destination?.hasRoute<AppRoute.Settings>() != true

    

    Scaffold(
        topBar = {
            HomeTopBar(
                title = title,
                subtitle = null,
                showBack = showBack,
                onBackClick = { navController.popBackStack() }
            )
        },
        bottomBar = {
            val showBottomBar =
                destination?.hasRoute<AppRoute.Home>() == true ||
                        destination?.hasRoute<AppRoute.Favorites>() == true ||
                        destination?.hasRoute<AppRoute.Settings>() == true
            if (showBottomBar) {
                BottomNavBar(navController)
            }
        } //  only bottom bar here
    ) { padding ->

        NavHost(
            navController = navController,
            startDestination = AppRoute.Home,
            modifier = Modifier.padding(padding)
        ) {

            composable<AppRoute.Home> {
                HomeScreen(navController)
            }

            composable<AppRoute.Favorites> {
                FavoriteScreen()
            }
            composable<AppRoute.Settings> {
                SettingsScreen(navController)
            }
            composable<AppRoute.About> {
                AboutScreen()
            }

            composable<AppRoute.Categories> { entry ->
                val args = entry.toRoute<AppRoute.Categories>()

                CategoryScreen(
                    type = args.type,
                    navController = navController
                )
            }

            composable<AppRoute.ListScreen> { entry ->
                val args = entry.toRoute<AppRoute.ListScreen>()

                ListScreen(
                    category = args.category,
                    type = args.type,
                    navController = navController
                )
            }

        }
    }
}