package com.example.shayariverse.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.shayariverse.model.FavoriteEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface FavoriteDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: FavoriteEntity)

    @Query("SELECT * FROM favorites")
    fun getAll(): Flow<List<FavoriteEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE text = :text)")
    fun isFavorite(text: String): Flow<Boolean>

    @Query("DELETE FROM favorites WHERE id = :id")
    suspend fun delete(id: Int)

    @Query("DELETE FROM favorites WHERE text = :text")
    suspend fun deleteByText(text: String)
}