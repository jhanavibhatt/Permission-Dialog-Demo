package com.example.shayariverse.presentation.ui.settingsscreen

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.FormatQuote
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.shayariverse.presentation.ui.settingsscreen.components.RateAppDialog
import com.example.shayariverse.presentation.ui.settingsscreen.components.SectionTitle
import com.example.shayariverse.presentation.ui.settingsscreen.components.SettingItem
import com.example.shayariverse.ui.theme.ScreenBg
import androidx.core.net.toUri
import androidx.navigation.NavController
import com.example.shayariverse.presentation.navigation.AppRoute

@SuppressLint("SuspiciousIndentation")
@Composable
fun SettingsScreen(navController: NavController) {
    var showRateDialog by remember { mutableStateOf(false) }
    val context = LocalContext.current



        // Header

        LazyColumn(modifier = Modifier
            .fillMaxSize()
            .background(ScreenBg)) {

            // App Profile Section
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {

                    Box(
                        modifier = Modifier
                            .size(80.dp)
                            .clip(RoundedCornerShape(20.dp))
                            .background(
                                Brush.linearGradient(
                                    listOf(Color(0xFF7F19E6), Color(0x997F19E6))
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.FormatQuote,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(40.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        "ShayariVerse",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = Color.White
                    )

                    Text(
                        "Version 2.4.0",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                }
            }

            // Support Section
            item {
                SectionTitle("Support & Community")

                SettingItem("Rate App", Icons.Default.Star, onClick = {showRateDialog = true })
                SettingItem("Share with Friends", Icons.Default.Share, onClick = {})
                SettingItem("Send Feedback", Icons.Default.Email, onClick = {
                    val intent = Intent(Intent.ACTION_SENDTO).apply {
                        data = Uri.parse("mailto:")               // only email apps
                        putExtra(Intent.EXTRA_EMAIL, arrayOf("your@gmail.com"))  // ← your mail ID
                        putExtra(Intent.EXTRA_SUBJECT, "Feedback – ShayariVerse")
                        putExtra(Intent.EXTRA_TEXT, "Hi ShayariVerse team,\n\n")
                    }
                    context.startActivity(Intent.createChooser(intent, "Send Feedback via..."))

                })
            }

            // Legal Section
            item {
                SectionTitle("Legal & About")

                SettingItem("Privacy Policy", Icons.Default.Gavel, onClick = {
                    val intent = Intent(
                        Intent.ACTION_VIEW,
                        "https://sites.google.com/view/shayariprivacypolicy/home".toUri()
                    )
                    context.startActivity(intent)

                })
                SettingItem("About ShayariVerse", Icons.Default.Info, onClick = {
                    navController.navigate(AppRoute.About)
                })
            }

            // Logout Button

        }


    if (showRateDialog) {
        RateAppDialog(onDismiss = { showRateDialog = false })
    }
}