package com.example.shayariverse

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.shayariverse.ui.theme.ShayariVerseTheme
import com.example.shayariverse.presentation.ui.mainscreen.MainScreen
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        AdManager.initialize(this)

        // Preload ads so they're ready when needed
        AdManager.loadInterstitialAd(this)
        AdManager.loadRewardedAd(this)
        setContent {
            ShayariVerseTheme {
                    MainScreen()   // 👈 Entry point of your UI
                }

                }
            }
        }




