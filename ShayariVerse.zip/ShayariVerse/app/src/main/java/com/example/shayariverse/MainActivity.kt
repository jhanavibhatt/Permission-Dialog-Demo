package com.example.shayariverse

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.example.shayariverse.ui.theme.ShayariVerseTheme
import com.example.shayariverse.presentation.ui.mainscreen.MainScreen
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )

        AdManager.initialize(this)

        // Preload ads so they're ready when needed
        AdManager.loadInterstitialAd(this)
        AdManager.loadRewardedAd(this)
        setContent {
            ShayariVerseTheme {
                    MainScreen()
                }

                }
            }
        }




