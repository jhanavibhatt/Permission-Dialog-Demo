package com.example.shayariverse.presentation.ui.categoryscreen.components

import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.shayariverse.AdManager
import com.example.shayariverse.model.Category
import com.example.shayariverse.presentation.navigation.AppRoute

@Composable
fun AllCategoryCard(category: Category, type: String,
                    navController: NavController
){

    val context = LocalContext.current
    val activity = context as Activity


    Card(modifier = Modifier.fillMaxWidth().clickable{
        AdManager.showInterstitialAd(activity) {
            navController.navigate(
                AppRoute.ListScreen(
                    type = type,
                    category = category.title
                )
            )
        }

    },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)) {

        Box(
            modifier = Modifier
                .background(Color(0xFF2A1E3D))
                .fillMaxWidth()
                .padding(16.dp)){
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ){
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .background(
                            category.color.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(10.dp)
                        ),
                    contentAlignment = Alignment.Center
                ){
                    Icon(
                        imageVector = category.icon,
                        contentDescription = null,
                        tint = category.color
                    )
                }
                Text(
                    category.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = Color.White
                )

                Text(
                    category.count,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White
                )

            }
        }

    }

}