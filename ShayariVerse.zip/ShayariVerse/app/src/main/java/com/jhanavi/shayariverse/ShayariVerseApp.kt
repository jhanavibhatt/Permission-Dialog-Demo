package com.jhanavi.shayariverse

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class ShayariVerseApp: Application() {
}