package com.jhanavi.shayariverse.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "favorites")
data class FavoriteEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val text: String, // ✅ unique identifier
    val type: String,
    val category: String?,
    val author: String?
)