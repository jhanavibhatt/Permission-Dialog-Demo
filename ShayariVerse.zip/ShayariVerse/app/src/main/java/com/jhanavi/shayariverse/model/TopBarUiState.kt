package com.jhanavi.shayariverse.model

data class TopBarUiState(
    val title: String = "",
    val showBack: Boolean = false,
    val showUndo: Boolean = false,
    val showRedo: Boolean = false,
    val showSave: Boolean = false,
    val showMore: Boolean = false,
)