package com.jhanavi.shayariverse.presentation.ui.settingsscreen

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.FormatQuote
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jhanavi.shayariverse.presentation.ui.settingsscreen.components.RateAppDialog
import com.jhanavi.shayariverse.presentation.ui.settingsscreen.components.SectionTitle
import com.jhanavi.shayariverse.presentation.ui.settingsscreen.components.SettingItem
import com.jhanavi.shayariverse.ui.theme.ScreenBg
import androidx.core.net.toUri
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.jhanavi.shayariverse.R
import com.jhanavi.shayariverse.presentation.navigation.AppRoute

@SuppressLint("SuspiciousIndentation")
@Composable
fun SettingsScreen(navController: NavController) {
    var showRateDialog by remember { mutableStateOf(false) }
    val context = LocalContext.current


        // Header

        LazyColumn(modifier = Modifier
            .fillMaxSize()
            .background(ScreenBg)) {

            // App Profile Section
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {

                    Box(
                        modifier = Modifier
                            .size(80.dp)
                            .clip(RoundedCornerShape(20.dp))
                            .background(
                                Brush.linearGradient(
                                    listOf(Color(0xFF7F19E6), Color(0x997F19E6))
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.FormatQuote,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(40.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        "ShayariVerse",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = Color.White
                    )

                    Text(
                        "Version 2.4.0",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                }
            }

            // Support Section
            item {
                SectionTitle(stringResource(R.string.support_community))

                SettingItem(stringResource(R.string.rate_app), Icons.Default.Star, onClick = {showRateDialog = true })
                SettingItem(stringResource(R.string.share_with_friends), Icons.Default.Share, onClick = {})
                SettingItem(stringResource(R.string.send_feedback), Icons.Default.Email, onClick = {
                    val intent = Intent(Intent.ACTION_SENDTO).apply {
                        data = Uri.parse("mailto:")               // only email apps
                        putExtra(Intent.EXTRA_EMAIL, arrayOf("your@gmail.com"))  // ← your mail ID
                        putExtra(Intent.EXTRA_SUBJECT, "Feedback – ShayariVerse")
                        putExtra(Intent.EXTRA_TEXT, "Hi ShayariVerse team,\n\n")
                    }
                    context.startActivity(Intent.createChooser(intent, "Send Feedback via..."))

                })
            }

            // Legal Section
            item {
                SectionTitle(stringResource(R.string.legal_about))

                SettingItem(stringResource(R.string.privacy_policy), Icons.Default.Gavel, onClick = {
                    val intent = Intent(
                        Intent.ACTION_VIEW,
                        "https://sites.google.com/view/shayariprivacypolicy/home".toUri()
                    )
                    context.startActivity(intent)

                })
                SettingItem(stringResource(R.string.about_shayariverse), Icons.Default.Info, onClick = {
                    navController.navigate(AppRoute.About)
                })
            }

            // Logout Button

        }


    if (showRateDialog) {
        RateAppDialog(onDismiss = { showRateDialog = false })
    }
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun SettingsScreenPreview() {
    SettingsScreen(navController = rememberNavController())
}