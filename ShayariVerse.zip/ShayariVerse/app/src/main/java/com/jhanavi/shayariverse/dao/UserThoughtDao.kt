package com.jhanavi.shayariverse.dao

import androidx.room.*
import com.jhanavi.shayariverse.model.UserThoughtEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface UserThoughtDao {
    @Query("SELECT * FROM user_thoughts WHERE type = :type ORDER BY timestamp DESC")
    fun getThoughtsByType(type: String): Flow<List<UserThoughtEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertThought(thought: UserThoughtEntity)

    @Update
    suspend fun updateThought(thought: UserThoughtEntity)

    @Delete
    suspend fun deleteThought(thought: UserThoughtEntity)

    @Query("SELECT * FROM user_thoughts WHERE id = :id")
    suspend fun getThoughtById(id: Int): UserThoughtEntity?
}
