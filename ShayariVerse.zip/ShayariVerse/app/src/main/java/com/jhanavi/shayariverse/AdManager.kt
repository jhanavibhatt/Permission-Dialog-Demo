package com.jhanavi.shayariverse

import android.app.Activity
import android.content.Context
import android.util.Log
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

object AdManager {

    private const val TAG = "AdManager"
// app id ca-app-pub-5333281600111629~3822165865
    // ─── Test IDs (use these during development) ───────────────────────────
    const val BANNER_AD_UNIT_ID       = "ca-app-pub-5333281600111629/1669585750"//ca-app-pub-5333281600111629/1669585750
    const val INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-5333281600111629/4152926638"// "ca-app-pub-3940256099942544/1033173712"
    const val REWARDED_AD_UNIT_ID     = "ca-app-pub-3940256099942544/5224354917"

    // ─── Replace above with real IDs before release ─────────────────────────
    // const val BANNER_AD_UNIT_ID       = "ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX"
    // const val INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX"
    // const val REWARDED_AD_UNIT_ID     = "ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX"

    private var interstitialAd: InterstitialAd? = null
    private var rewardedAd: RewardedAd? = null

    // ── Initialize AdMob ────────────────────────────────────────────────────
    fun initialize(context: Context) {
        MobileAds.initialize(context) {
            Log.d(TAG, "AdMob initialized")
        }
    }

    // ── Load Interstitial Ad ────────────────────────────────────────────────
    fun loadInterstitialAd(context: Context) {
        InterstitialAd.load(
            context,
            INTERSTITIAL_AD_UNIT_ID,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                    Log.d(TAG, "Interstitial ad loaded")
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitialAd = null
                    Log.e(TAG, "Interstitial failed: ${error.message}")
                }
            }
        )
    }

    // ── Show Interstitial Ad ────────────────────────────────────────────────
    fun showInterstitialAd(activity: Activity, onAdDismissed: () -> Unit = {}) {
        if (interstitialAd != null) {
            interstitialAd!!.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    interstitialAd = null
                    loadInterstitialAd(activity) // preload next
                    onAdDismissed()
                }
                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    interstitialAd = null
                    onAdDismissed()
                }
            }
            interstitialAd!!.show(activity)
        } else {
            Log.d(TAG, "Interstitial not ready yet")
            loadInterstitialAd(activity)
            onAdDismissed() // proceed without ad
        }
    }

    // ── Load Rewarded Ad ────────────────────────────────────────────────────
    fun loadRewardedAd(context: Context) {
        RewardedAd.load(
            context,
            REWARDED_AD_UNIT_ID,
            AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                    Log.d(TAG, "Rewarded ad loaded")
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    rewardedAd = null
                    Log.e(TAG, "Rewarded failed: ${error.message}")
                }
            }
        )
    }

    // ── Show Rewarded Ad ────────────────────────────────────────────────────
    fun showRewardedAd(
        activity: Activity,
        onRewarded: () -> Unit,
        onAdDismissed: () -> Unit = {}
    ) {
        if (rewardedAd != null) {
            rewardedAd!!.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    rewardedAd = null
                    loadRewardedAd(activity)
                    onAdDismissed()
                }
                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    rewardedAd = null
                    onAdDismissed()
                }
            }
            rewardedAd!!.show(activity) { onRewarded() }
        } else {
            Log.d(TAG, "Rewarded ad not ready yet")
            loadRewardedAd(activity)
            onAdDismissed()
        }
    }

}