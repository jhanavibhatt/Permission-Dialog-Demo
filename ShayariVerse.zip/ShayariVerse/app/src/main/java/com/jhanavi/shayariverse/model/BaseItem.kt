package com.jhanavi.shayariverse.model

interface BaseItem {
    val category: String
}