package com.jhanavi.shayariverse.presentation.ui.listscreen

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.jhanavi.shayariverse.QuoteRepository
import com.jhanavi.shayariverse.model.Quote
import com.jhanavi.shayariverse.model.Shayri
import com.jhanavi.shayariverse.presentation.navigation.CategoryType
import com.jhanavi.shayariverse.presentation.ui.listscreen.components.QuoteItemCard
import com.jhanavi.shayariverse.presentation.ui.listscreen.components.ShayriItemCard
import com.jhanavi.shayariverse.ui.theme.ScreenBg
import com.jhanavi.shayariverse.viewmodel.FavoriteViewModel
import kotlin.collections.filter


@Composable
fun ListScreen(  category: String?,type: CategoryType,
                 navController: NavController,viewModel: FavoriteViewModel = hiltViewModel()) {

    var selectedFilter by remember { mutableIntStateOf(0) }


    val context = LocalContext.current

//    val allQuotes = remember(type) {
//        when (type) {
//            "quotes" -> QuoteRepository.loadQuotes(context)
//            "shayari" -> QuoteRepository.loadShayri(context)
//            else -> emptyList()
//        }
//    }
    val allQuotes by produceState<List<Any>>(
        initialValue = emptyList(),
        key1 = type
    ) {
        value = when (type) {
            CategoryType.QUOTES -> QuoteRepository.loadQuotes(context)
            CategoryType.SHAYARI -> QuoteRepository.loadShayri(context)
        }
    }

//    val filteredQuotes = remember(category, allQuotes) {
//        if (category == null) allQuotes
//        else allQuotes.filter {
//            it.category.equals(category, ignoreCase = true)
//        }
//    }
    val filteredQuotes = remember(category, allQuotes) {
        if (category == null) {
            allQuotes
        } else {
            allQuotes.filter { item ->
                when (item) {
                    is Quote -> item.category.equals(category, ignoreCase = true)
                    is Shayri -> item.category.equals(category, ignoreCase = true)
                    else -> false
                }
            }
        }
    }



    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ScreenBg)
            .padding(16.dp)
    ) {

        Spacer(Modifier.height(16.dp))

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {

                items(filteredQuotes) { item ->

                    when (item) {
                        is Quote -> QuoteItemCard(item, viewModel)
                        is Shayri -> ShayriItemCard(item, viewModel)
                    }
                }
            }
        }
    }


@Preview(showBackground = true, showSystemUi = true)
@Composable
fun ListScreenPreview() {
    ListScreen(
        category = "Love",
        type = CategoryType.SHAYARI,
        navController = rememberNavController()
    )
}
