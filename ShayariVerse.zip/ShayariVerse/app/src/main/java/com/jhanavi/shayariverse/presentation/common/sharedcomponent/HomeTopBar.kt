package com.jhanavi.shayariverse.presentation.common.sharedcomponent

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.RowScope
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.sp
import com.jhanavi.shayariverse.presentation.ui.homescreen.PrimaryColor

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeTopBar(
    title: String,
    subtitle: String? = null,
    showBack: Boolean,
    onBackClick: () -> Unit,
    actions: @Composable RowScope.() -> Unit = {
        IconButton(onClick = {}) {
            Icon(Icons.Default.Search, null, tint = PrimaryColor)
        }
        IconButton(onClick = {}) {
            Icon(Icons.Default.Notifications, null, tint = PrimaryColor)
        }
    }
) {

    TopAppBar(
        title = {
            Column {

                Text(
                    text = title,
                    color = PrimaryColor,
                    fontSize = 20.sp
                )

                // ✅ Only show if provided
                if (subtitle != null) {
                    Text(
                        text = subtitle,
                        color = PrimaryColor.copy(alpha = 0.7f),
                        fontSize = 12.sp
                    )
                }
            }
        },

        navigationIcon = {

            if (showBack) {
                IconButton(onClick = onBackClick) {
                    Icon(
                        Icons.Default.ArrowBack,
                        contentDescription = null,
                        tint = PrimaryColor
                    )
                }
            }
        },

        actions =actions
    )
}