package com.jhanavi.shayariverse.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jhanavi.shayariverse.model.FavoriteEntity
import com.jhanavi.shayariverse.repository.FavoriteRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class FavoriteViewModel @Inject constructor(
    private val repo: FavoriteRepository
) : ViewModel() {

    val favorites = repo.getFavorites().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    fun toggleFavorite(item: FavoriteEntity) {
        viewModelScope.launch {
            repo.toggleFavorite(item)
        }
    }

    fun isFavorite(text: String): StateFlow<Boolean> =
        repo.isFavorite(text).stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            false
        )

    fun deleteFavorite(id: Int) {

        viewModelScope.launch {

            repo.deleteFavorite(id)
        }
    }
}