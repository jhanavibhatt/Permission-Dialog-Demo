package com.jhanavi.shayariverse.presentation.ui.categoryscreen.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.jhanavi.shayariverse.model.Category
import com.jhanavi.shayariverse.presentation.navigation.CategoryType

@Composable
fun AllCategoryGrid(categories: List<Category>, type: CategoryType,
                    navController: NavController, modifier: Modifier=Modifier){
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(categories, key = { it.title }, contentType = { "category_card" }){
            AllCategoryCard(it,type,navController)
        }
    }

}