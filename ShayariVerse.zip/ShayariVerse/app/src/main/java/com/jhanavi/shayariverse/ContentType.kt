package com.jhanavi.shayariverse

enum class ContentType {
    SHAYARI,
    QUOTE
}