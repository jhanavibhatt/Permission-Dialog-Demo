package com.jhanavi.shayariverse.presentation.ui.homescreen.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.jhanavi.shayariverse.presentation.ui.homescreen.PrimaryColor

@Composable
fun ExploreHeader(
    title: String,
    onSeeAllClick: () -> Unit = {}
) {

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {

        Text(
            title,
            style = MaterialTheme.typography.titleMedium,
            color = Color.White
        )

        Text(
            "See All",
            color = PrimaryColor,
            modifier = Modifier.clickable { onSeeAllClick() }
        )
    }
}
