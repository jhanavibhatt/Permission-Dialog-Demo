package com.jhanavi.shayariverse.presentation.ui.homescreen.components

import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.FormatQuote
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.util.lerp
import com.jhanavi.shayariverse.R
import com.jhanavi.shayariverse.presentation.ui.homescreen.PrimaryColor
import kotlinx.coroutines.delay

@Composable
fun ShayariOfDayCard() {

    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val shayaris = listOf(
        "राह संघर्ष की जो चलता है,\nवही संसार को बदलता है,\nजिसने रातों में जंग जीती है,\nसूर्य बनकर वही निकलता है!",

        "Kabhi to chhu ke dekhe koi hamari taraf..\nKisi ki aankh mein hamko bhi intezar dikhe...🫣",

        "Mein tere zikr mein bhi nahi,\nAur mujhe tu lafz lafz yaad hai..",

        "Being emotionally intelligent is a curse.\nYou really can't judge or hate someone,\nSo you end up saying:\n'Kya pata, iski bhi koi majburi rahi hogi.'",

        "Khoye the teri yaad mein,\nKyun khoye the kuch yaad nahi.\nSab kuch bhul gayi tujhe sochte sochte,\nKya sochti thi vo yaad nahi.\nSirf tu hi yaad hai bas,\nKyun yaad ho yeh to yaad nahi...",

        "क्या ख़बर उस रोशनी में और क्या रोशन हुआ,\nजब वो इन हाथों से पहली मर्तबा रोशन हुआ।\nवो मेरे सीने से लग कर जिसको रोई वो कौन था,\nकिसके बुझने पर आज मैं उसकी जगह रोशन हुआ..",

        "Vo umeed usi hatheli mein baandhke rakhti hai,\nJis haath ko kabhi kisi ne thama nahi.....\nVo rooh jo ishq poore dil se nibhati hai,\nUse kabhi koi jaan paaya nahi..💗",

        "Jazbaat ulajh jaate hai,\nJin aankhon ki roshni se qaainat roshan ho jaaya karti thi,\nUn aankhon mein jab andhera हो jata hai.\nMagार जब स्याही कागज़ से बात करती है,\nतो सब ठीक हो जाता है।",

        "Sajne lage hai ab jismani se alfaaz,\nDikhave ki dukaano par.\nVoh kya hai ki,\nRooh ki saada si khamoshi ko,\nKoi kharidar na mila. 😇🩷",

        "Kuch to kami rahi hogi,\nZamane ki samajhdari mein..\nShayari varna yun hi har,\nJazbaat ko chhupaya nahi karti. 😊",

        "શોધું એક બહાનું તને મળવાનું,\nને મળવાનું કારણ મળી જાય.\nમાંગુ એક દિવસ તારો,\nને હર એક સાંજનો સથવારો મળી જાય.\nમાંગુ એક સુવાસ તારી,\nને હર એક શ્વાસમાં તારો સંગાથ મળી જાય.\nખોવાઉ જ્યારે તારી યાદોમાં,\nઆંગળી પકડેલો તારો હાથ મળી જાય.\nજ્યાં પણ શોધું સુકુન,\nવિતાવેલી તારી સાથેની એ પળો પાછી મળી જાય..",

        "Teri har ek baat ka hisaab rakha hai,\nTere aane aur jaane ka waqt behisaab rakha hai.\nTu ek baar milne to aa,\nMaine tere liye tohfa tayyar rakha hai.\nItna hai pyaar tujhse ki,\nDil mein teri jagah chhupa rakha hai."
    )

    val pagerState = rememberPagerState(
        pageCount = { shayaris.size }
    )

    LaunchedEffect(Unit) {
        while (true) {
            delay(5000) // 5 seconds delay

            val nextPage = (pagerState.currentPage + 1) % shayaris.size

            pagerState.animateScrollToPage(
                page = nextPage,
                animationSpec = tween(
                    durationMillis = 2000,
                    easing = FastOutSlowInEasing
                )
            )
        }
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(PrimaryColor)
    ) {

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
        ) {

            Row(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .offset(x = 25.dp, y = 30.dp)
            ) {

                Icon(
                    imageVector = Icons.Default.FormatQuote,
                    contentDescription = null,
                    tint = Color.White.copy(alpha = 0.06f),
                    modifier = Modifier.size(120.dp)
                )
            }

            // 🔹 CONTENT
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {

                Text(
                    stringResource(R.string.shayari_of_the_day),
                    style = MaterialTheme.typography.titleLarge,
                    color = Color.White
                )

                Spacer(modifier = Modifier.height(8.dp))

                HorizontalPager(
                    state = pagerState,
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) { page ->

                    val pageOffset = ((pagerState.currentPage - page) + pagerState.currentPageOffsetFraction).let { kotlin.math.abs(it) }

                    val alpha = lerp(
                        start = 0.5f,
                        stop = 1f,
                        fraction = 1f - pageOffset.coerceIn(0f, 1f)
                    )

                    val scale = lerp(
                        start = 0.9f,
                        stop = 1f,
                        fraction = 1f - pageOffset.coerceIn(0f, 1f)
                    )

                    Text(
                        text = shayaris[page],
                        color = Color.White,
                        style = MaterialTheme.typography.bodyMedium,
                        fontStyle = FontStyle.Italic,
                        modifier = Modifier.graphicsLayer {
                            this.alpha = alpha
                            scaleX = scale
                            scaleY = scale
                        }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = {
                            val currentShayari = shayaris[pagerState.currentPage]
                            val intent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, currentShayari)
                            }
                            context.startActivity(Intent.createChooser(intent, "Share Shayari"))
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.White.copy(alpha = 0.2f)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null)
                        Text(
                            "Share",
                            color = Color.White,
                            modifier = Modifier.padding(start = 8.dp)
                        )
                    }

                    Button(
                        onClick = {
                            val currentShayari = shayaris[pagerState.currentPage]
                            clipboardManager.setText(AnnotatedString(currentShayari))
                            Toast.makeText(context, "Copied to clipboard", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.White.copy(alpha = 0.2f)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null)
                        Text(
                            "Copy",
                            color = Color.White,
                            modifier = Modifier.padding(start = 8.dp)
                        )
                    }
                }
            }
        }
    }
}
