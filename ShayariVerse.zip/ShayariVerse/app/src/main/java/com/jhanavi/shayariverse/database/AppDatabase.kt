package com.jhanavi.shayariverse.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.jhanavi.shayariverse.dao.FavoriteDao
import com.jhanavi.shayariverse.dao.UserThoughtDao
import com.jhanavi.shayariverse.model.FavoriteEntity
import com.jhanavi.shayariverse.model.UserThoughtEntity

@Database(entities = [FavoriteEntity::class,  UserThoughtEntity::class], version = 4, exportSchema = false )
abstract class AppDatabase : RoomDatabase() {
    abstract fun favoriteDao(): FavoriteDao
    abstract fun userThoughtDao(): UserThoughtDao
}