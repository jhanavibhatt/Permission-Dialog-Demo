package com.jhanavi.shayariverse.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.jhanavi.shayariverse.dao.FavoriteDao
import com.jhanavi.shayariverse.model.FavoriteEntity

@Database(entities = [FavoriteEntity::class], version = 3, exportSchema = false )
abstract class AppDatabase : RoomDatabase() {
    abstract fun favoriteDao(): FavoriteDao
}