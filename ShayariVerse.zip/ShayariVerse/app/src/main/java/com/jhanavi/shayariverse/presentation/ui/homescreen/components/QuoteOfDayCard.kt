package com.jhanavi.shayariverse.presentation.ui.homescreen.components

import android.content.Intent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.FormatQuote
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.util.lerp
import com.jhanavi.shayariverse.R
import kotlinx.coroutines.delay

@Composable
fun QuoteOfDayCard() {

    val context = LocalContext.current
    val quotes = listOf(
        "The soul always knows what to do to heal itself. The challenge is to silence the mind.",
        "The only place success comes before work is in the dictionary.",
        "The most difficult thing is the decision to act, the rest is merely tenacity.",
        "Luck is what happens when preparation meets opportunity.",
        "Be yourself; everyone else is already taken.",
        "Success usually comes to those who are too busy looking for it.",
        "In the middle of every difficulty lies opportunity.",
        "The most common way people give up their power is by thinking they don't have any.",
        "Be the change that you wish to see in the world.",
        "Success consists of going from failure to failure without loss of enthusiasm."
    )
    val pagerState = rememberPagerState(
        pageCount = { quotes.size }
    )

    LaunchedEffect(Unit) {
        while (true) {
            delay(5000) // 3 seconds

            val nextPage =
                (pagerState.currentPage + 1) % quotes.size

            pagerState.animateScrollToPage(
                page = nextPage,
                animationSpec = tween(
                    durationMillis = 2000, // 2-second smooth slide
                    easing = FastOutSlowInEasing
                )
            )
        }
    }



    val gradient = remember {
        Brush.linearGradient(
            colors = listOf(
                Color(0xFF1E1230),
                Color(0xFF2A1E3D)
            )
        )
    }

    Card(
        modifier = Modifier
            .fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {

        Box(
            modifier = Modifier
                .background(gradient)
                .padding(16.dp)
        ) {


            Icon(
                imageVector = Icons.Default.FormatQuote,
                contentDescription = null,
                tint = Color.White.copy(alpha = 0.05f),
                modifier = Modifier
                    .size(120.dp)
                    .align(Alignment.TopEnd)
                    .offset(x = 20.dp, y = (-10).dp)
            )

            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {

                // ✅ 1️⃣ Pill Background Label
                Box(
                    modifier = Modifier
                        .background(
                            color = Color(0xFF7F19E6).copy(alpha = 0.2f),
                            shape = RoundedCornerShape(50)
                        )
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = stringResource(R.string.quote_of_the_day),
                        color = Color(0xFFB388FF),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // 🔹 Quote Text
                HorizontalPager(
                    state = pagerState,
                    modifier = Modifier.fillMaxWidth()
                ) { page ->

                    val pageOffset = (
                            (pagerState.currentPage - page) + pagerState.currentPageOffsetFraction
                            ).let { kotlin.math.abs(it) }

                    val alpha = lerp(
                        start = 0.5f,
                        stop = 1f,
                        fraction = 1f - pageOffset.coerceIn(0f, 1f)
                    )

                    val scale = lerp(
                        start = 0.9f,
                        stop = 1f,
                        fraction = 1f - pageOffset.coerceIn(0f, 1f)
                    )

                    Text(
                        text = "\"${quotes[page]}\"",
                        color = Color.White,
                        fontSize = 16.sp,
                        minLines = 2,
                        fontStyle = FontStyle.Italic,
                        lineHeight = 22.sp,
                        modifier = Modifier.graphicsLayer {
                            this.alpha = alpha
                            scaleX = scale
                            scaleY = scale
                        }
                    )
                }

                // 🔹 Bottom Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {

                    // Author
                    Row(verticalAlignment = Alignment.CenterVertically) {

                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(
                                    Color(0xFF7F19E6),
                                    shape = CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("C", color = Color.White)
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        Text(
                            text = "Caroline Myss",
                            color = Color.White.copy(alpha = 0.8f)
                        )
                    }

                    // ✅ 2️⃣ Action Buttons with Background
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {

                        ActionIconButton(
                            icon = Icons.Default.Share,
                            onClick = {
                                val currentQuote = quotes[pagerState.currentPage]
                                val intent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, currentQuote)
                                }
                                context.startActivity(Intent.createChooser(intent, "Share Quote"))
                            }
                        )

                        ActionIconButton(
                            icon = Icons.Default.ContentCopy,
                            onClick = {
                                // Add copy functionality if needed, for now just share was requested
                            }
                        )
                    }
                }
            }
        }
    }
}
@Composable
fun ActionIconButton(icon: ImageVector, onClick: () -> Unit = {}) {

    Box(
        modifier = Modifier
            .size(36.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(
                Color.White.copy(alpha = 0.08f) // 👈 glass effect
            )
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(18.dp)
        )
    }
}
