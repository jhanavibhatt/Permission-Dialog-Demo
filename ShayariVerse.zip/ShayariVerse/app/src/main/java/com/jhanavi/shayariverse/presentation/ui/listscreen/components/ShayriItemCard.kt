package com.jhanavi.shayariverse.presentation.ui.listscreen.components

import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FileCopy
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.outlined.FileCopy
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import com.jhanavi.shayariverse.model.FavoriteEntity
import com.jhanavi.shayariverse.model.Shayri
import com.jhanavi.shayariverse.presentation.ui.favoritescreen.ContentItem
import com.jhanavi.shayariverse.viewmodel.FavoriteViewModel
import kotlinx.coroutines.delay

@Composable
fun ShayriItemCard(shayri: Shayri, viewModel: FavoriteViewModel) {
    val isFav by viewModel.isFavorite(shayri.shayri).collectAsState()


    val clipboardManager = LocalClipboardManager.current
    val context = LocalContext.current
    var isCopied by remember { mutableStateOf(false) }


    LaunchedEffect(isCopied) {
        if (isCopied) {
            delay(1500)
            isCopied = false
        }
    }

    val entity = FavoriteEntity(
        text = shayri.shayri,
        type = "shayari",
        category = shayri.category,
        author = null
    )

    val contentItem = ContentItem(
        text = shayri.shayri,
        type = "shayari",
        category = shayri.category
    )

//    var isFav by remember {
//        mutableStateOf(FavoriteManager.isFavorite(contentItem.text))
//    }


    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF2A1E3D)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {

        Column(modifier = Modifier.padding(16.dp)) {

            Text(
                text = shayri.shayri,
                color = Color.White
            )

            Spacer(Modifier.height(12.dp))

            CategoryBadge(shayri.category)

            Spacer(Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                ActionItem(
                    icon = Icons.Default.Favorite,
                    tint = if (isFav) Color.Red else Color.Gray,
                    onClick = {
                        viewModel.toggleFavorite(entity)
                    },
                    text = "Add to Favorite ",
                    modifier = Modifier.weight(1f)
                )
                ActionItem(
                    icon = if (isCopied) Icons.Filled.FileCopy else Icons.Outlined.FileCopy,
                    text = if (isCopied) "Copied" else "Copy",
                    modifier = Modifier.weight(1f),
                    onClick = {
                        clipboardManager.setText(AnnotatedString(shayri.shayri))
                        isCopied = true
                    })
                ActionItem(Icons.Default.Share, "Share",onClick = {
                    val shareText = shayri.shayri

                    val intent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, shareText)
                    }

                    context.startActivity(
                        Intent.createChooser(intent, "Share via")
                    )
                },modifier = Modifier.weight(1f))
            }
        }
    }
}