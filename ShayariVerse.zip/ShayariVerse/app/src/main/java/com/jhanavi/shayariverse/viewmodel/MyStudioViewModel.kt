package com.jhanavi.shayariverse.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jhanavi.shayariverse.model.UserThoughtEntity
import com.jhanavi.shayariverse.repository.UserThoughtRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.launch
import javax.inject.Inject

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class MyStudioViewModel @Inject constructor(
    private val repository: UserThoughtRepository
) : ViewModel() {

    private val _selectedTab = MutableStateFlow("Quotes")
    val selectedTab: StateFlow<String> = _selectedTab.asStateFlow()

    val thoughts = _selectedTab.flatMapLatest { type ->
        repository.getThoughtsByType(type)
    }

    fun selectTab(type: String) {
        _selectedTab.value = type
    }

    fun addThought(
        title: String,
        content: String,
        type: String,
        textAlign: String = "Start",
        fontSize: Float = 18f,
        isBold: Boolean = false,
        isItalic: Boolean = false,
        isUnderline: Boolean = false,
        fontFamily: String = "Default"
    ) {
        viewModelScope.launch {
            repository.insertThought(
                UserThoughtEntity(
                    title = title,
                    content = content,
                    type = type,
                    textAlign = textAlign,
                    fontSize = fontSize,
                    isBold = isBold,
                    isItalic = isItalic,
                    isUnderline = isUnderline,
                    fontFamily = fontFamily
                )
            )
        }
    }

    fun updateThought(thought: UserThoughtEntity) {
        viewModelScope.launch {
            repository.updateThought(thought)
        }
    }

    fun deleteThought(thought: UserThoughtEntity) {
        viewModelScope.launch {
            repository.deleteThought(thought)
        }
    }
}
