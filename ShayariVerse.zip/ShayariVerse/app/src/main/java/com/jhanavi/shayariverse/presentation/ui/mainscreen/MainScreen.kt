package com.jhanavi.shayariverse.presentation.ui.mainscreen

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.jhanavi.shayariverse.R
import com.jhanavi.shayariverse.presentation.common.sharedcomponent.HomeTopBar
import com.jhanavi.shayariverse.presentation.navigation.AppRoute
import com.jhanavi.shayariverse.presentation.navigation.CategoryType
import com.jhanavi.shayariverse.presentation.ui.aboutscreen.AboutScreen
import com.jhanavi.shayariverse.presentation.ui.mainscreen.components.BottomNavBar
import com.jhanavi.shayariverse.presentation.ui.categoryscreen.CategoryScreen
import com.jhanavi.shayariverse.presentation.ui.favoritescreen.FavoriteScreen
import com.jhanavi.shayariverse.presentation.ui.homescreen.HomeScreen
import com.jhanavi.shayariverse.presentation.ui.listscreen.ListScreen
import com.jhanavi.shayariverse.presentation.ui.settingsscreen.SettingsScreen
import com.jhanavi.shayariverse.presentation.ui.splashscreen.SplashScreen

@Composable
fun MainScreen() {

    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val destination = backStackEntry?.destination

    val isSplash =
        destination?.hasRoute<AppRoute.Splash>() == true

    val topLevelScreens = setOf(
        AppRoute.Home,
        AppRoute.Favorites,
        AppRoute.Settings
    )
    val currentScreen = when {
        destination?.hasRoute<AppRoute.Home>() == true ->
            AppRoute.Home

        destination?.hasRoute<AppRoute.Favorites>() == true ->
            AppRoute.Favorites

        destination?.hasRoute<AppRoute.Settings>() == true ->
            AppRoute.Settings

        destination?.hasRoute<AppRoute.About>() == true ->
            AppRoute.About

        else -> null
    }

    val title = when {


        currentScreen?.title != null ->
            stringResource(currentScreen.title)

        destination?.hasRoute<AppRoute.Categories>() == true -> {
            val type = backStackEntry
                ?.toRoute<AppRoute.Categories>()
                ?.type

            when (type) {
                CategoryType.SHAYARI ->
                    stringResource(R.string.shayari_categories)

                CategoryType.QUOTES ->
                    stringResource(R.string.quote_categories)

                null ->
                    stringResource(R.string.categories)
            }
        }

        destination?.hasRoute<AppRoute.ListScreen>() == true -> {
            backStackEntry
                ?.toRoute<AppRoute.ListScreen>()
                ?.category
                ?: stringResource(R.string.collection)
        }

        else ->
            stringResource(R.string.app_name)
    }
    val showBack = currentScreen !in topLevelScreens

    

    Scaffold(
        topBar = {
            if (!isSplash) {
            HomeTopBar(
                title = title,
                subtitle = null,
                showBack = showBack,
                onBackClick = { navController.popBackStack() }
            )
                }
        },
        bottomBar = {
            if (!isSplash && currentScreen in topLevelScreens) {
                BottomNavBar(
                    currentScreen = currentScreen,
                    onTabSelected = { screen ->

                        navController.navigate(screen) {

                            popUpTo(navController.graph.startDestinationId) {
                                saveState = true
                            }

                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
            }
        } //  only bottom bar here
    ) { padding ->

        NavHost(
            navController = navController,
            startDestination = AppRoute.Splash,
            modifier = Modifier.padding(padding)
        ) {

            composable<AppRoute.Splash> {
                SplashScreen(
                    onSplashFinished = {
                        navController.navigate(AppRoute.Home) {
                            popUpTo<AppRoute.Splash> {
                                inclusive = true
                            }
                        }
                    }
                )
            }

            composable<AppRoute.Home> {
                HomeScreen(navController)
            }

            composable<AppRoute.Favorites> {
                FavoriteScreen()
            }
            composable<AppRoute.Settings> {
                SettingsScreen(navController)
            }
            composable<AppRoute.About> {
                AboutScreen()
            }

            composable<AppRoute.Categories> { entry ->
                val args = entry.toRoute<AppRoute.Categories>()

                CategoryScreen(
                    type = args.type,
                    navController = navController
                )
            }

            composable<AppRoute.ListScreen> { entry ->
                val args = entry.toRoute<AppRoute.ListScreen>()

                ListScreen(
                    category = args.category,
                    type = args.type,
                    navController = navController
                )
            }

        }
    }
}