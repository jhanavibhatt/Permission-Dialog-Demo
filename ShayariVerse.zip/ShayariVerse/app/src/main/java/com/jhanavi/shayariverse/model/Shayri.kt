package com.jhanavi.shayariverse.model

data class Shayri(
    override val category: String,
    val shayri: String,
) : BaseItem