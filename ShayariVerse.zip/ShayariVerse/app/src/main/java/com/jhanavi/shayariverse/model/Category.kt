package com.jhanavi.shayariverse.model

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

data class Category(
    val title: String,
    val count: String,
    val icon: ImageVector,
    val color: Color
)
