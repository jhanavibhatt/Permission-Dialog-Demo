package com.jhanavi.shayariverse.presentation.ui.aboutscreen

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.FormatQuote
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jhanavi.shayariverse.R
import com.jhanavi.shayariverse.ui.theme.AccentPurpleL
import com.jhanavi.shayariverse.ui.theme.HeroBgMid
import com.jhanavi.shayariverse.ui.theme.HeroBgStart
import com.jhanavi.shayariverse.ui.theme.QuoteStripBdr
import com.jhanavi.shayariverse.ui.theme.QuoteStripBg
import com.jhanavi.shayariverse.ui.theme.QuoteText

import com.jhanavi.shayariverse.ui.theme.ScreenBg


private data class FeatureItem(
    val iconRes: ImageVector,         // e.g. R.drawable.ic_grid
    val label: String,
    val bgColor: Color,
    val iconColor: Color
)

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun AboutScreen() {
    val gradient = remember {
        Brush.linearGradient(
            colors = listOf(
                Color(0xFF1E1230),
                Color(0xFF2A1E3D)
            )
        )
    }
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ScreenBg)
    ) {
        item {
            HeroSection()
        }
        item {
            HorizontalDivider(color = QuoteStripBdr, thickness = 0.5.dp)
        }
        item {
            QuoteBannerSection()
        }

        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(15.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent)
            ) {

                Box(
                    modifier = Modifier
                        .background(gradient)
                        .padding(16.dp)
                ) {


                    Icon(
                        imageVector = Icons.Default.FormatQuote,
                        contentDescription = null,
                        tint = Color.White.copy(alpha = 0.05f),
                        modifier = Modifier
                            .size(120.dp)
                            .align(Alignment.TopEnd)
                            .offset(x = 20.dp, y = (-10).dp)
                    )


                    Column(
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {


                        Text(
                            text = "Our Story",
                            color = Color(0xFFB388FF),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(Modifier.height(10.dp))
                        // 🔹 Quote Text
                        Text(
                            text = "ShayariVerse was born as a sanctuary for those who find beauty in words. We bridge the gap between the timeless art of traditional Shayari and the sharpness of contemporary quotes. In a world of fleeting digital noise, we curate moments of profound literary resonance, creating an ethereal anthology for the modern reader.",
                            color = Color.White,
                            fontSize = 16.sp,
                            fontStyle = FontStyle.Italic,
                            lineHeight = 22.sp
                        )
                    }
                }
            }
        }
        item {
            AboutDescription()
        }
        item {
            FeaturesGridSection()
        }
        item {
            MadeWithFooter()
        }
    }
}


@Composable
private fun HeroSection() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.linearGradient(
                    colors = listOf(HeroBgStart, HeroBgMid, HeroBgStart),
                    start = Offset(0f, 0f),
                    end = Offset(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY)
                ),
                shape = RoundedCornerShape(15.dp)
            )
            .padding(vertical = 32.dp, horizontal = 24.dp),
        contentAlignment = Alignment.Center
    ) {
        // Decorative circle — top left
        Box(
            modifier = Modifier
                .size(140.dp)
                .offset(x = (-40).dp, y = (-40).dp)
                .clip(CircleShape)
                .background(Color(0x1FA774FF))
                .align(Alignment.TopStart)
        )
        // Decorative circle — bottom right
        Box(
            modifier = Modifier
                .size(100.dp)
                .offset(x = 30.dp, y = 30.dp)
                .clip(CircleShape)
                .background(Color(0x14FFB464))
                .align(Alignment.BottomEnd)
        )

        Column(horizontalAlignment = Alignment.CenterHorizontally) {

            // App icon
            Box(
                modifier = Modifier
                    .size(76.dp)
                    .clip(CircleShape)
                    .border(
                        width = 4.dp,
                        color = AccentPurpleL,
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.ic_logo),
                    contentDescription = "App Logo",
                    modifier = Modifier.size(70.dp)
                )
            }

            Spacer(Modifier.height(16.dp))

            Text(
                text = stringResource(R.string.app_name),
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                letterSpacing = 0.5.sp
            )

            Spacer(Modifier.height(4.dp))

            Text(
                text = "WHERE WORDS FIND A SOUL",
                fontSize = 11.sp,
                color = Color.White.copy(alpha = 0.5f),
                letterSpacing = 2.5.sp
            )

            Spacer(Modifier.height(14.dp))


        }
    }
}

@Composable
fun QuoteBannerSection() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(QuoteStripBg)
            .padding(15.dp),
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Quote icon
        Icon(
            imageVector = Icons.Default.FormatQuote,
            contentDescription = null,
            tint = Color(0xFF9C6BFF),
            modifier = Modifier
                .size(28.dp)
        )
        Text(
            text = "Words have the power to both destroy and heal. " +
                    "When words are both true and kind, they can change the world.",
            style = MaterialTheme.typography.bodyMedium,
            fontStyle = FontStyle.Italic,
            color = QuoteText,
            lineHeight = 20.sp,
            modifier = Modifier.padding(top = 2.dp)
        )
    }
    HorizontalDivider(color = QuoteStripBdr, thickness = 0.5.dp)


}

@Composable
private fun AboutDescription() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .padding(top = 20.dp, bottom = 8.dp)
    ) {
        Text(
            text = stringResource(R.string.about_this_app),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Medium,
            color = Color.White,
            letterSpacing = 1.2.sp
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = stringResource(R.string.app_desc),
            style = MaterialTheme.typography.bodyMedium,
            color = Color.White,
            lineHeight = 21.sp
        )
    }
}

@Composable
fun FeaturesGridSection() {

    Column(
        Modifier
            .fillMaxWidth()
            .padding(15.dp)
    ) {
        Text(
            text = stringResource(R.string.features),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Medium,
            color = Color.White,
            letterSpacing = 1.2.sp
        )
        Spacer(Modifier.height(10.dp))

        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {

            FeatureGridCard(
                modifier = Modifier.weight(1f),
                icon = Icons.Default.GridView,
                iconBg = Color(0xFF4B1FA6),
                iconTint = Color(0xFF9C6BFF),
                title = "Different Categories"
            )

            FeatureGridCard(
                modifier = Modifier.weight(1f),
                icon = Icons.Default.FavoriteBorder,
                iconBg = Color(0xFF5B3417),
                iconTint = Color(0xFFFF8A33),
                title = stringResource(R.string.save_favourites)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {

            FeatureGridCard(
                modifier = Modifier.weight(1f),
                icon = Icons.Default.Share,
                iconBg = Color(0xFF063B35),
                iconTint = Color(0xFF00C896),
                title = stringResource(R.string.easy_sharing)
            )

            FeatureGridCard(
                modifier = Modifier.weight(1f),
                icon = Icons.Default.ContentCopy,
                iconBg = Color(0xFF4A1732),
                iconTint = Color(0xFFFF4D8D),
                title = stringResource(R.string.copy_instantly)
            )
        }
    }
}

@Composable
fun FeatureGridCard(
    modifier: Modifier = Modifier,
    icon: ImageVector,
    iconBg: Color,
    iconTint: Color,
    title: String
) {

    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF232323)
        ),
        border = BorderStroke(
            1.dp,
            Color.White.copy(alpha = 0.08f)
        )
    ) {

        Column(
            modifier = Modifier
                .padding(16.dp)
                .height(80.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {

            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(iconBg),
                contentAlignment = Alignment.Center
            ) {

                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(18.dp)
                )
            }

            Text(
                text = title,
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
private fun MadeWithFooter() {
    HorizontalDivider(
        color = Color(0xFFEEEEEE),
        thickness = 0.5.dp
    )
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Text(
                text = stringResource(R.string.made_with),
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
            )
//            Text(
//                text = "♥",
//                fontSize = 12.sp,
//                color = Color.Red
//            )
//            Text(
//                text = " by ",
//                fontSize = 12.sp,
//                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.45f)
//            )
//            Text(
//                text = stringResource(R.string.shayriverse_team),
//                fontSize = 12.sp,
//                fontWeight = FontWeight.Medium,
//                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
//            )
        }
        Spacer(Modifier.height(4.dp))
        Text(
            text = stringResource(R.string.all_rights),
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
            textAlign = TextAlign.Center
        )
    }
}
