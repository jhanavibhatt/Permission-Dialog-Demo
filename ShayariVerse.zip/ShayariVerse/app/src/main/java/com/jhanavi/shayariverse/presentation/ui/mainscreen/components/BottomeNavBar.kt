package com.jhanavi.shayariverse.presentation.ui.mainscreen.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.vector.ImageVector
import com.jhanavi.shayariverse.presentation.navigation.AppRoute

@Composable
fun BottomNavBar(
    currentScreen: AppRoute?,
    onTabSelected: (AppRoute) -> Unit
) {

//    val items = listOf(
//        AppRoute.Home,
//        AppRoute.Favorites,
//        AppRoute.Settings
//    )
    data class BottomNavItem(
        val route: AppRoute,
        val label: String,
        val icon: ImageVector
    )
    val icons = listOf(
        Icons.Default.Home,
        Icons.Default.Settings,
        Icons.Default.Favorite,
    )
    val items = listOf(
        BottomNavItem(
            route = AppRoute.Home,
            label = "Home",
            icon = Icons.Default.Home
        ),
        BottomNavItem(
            route = AppRoute.Favorites,
            label = "Favorites",
            icon = Icons.Default.Favorite
        ),
        BottomNavItem(
            route = AppRoute.Settings,
            label = "Settings",
            icon = Icons.Default.Settings
        )
    )


//    val navBackStackEntry by navController.currentBackStackEntryAsState()
//    val currentDestination = navBackStackEntry?.destination


    NavigationBar {

        items.forEach { item ->
            NavigationBarItem(
                selected = currentScreen == item.route,
                onClick = {
                    onTabSelected(item.route)
                },
                icon = {
                    Icon(
                        imageVector = item.icon,
                        contentDescription = item.label
                    )
                },
                label = {
                    Text(item.label)
                }
            )
        }
    }
}