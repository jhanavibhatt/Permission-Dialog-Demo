package com.jhanavi.shayariverse.presentation.navigation

import androidx.annotation.StringRes
import com.jhanavi.shayariverse.R
import kotlinx.serialization.Serializable

@Serializable
sealed class AppRoute(@StringRes val title :Int? = null) {

    @Serializable
    data object Splash : AppRoute()

    @Serializable
    data object Home : AppRoute(R.string.app_name)

    @Serializable
    data object Favorites : AppRoute(R.string.favorites)

    @Serializable
    data object Settings : AppRoute(R.string.settings)

    @Serializable
    data object  About : AppRoute(R.string.about)

    @Serializable
    data class Categories(val type: CategoryType) : AppRoute()

    @Serializable
    data class ListScreen(
        val type: CategoryType,
        val category: String
    ) : AppRoute()
}

@Serializable
enum class CategoryType {
    SHAYARI,
    QUOTES
}